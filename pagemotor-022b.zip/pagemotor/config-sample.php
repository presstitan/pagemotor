<?php
/**
 * PageMotor Config Information
 *
 * @package 	PageMotor
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
/*
PageMotor's 3-step setup guide:
1. Provide information in this file to connect to your database
2. Visit your site, and PageMotor will seed initial content data
3. Visit the admin (yoursiteurl.com/admin/) and create your Admin user

NOTE: Rename this file to config.php to activate your PageMotor installation!
*/
// Database connection info:
define('DB_NAME', 'your_db');
define('DB_USER', 'your_username');
define('DB_PASSWORD', 'your_password');
define('DB_HOST', 'localhost');
define('DB_CHARSET', '');					// [string] only enter a value if you want something other than utf8mb4! (you don't)
define('DB_COLLATE', '');					// [string] only enter a value if you also entered an alternate charset!
define('DB_TABLE_PREFIX', 'pm_');			// [string] numbers, letters, and underscores only!
define('DB_FLAGS', '');
define('PM_HTML_CHARSET', '');				// [string] only enter a value if you want something other than utf-8!

// PageMotor installation mods:
define('PM_INSTALL_LOCATION', '');			// [string] Leave false if installed at site root
define('PM_ADMIN_SLUG', '');				// [string] Leave false unless you are a serious cowboy