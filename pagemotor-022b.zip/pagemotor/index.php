<?php
/**
 * PageMotor Initation File
 *
 * @package 	PageMotor
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
require_once(__DIR__. '/pagemotor.php');

if (!function_exists('apply_filters')) {
	function apply_filters($filter, $value) {
		return $value;
	}
}

global $motor;
$motor = new PageMotor;
$motor->init();
$motor->run();