<?php
/**
 * PageMotor Admin Theme
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Theme
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Admin extends PM_Theme {
	public $_seed_content = 'admin_content_seed';	// [string] Option to indicate if Admin content has been seeded
	public $_admin_theme = true;					// [bool] true because this is an Admin Theme
	public $_admin_slug = 'admin-theme';			// [string] to identify Admin control pages
	public $_body_id = 'pm-admin';					// [string] HTML id for <body> of Admin pages
	public $_register_js = array(					// [array] JS for use on various Admin pages
		'content' => array(
			'url' => PM_JS_URL. '/content.js'));
	public $_content_types = array(				// [array] Admin-only content types
		'admin-content' => array(
			'name' => 'Content',
			'environment' => array('admin'),
			'url' => true,
			'hide-ui' => true),
		'admin-plugins' => array(
			'name' => 'Plugins',
			'environment' => array('admin'),
			'url' => true,
			'hide-ui' => true),
		'admin-themes' => array(
			'name' => 'Themes',
			'environment' => array('admin'),
			'url' => true,
			'hide-ui' => true),
		'admin-theme' => array(
			'name' => 'Theme UI',
			'environment' => array('admin'),
			'url' => true,
			'hide-ui' => true,
			'sub-types' => array(
				'display' => array(
					'name' => 'Display Options'),
				'elements' => array(
					'name' => 'Elements'),
				'design' => array(
					'name' => 'Design Options'),
				'options' => array(
					'name' => 'Plugin Options'),
				'css' => array(
					'name' => 'Custom CSS'),
				'editor' => array(
					'name' => 'Editor'))),
		'admin-settings' => array(
			'name' => 'Site Settings',
			'environment' => array('admin'),
			'url' => true,
			'hide-ui' => true));
	public $_no_title = '[No Title Provided]';
	public $admin_docs = array(
		'edit-content' => 'https://pagemotor.com/docs/edit-content/');

	public function _body_id() {
		return $this->_body_id;
	}

	public function _home($depth = 0) {
		global $motor;
		// Content, Plugins, Themes
		$tab = str_repeat("\t", $depth);
		echo
			"$tab<div id=\"pm-admin-home\" class=\"pm-ui-flex pm-ui-flex-3\">\n".
			"$tab\t<div id=\"pm-admin-content\" class=\"pm-ui-flex-item pm-admin-module\">\n".
			"$tab\t\t<h4>Content</h4>\n".
			"$tab\t\t<p class=\"small\">Manage Content Types and edit the content of your site</p>\n".
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			"$tab\t\t\t<a href=\"". $motor->admin_url('content'). "\" class=\"button action\" title=\"Manage site content\">\n".
			$motor->tools->svg->icon('edit', $depth + 4).
			"$tab\t\t\t\tContent\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n".
			($motor->settings->admin_management ?
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			"$tab\t\t\t<a href=\"". $motor->admin_url('admin-content'). "\" class=\"button ui\" title=\"Manage admin content\">\n".
			$motor->tools->svg->icon('edit', $depth + 4).
			"$tab\t\t\t\tAdmin Content\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n" : '').
			"$tab\t</div>\n".
			"$tab\t<div id=\"pm-admin-plugins\" class=\"pm-ui-flex-item pm-admin-module\">\n".
			"$tab\t\t<h4>Plugins</h4>\n".
			"$tab\t\t<p class=\"small\">Change Plugin Settings and manage installed Plugins</p>\n".
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			"$tab\t\t\t<a href=\"". $motor->admin_url('plugins'). "\" class=\"button action\" title=\"Plugin settings\">\n".
			$motor->tools->svg->icon('settings', $depth + 4).
			"$tab\t\t\t\tPlugin Settings\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n".
			"$tab\t\t<form class=\"pm-ui-item-row\" method=\"post\" action=\"". $motor->admin_url('plugins'). "\" enctype=\"multipart/form-data\">\n".
			// Add update number to Manage Plugins button
			"$tab\t\t\t<button name=\"manage\" value=\"1\" title=\"Manage Plugins\">\n".
			$motor->tools->svg->icon('shopping-bag', $depth + 4).
			"$tab\t\t\t\tManage Plugins\n".
			"$tab\t\t\t</button>\n".
			"$tab\t\t</form>\n".
			"$tab\t</div>\n".
			"$tab\t<div id=\"pm-admin-themes\" class=\"pm-ui-flex-item pm-admin-module\">\n".
			"$tab\t\t<h4>Themes</h4>\n".
			"$tab\t\t<p class=\"small\">Change Theme settings and manage installed Themes</p>\n".
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			"$tab\t\t\t<a href=\"". $motor->admin_url('theme'). "\" class=\"button action\" title=\"Theme Settings\">\n".
			$motor->tools->svg->icon('settings', $depth + 4).
			"$tab\t\t\t\tTheme Settings\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n".
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			// Add update number to Manage Themes button
			"$tab\t\t\t<a href=\"". $motor->admin_url('themes'). "\" class=\"button\" title=\"Manage installed Themes\">\n".
			$motor->tools->svg->icon('shopping-bag', $depth + 4).
			"$tab\t\t\t\tManage Themes\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n".
			"$tab\t</div>\n".
			($motor->settings->admin_management ?
			"$tab\t<div id=\"pm-admin-admin-themes\" class=\"pm-ui-flex-item pm-admin-module\">\n".
			"$tab\t\t<h4>Admin Themes</h4>\n".
			"$tab\t\t<p class=\"small\">Change Admin Theme settings and manage installed Admin Themes</p>\n".
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			"$tab\t\t\t<a href=\"". $motor->admin_url('admin-theme'). "\" class=\"button action\" title=\"Admin Theme Settings\">\n".
			$motor->tools->svg->icon('settings', $depth + 4).
			"$tab\t\t\t\tAdmin Theme Settings\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n".
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			// Add update number to Manage Admin Themes button
			"$tab\t\t\t<a href=\"". $motor->admin_url('admin-themes'). "\" class=\"button\" title=\"Manage installed Admin Themes\">\n".
			$motor->tools->svg->icon('shopping-bag', $depth + 4).
			"$tab\t\t\t\tManage Admin Themes\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n".
			"$tab\t</div>\n" : '').
			"$tab\t<div id=\"pm-admin-settings\" class=\"pm-ui-flex-item pm-admin-module\">\n".
			"$tab\t\t<h4>Site Settings</h4>\n".
			"$tab\t\t<p class=\"small\">Set your Site Title, manage Admin access, and more</p>\n".
			"$tab\t\t<p class=\"pm-ui-buttons\">\n".
			"$tab\t\t\t<a href=\"". $motor->admin_url('settings'). "\" class=\"button action\" title=\"Manage site settings\">\n".
			$motor->tools->svg->icon('settings', $depth + 4).
			"$tab\t\t\t\tSite Settings\n".
			"$tab\t\t\t</a>\n".
			"$tab\t\t</p>\n".
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

	public function _content($admin, $depth = 0) {
		if (empty($_POST) || empty($_POST['content_type']))
			return
				$this->_select_content_type($admin, $depth);
		elseif (empty($_POST['edit_content']))
			return
				$this->_select_content($admin, $depth);
		else
			return
				$this->_edit_content($admin, $depth);
	}

	protected function _select_content_type($admin, $depth = 0) {
		global $motor;
		$list = '';
		$tab = str_repeat("\t", $depth);
		$environment = $admin ? 'admin' : 'theme';
		foreach ($motor->content->types as $id => $type)
			if (!empty($type['environment']) && in_array($environment, $type['environment']) && empty($type['hide-ui']))
				$list .=
					"$tab\t<li>\n".
					"$tab\t\t<form class=\"manage-content-type\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}\" enctype=\"multipart/form-data\">\n".
					"$tab\t\t\t<input type=\"hidden\" name=\"content_type\" value=\"$id\" />\n".
					"$tab\t\t\t<button type=\"submit\" class=\"manage-content-submit\">". $motor->text($type['name'], 'inline-no-links'). "</button>\n".
					"$tab\t\t</form>\n".
					"$tab\t</li>\n";
		return
			"$tab<h2>". ($admin ? 'Admin ' : ''). "Content Types</h2>\n".
			"$tab<ul class=\"select-vert\">\n".
			$list.
			"$tab</ul>\n";
	}

	public function _select_content($admin, $depth = 0) {
		global $motor;
		$live = array();
		$count = array(
			'live' => 0,
			'draft' => 0,
			'trash' => 0);
		$add_new = true;
		$tab = str_repeat("\t", $depth);
		$type = !empty($_POST) && !empty($_POST['content_type']) ? $_POST['content_type'] : 'page';
		$status = $motor->content->has_status($type);
		$name = !empty($motor->content->types[$type]['name']) ? $motor->content->types[$type]['name'] : ucfirst($type);
		$all = $motor->content->get_where(array('type' => $type), $admin);
		if (!empty($all))
			foreach ($all as $entry)
				if (!empty($entry['status'])) {
					if ($entry['status'] === 'live')
						$live[] = $entry;
					$count[$entry['status']] = $count[$entry['status']] + 1;
				}
		$content = $motor->content->get_hierarchy(false, $type, $admin);
		if (!empty($content) && !empty($motor->content->types[$type]['limit']) && count($content) >= $motor->content->types[$type]['limit'])
			$add_new = false;
		return
			"$tab<div id=\"content-manager\" data-type=\"$type\" data-admin=\"$admin\" data-depth=\"$depth\">\n".
			"$tab\t<div class=\"pm-ui-title-controls\">\n".
			"$tab\t\t<h2>Select $name</h2>\n".
			($add_new ?
			"$tab\t\t<button id=\"content-new\" class=\"action\" data-type=\"$type\" data-admin=\"$admin\" data-depth=\"$depth\" title=\"Create new $name\">\n".
			$motor->tools->svg->icon('plus-circle', $depth + 3).
			"$tab\t\t\tCreate new $name\n".
			"$tab\t\t</button>\n" : '').
			"$tab\t</div>\n".
			($status ?
			"$tab\t<div class=\"content-status-select callout\">\n".
			"$tab\t\t<strong>View:</strong>\n".
			"$tab\t\t<a href=\"\" data-status=\"live\" class=\"content-status content-status-live active\">All (<span class=\"content-count\">". ($count['live'] + $count['draft']). "</span>)</a>\n".
			"$tab\t\t<a href=\"\" data-status=\"draft\" class=\"content-status content-status-draft\">Drafts (<span class=\"content-count\">{$count['draft']}</span>)</a>\n".
			"$tab\t\t<a href=\"\" data-status=\"trash\" class=\"content-status content-status-trash\">Trash (<span class=\"content-count\">{$count['trash']}</span>)</a>\n".
			"$tab\t</div>\n" : '').
			"$tab\t<div id=\"content-select\">\n".
			"$tab\t\t<ul class=\"select-vert\">\n".
			$this->_select_content_forms($type, $content, 'live', $admin, $depth + 3).
			"$tab\t\t</ul>\n".
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

	public function _select_content_forms($type, $content, $status = 'live', $admin = false, $depth = 0) {
		global $motor;
		$list = '';
		if (empty($content))
			return $list;
		$tab = str_repeat("\t", $depth);
		$trash = $motor->content->has_trash($type);
		foreach ($content as $id => $item) {
			$title = !empty($item['title']) ? $motor->text($item['title'], 'inline-no-links') : $this->_no_title;
			$url = $motor->content->get_url($type, $id, $admin);
			$parent = false;
			if ($status === 'draft' && !empty($item['parent'])) {
				$parent = $motor->content->get_by_id($item['parent'], $admin);
				$parent = !empty($parent['title']) ? $motor->text($parent['title'], 'inline-no-links') : $this->_no_title;
			}
			$list .=
				"$tab<li class=\"content-manage\">\n".
				"$tab\t<form class=\"content-edit\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}\" enctype=\"multipart/form-data\">\n".
				"$tab\t\t<input type=\"hidden\" name=\"edit_content\" value=\"1\">\n".
				"$tab\t\t<input type=\"hidden\" name=\"id\" value=\"$id\">\n".
				"$tab\t\t<input type=\"hidden\" name=\"content_type\" value=\"$type\">\n".
				"$tab\t\t<button type=\"submit\" class=\"content-edit-submit\">$title</button>\n".
				($status === 'live' && !empty($item['status']) && $item['status'] === 'draft' ?
				"$tab\t\t<span class=\"content-draft\">Draft</span>\n" : '').
				(!empty($parent) ?
				"$tab\t\t<span class=\"content-parent\"><strong>Parent:</strong> $parent</span>\n" : '').
				(!empty($url) ?
				"$tab\t\t<a href=\"$url\" class=\"content-control content-view button action\" target=\"_blank\" rel=\"noopener noreferrer\">\n".
				$motor->tools->svg->icon('external-link', $depth + 3).
				"$tab\t\t\tView\n".
				"$tab\t\t</a>\n" : '').
				($trash && $status !== 'trash' ?
				"$tab\t\t<span class=\"content-control content-trash button delete\">\n".
				$motor->tools->svg->icon('trash', $depth + 3).
				"$tab\t\t\tTrash\n".
				"$tab\t\t</span>\n" : '').
				($status === 'trash' ?
				"$tab\t\t<span class=\"content-control content-restore button save\">\n".
				$motor->tools->svg->icon('rotate-left', $depth + 3).
				"$tab\t\t\tRestore\n".
				"$tab\t\t</span>\n".
				"$tab\t\t<span class=\"content-control content-delete button delete\">\n".
				$motor->tools->svg->icon('x-square', $depth + 3).
				"$tab\t\t\tDelete Forever\n".
				"$tab\t\t</span>\n" : '').
				"$tab\t</form>\n".
				(!empty($item['descendants']) ?
				"$tab\t<ul>\n".
				$this->_select_content_forms($type, $item['descendants'], $status, $admin, $depth + 2).
				"$tab\t</ul>\n" : '').
				"$tab</li>\n";
		}
		return $list;
	}

	public function _create_new_content() {
		echo $this->_edit_content($_POST['admin'], $_POST['depth']);
	}

	public function _content_by_status() {
		global $motor;
		if (empty($_POST['content_type']) || empty($_POST['status']))
			return;
		$type = $_POST['content_type'];
		$status = $_POST['status'];
		$depth = !empty($_POST['depth']) ? $_POST['depth'] : 0;
		if (in_array($status, array('draft', 'trash'))) {
			$content = $motor->content->get_where(array('type' => $type, 'status' => $status), !empty($_POST['admin']));
			if (empty($content))
				return false;
			$list = $sort = array();
			foreach ($content as $item)
				if (!empty($item['id'])) {
					$list[$item['id']] = $item;
					$sort[$item['id']] = !empty($item['title']) ? $item['title'] : $this->_no_title;
				}
			asort($sort);
			$content = array();
			foreach ($sort as $id => $title)
				$content[$id] = $list[$id];
		}
		elseif ($status === 'live')
			$content = $motor->content->get_hierarchy(false, $type, !empty($_POST['admin']));
		else
			return;
		$tab = str_repeat("\t", $depth);
		echo
			"$tab\t\t<ul class=\"select-vert\">\n".
			$this->_select_content_forms($type, $content, $status, !empty($_POST['admin']), $depth + 3).
			"$tab\t\t</ul>\n";
	}

	public function _trash_content() {
		global $motor;
		if (empty($_POST['id']))
			return;
		$content = $motor->content->get_by_id($_POST['id'], !empty($_POST['admin']));
		if (empty($content))
			return;
		$content['status'] = 'trash';
		$motor->content->update($content, !empty($_POST['admin']));
		echo true;
	}

	public function _restore_content() {
		global $motor;
		if (empty($_POST['id']))
			return;
		$content = $motor->content->get_by_id($_POST['id'], !empty($_POST['admin']));
		if (empty($content))
			return;
		$content['status'] = 'draft';
		$motor->content->update($content, !empty($_POST['admin']));
		echo true;
	}

	public function _delete_content() {
		global $motor;
		if (empty($_POST['id']))
			return;
		$motor->content->delete($_POST['id'], !empty($_POST['admin']));
		echo true;
	}

	public function _edit_content($admin = false, $depth = 0) {
		global $motor;
/*		Need a way to examine the current content type to see which features/options are supported.
		Each content option can be examined to see if it works with the current page type.
		Title and Content should be universal, but Slug only applies to content with a URL endpoint. */
		$user = false;	// Set to active user
		$update_gmt = false;
		$values = $options_values = array();
		$id = !empty($_POST['id']) ? $_POST['id'] : false;
		$new = !empty($_POST['new']) ? $_POST['new'] : false;
		$type = !empty($_POST['content_type']) ? $_POST['content_type'] : 'page';
		$tab = str_repeat("\t", $depth);
		if (empty($id) && empty($new))
			return
				"$tab<form class=\"no-content-selected\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}\" enctype=\"multipart/form-data\">\n".
				"$tab\t<input type=\"hidden\" name=\"content_type\" value=\"$type\" />\n".
				"$tab\t<p>No content was selected for editing!</p>\n".
				"$tab\t<p><button class=\"button action\">&larr; Back to content</button></p>\n".
				"$tab</form>\n";
		if ($new) {
			// Draft status should only be set if the content type has a URL and no-slug is empty!
			$motor->content->update(array(
				'type' => $type), $admin);
			$id = $motor->db->connection->insert_id;
			$motor->content->update(array(
				'id' => $id,
				'date_gmt' => ($values['date_gmt'] = gmdate($motor->db->date_format)),
				'slug' => ($values['slug'] = $motor->content->check_slug($id, "$type-$id", false, $admin)),
				'status' => $motor->content->has_status($type) ? 'draft' : 'live',
				'type' => $type));
			// Ensure default UI status is 'live' and not 'draft' (requires one less action for the most likely preferred outcome)
			$values['status'] = 'live';
		}
		else {
			$values = $motor->content->get_by_id($id, $admin);
			$options_values = $motor->content->get_options($id, $admin);
			$update_gmt = true;
		}
		$name = !empty($motor->content->types[$type]['name']) ?
			$motor->content->types[$type]['name'] : ucfirst($type);
		return
			$motor->tools->ui->admin_options_form(array(
				'title' => ($new ? 'Create New' : 'Edit'). " $name",
				'name' => $name,
				'docs' => $this->admin_docs['edit-content'],
				'id' => 'content-edit',
				'form' =>
					$motor->tools->form->fields($motor->content->core_fields($type, $id, $admin), $values, '_', false, $depth + 1).
					$motor->content->options_form($type, $options_values, $depth + 1),
				'hidden' => array(
					'admin' => $admin,
					'classes_editor' => $admin ? $motor->admin->_body_classes_editor() : $motor->theme->_body_classes_editor(),
					'id' => $id,
					'type' => $type,
					'sub_type' => !empty($values['sub_type']) ? $values['sub_type'] : false,
					'date_gmt' => !empty($values['date_gmt']) ? $values['date_gmt'] : false,
					'update_gmt' => $update_gmt,
//					'author' => isset($values['author']) ? $values['author'] : $user,
					/*'user' => */),
				'depth' => $depth,
				'save_icon' => 'check-circle'));
	}

	public function _update_url() {
		global $motor;
		if (empty($_POST['id']) || empty($_POST['type']))
			return false;
		// Auto slug already includes check slug; check slug only necessary if slug is not empty
		$slug = empty($_POST['slug']) ?
			$motor->content->auto_slug($_POST['id'], $_POST['type'], !empty($_POST['parent']) ? $_POST['parent'] : false, !empty($_POST['admin'])) :
			$motor->content->check_slug($_POST['id'], $_POST['slug'], !empty($_POST['parent']) ? $_POST['parent'] : false, !empty($_POST['admin']));
		echo
			(!empty($_POST['admin']) ? $motor->admin_url : $motor->site_url).
			$motor->content->get_new_path($slug, !empty($_POST['parent']) ? $_POST['parent'] : false, !empty($_POST['admin']));
	}

	protected function _save_content() {
		global $motor;
		parse_str(stripslashes($_POST['form']), $form);
		$type_name = !empty($form['type']) && !empty($motor->content->types[$form['type']]['name']) ?
			$motor->content->types[$form['type']]['name'] : ucfirst($form['type']);
		if (!empty($form['id']) && !empty($form['type'])) {
			if (empty($form['title'])) {
				echo json_encode(array(
					'status' => 'error',
					'element' => '#_title',
					'message' => $motor->tools->ui->alert('NOT saved: Title required!', 'content-saved', true)));
			}
			else {
				if (empty($form['status']) && !$motor->content->has_status($form['type']))
					$form['status'] = 'live';
				$update_slug = false;
				$slug = empty($form['slug']) ?
					$motor->content->auto_slug($form['id'], $form['type'], !empty($form['parent']) ? $form['parent'] : false, !empty($form['admin'])) :
					$motor->content->check_slug($form['id'], !empty($form['slug']) ? $form['slug'] : false, !empty($form['parent']) ? $form['parent'] : false, !empty($form['admin']));
				if (!empty($form['slug']) && $slug !== $form['slug'])
					$form['slug'] = $update_slug = $slug;
				if (isset($_POST['content']))
					$form['content'] = $_POST['content'];
				if (!empty($form['update_gmt']))
					$form['modified_gmt'] = gmdate($motor->db->date_format);
				$motor->content->update($form, !empty($form['admin']));
				$motor->content->update_options($form['id'], $form['type'], $form, !empty($form['admin']));
				echo json_encode(array(
					'status' => 'saved',
					'update_slug' => $update_slug,
					'message' => $motor->tools->ui->alert("$type_name saved!", 'content-saved', true)));
			}
		}
		else
			echo json_encode(array(
				'status' => 'error',
				'message' => $motor->tools->ui->alert("$type_name NOT saved!", 'content-saved', true)));
	}

	public function _plugins($depth = 0) {
		global $motor;
		return
			$motor->plugins->admin($depth);
	}

	public function _save_plugins() {
		global $motor;
		if ($motor->plugins->save())
			echo $motor->tools->ui->alert('Plugins saved!', 'plugins-saved', true);
		else
			echo $motor->tools->ui->alert('Plugins NOT saved!', 'plugins-saved', true);
	}

	public function _themes($admin = false, $depth = 0) {
		global $motor;
		return
			$motor->themes->admin($admin, $depth);
	}

	public function _settings($depth = 0) {
		global $motor;
		return
			$motor->settings->admin($depth);
	}

	public function _save_settings() {
		global $motor;
		if ($motor->settings->save())
			echo $motor->tools->ui->alert('Settings saved!', 'options-saved', true);
		else
			echo $motor->tools->ui->alert('Settings NOT saved!', 'options-saved', true);
	}

	protected function _seed_content() {
		global $motor;
		if ($motor->options->option($this->_seed_content))
			return;
		// Home: Add content to DB and then set admin_home option to the ID that was just inserted
		$home = $motor->content->get_where(array('type' => 'home'), $this->_admin_theme);
		if (empty($home)) {
			$motor->content->update(
				array_merge($motor->seed->admin_content['home'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
			$motor->options->update($motor->page->admin_home, $motor->db->connection->insert_id);
		}
		// Content: Add content to DB
		$content = $motor->content->get_where(array('type' => 'admin-content', 'slug' => 'content'), $this->_admin_theme);
		if (empty($content))
			$motor->content->update(
				array_merge($motor->seed->admin_content['content'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
		// Admin Content: Add content to DB
		$admin_content = $motor->content->get_where(array('type' => 'admin-content', 'slug' => 'admin-content'), $this->_admin_theme);
		if (empty($admin_content))
			$motor->content->update(
				array_merge($motor->seed->admin_content['admin-content'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
		// Plugins: Add content to DB
		$plugins = $motor->content->get_where(array('type' => 'admin-plugins'), $this->_admin_theme);
		if (empty($plugins))
			$motor->content->update(
				array_merge($motor->seed->admin_content['plugins'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
		// Themes: Add content to DB
		$themes = $motor->content->get_where(array('type' => 'admin-themes', 'slug' => 'themes'), $this->_admin_theme);
		if (empty($themes))
			$motor->content->update(
				array_merge($motor->seed->admin_content['themes'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
		// Admin Themes: Add content to DB
		$admin_themes = $motor->content->get_where(array('type' => 'admin-themes', 'slug' => 'admin-themes'), $this->_admin_theme);
		if (empty($admin_themes))
			$motor->content->update(
				array_merge($motor->seed->admin_content['admin-themes'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
		// Theme UI: Add to DB and then use the previously-inserted ID as the parent for Theme UI sub-pages
		// Only set subs if Theme UI page did not exist before
		$theme = $motor->content->get_where(array('type' => 'admin-theme', 'slug' => 'theme'), $this->_admin_theme);
		if (empty($theme)) {
			$motor->content->update(
				array_merge($motor->seed->admin_content['theme'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
			$theme_parent = $motor->db->connection->insert_id;
			foreach ($motor->seed->theme_ui as $ui)
				$motor->content->update(
					array_merge($ui, array('date_gmt' => gmdate($motor->db->date_format), 'parent' => $theme_parent)),
					$this->_admin_theme);
		}
		// Admin Theme UI: Add to DB and then use the previously-inserted ID as the parent for Admin Theme UI sub-pages
		$admin_theme = $motor->content->get_where(array('type' => 'admin-theme', 'slug' => 'admin-theme'), $this->_admin_theme);
		if (empty($admin_theme)) {
			$motor->content->update(
				array_merge($motor->seed->admin_content['admin-theme'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
			$admin_theme_parent = $motor->db->connection->insert_id;
			foreach ($motor->seed->theme_ui as $ui)
				$motor->content->update(
					array_merge($ui, array('date_gmt' => gmdate($motor->db->date_format), 'parent' => $admin_theme_parent)),
					$this->_admin_theme);
		}
		$error = $motor->content->get_where(array('type' => 'error'), $this->_admin_theme);
		if (empty($error))
			$motor->content->update(array_merge($motor->seed->admin_content['error'], array('date_gmt' => gmdate($motor->db->date_format))), $this->_admin_theme);
		// Admin Settings: Add to DB
		$admin_themes = $motor->content->get_where(array('type' => 'admin-settings', 'slug' => 'settings'), $this->_admin_theme);
		if (empty($admin_themes))
			$motor->content->update(
				array_merge($motor->seed->admin_content['settings'], array('date_gmt' => gmdate($motor->db->date_format))),
				$this->_admin_theme);
		// Set the seed option to true once content is seeded
		$motor->options->update($this->_seed_content, 1);
	}
}