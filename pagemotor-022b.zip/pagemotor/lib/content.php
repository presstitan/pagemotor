<?php
/**
 * PageMotor Content Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Content
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Content {
	public $options = array();
	public $table = 'content';
	public $table_options = 'content_options';
	public $table_admin = 'admin_content';
	public $table_admin_options = 'admin_content_options';
	public $content = array(
		'id' => NULL,
		'date_gmt' => NULL,
		'modified_gmt' => NULL,
		'title' => false,
		'content' => false,
		'slug' => false,
		'parent' => 0,
		'author' => 1,
		'status' => 'live',
		'type' => false,		// default type should probably be empty in $motor->db table setup
		'sub_type' => false);
	public $core = array(
		'title' => array(
			'type' => 'text',
			'width' => 'full',
			'label' => 'Title',
			'required' => '*'),
		'content' => array(
			'type' => 'textarea'),
		'parent' => array(
			'type' => 'select',
			'description' => 'Parent',
			'integer' => 0,
			'options' => array(
				'' => 'No parent selected')),
		'slash' => array(
			'type' => 'custom',
			'html' => '<span class="url-helper">/</span>'),
		'slug' => array(
			'type' => 'text',
			'width' => 'medium',
			'code' => true,
			'description' => 'URL Slug'),
		'arrow' => array(
			'type' => 'custom',
			'html' => '<span class="url-helper">→</span>'),
		'url' => array(
			'type' => 'custom',
			'html' => ''),
		'status' => array(
			'type' => 'select',
			'options' => array(
				'live' => 'Live',
				'draft' => 'Draft',
				'trash' => 'Trash')),
		'author' => array(
			'type' => 'select',
			'label' => 'Author',
			'integer' => 1,
			'options' => array()));
	public $types = array(
		'home' => array(
			'name' => 'Home',
			'environment' => array('admin', 'theme'),
			'url' => true,
			'no-slug' => true,
			'limit' => 1,
			'fields' => array('title', 'content')),
		'page' => array(
			'name' => 'Page',
			'environment' => array('admin', 'theme'),
			'url' => true,		// true if this content type has a URL endpoint
			'fields' => array('title', 'page-url', 'content', 'status'),
			'groups' => array(
				'page-url' => array('parent', 'slash', 'slug', 'arrow', 'url', 'author'))),
		'error' => array(
			'name' => '404 Page',
			'environment' => array('admin', 'theme'),
			'url' => true,
			'no-slug' => true,
			'limit' => 1,
			'fields' => array('title', 'content')));

	public function add_types($types = array()) { //$id, $type) {
		if (empty($types) || !is_array($types))
			return;
		foreach ($types as $id => $type)
			if (empty($this->types[$id]))
				$this->types[$id] = $type;
/*		if (empty($id) || !is_array($type) || empty($type) || !empty($this->types[$id]))
			return;
		$this->types[$id] = $type;*/
	}

	// Need to protect against identical slugs at the base level
	public function update($content, $admin = false) {
		global $motor;
		if (empty($content))
			return;
		$udpate = $this->content;
		foreach ($this->content as $field => $default)
			$update[$field] = !empty($content[$field]) ? $content[$field] : $default;
		return
			$motor->db->connection->prepare("INSERT INTO ". $motor->db->prefix. ($admin ? $this->table_admin : $this->table). " (id, date_gmt, modified_gmt, title, content, slug, parent, author, status, type, sub_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE date_gmt = VALUES(date_gmt), modified_gmt = VALUES(modified_gmt), title = VALUES(title), content = VALUES(content), slug = VALUES(slug), parent = VALUES(parent), author = VALUES(author), status = VALUES(status), type = VALUES(type), sub_type = VALUES(sub_type)")->execute(array_values($update));
	}

	public function update_options($id, $type, $form, $admin = false) {
		global $motor;
		$save = array();
		if (empty($id) || empty($type) || empty($form))
			return;
		foreach ($this->options as $class => $options)
			if (!empty($options['fields']) && (!empty($options['types']) && is_array($options['types']) && in_array($type, $options['types']))) {
				$set = $motor->options->set($options['fields'], $form[$class]);
				$save[$class] = !empty($set) ?
					$motor->db->connection->real_escape_string(json_encode($set)) : array();
			}
		foreach ($save as $class => $values) {
			$table = $motor->db->prefix. ($admin ? $this->table_admin_options : $this->table_options);
			if (!empty($values)) {
				$exists = $motor->db->get_rows("SELECT * FROM $table WHERE content_id = $id AND name = '$class'");
				if (count($exists) > 0)
					$motor->db->query("UPDATE $table SET value = '$values' WHERE content_id = $id AND name = '$class'");
				else
					$motor->db->query("INSERT INTO $table (content_id, name, value) VALUES ($id, '$class', '$values')");
			}
			else
				$motor->db->query("DELETE FROM $table WHERE content_id = $id AND name = '$class'");
		}
	}

	public function delete($id, $admin = false) {
		global $motor;
		if (empty($id))
			return;
		$motor->db->query("DELETE FROM ". $motor->db->prefix. ($admin ? $this->table_admin : $this->table). " WHERE id = $id");
		echo true;
	}

	public function get_all($admin = false) {
		global $motor;
		$table = $admin ? $this->table_admin : $this->table;
		return $motor->db->get_rows("SELECT * FROM {$motor->db->prefix}{$table}");
	}

	public function get_where($conditions, $admin = false) {
		global $motor;
		if (empty($conditions))
			return array();
		$where = array();
		foreach ($conditions as $key => $value)
			$where[] = "$key = '$value'";
		$where = implode(' AND ', $where);
		$table = $admin ? $this->table_admin : $this->table;
		return $motor->db->get_rows("SELECT * FROM {$motor->db->prefix}{$table} WHERE $where");
	}

	public function get_by_id($id, $admin = false) {
		if (empty($id))
			return array();
		$results = $this->get_where(array('id' => $id), $admin);
		return count($results) === 1 ?
			$results[0] : array();
	}

	public function get_options($id, $admin = false) {
		global $motor;
		$options = array();
		if (empty($id))
			return $options;
		$table = $admin ? $this->table_admin_options : $this->table_options;
		$results = $motor->db->get_rows("SELECT name, value FROM {$motor->db->prefix}{$table} WHERE content_id = $id");
		if (count($results) > 0)
			foreach ($results as $result)
				if (!empty($result['name']) && array_key_exists($result['name'], $this->options) && !empty($result['value'])) {
					if ((function_exists('json_validate') && json_validate($result['value']) === true) || $motor->tools->is_json($result['value'])) 
						$options[$result['name']] = json_decode($result['value'], true);
					else
						$options[$result['name']] = $result['value'];
				}
		return $options;
	}

	public function core_fields($type, $id, $admin = false) {
		global $motor;
		$fields = array();
		if (empty($type) || !array_key_exists($type, $this->types) || empty($this->types[$type]['fields']) || empty($id))
			return $fields;
		foreach ($this->types[$type]['fields'] as $field) {
			$add = $this->fill_core_field($field, $type, $id, $admin);
			if ($add)
				$fields[$field] = $add;
			elseif (!empty($this->types[$type]['groups']) && !empty($this->types[$type]['groups'][$field])) {
				if (empty($fields[$field]))
					$fields[$field] = array(
						'type' => 'group',
						'class' => "group-$field",
						'fields' => array());
				foreach ($this->types[$type]['groups'][$field] as $grouped_field) {
					$add_grouped_field = $this->fill_core_field($grouped_field, $type, $id, $admin);
					if ($add_grouped_field)
						$fields[$field]['fields'][$grouped_field] = $add_grouped_field;
				}
			}
		}
		return $fields;
	}

	public function fill_core_field($field, $type, $id, $admin = false) {
		global $motor;
		if (!array_key_exists($field, $this->core))
			return false;
		$content = false;	// May be able to remove this once author is resolved (but maybe not)
		if ($field === 'parent' && !empty($this->types[$type]['url'])) {
			$parents = $this->get_hierarchy(false, false, $admin);
			$options = $this->parent_options($id, $parents, array());
			$this->core[$field]['options'] = array('' => 'No parent selected') + $options;
		}
		elseif ($field === 'url') {		// Populate 'html' index with the PageMotor URL root
			$content = $this->get_by_id($id, $admin);
			$path = !empty($content['slug']) ? "{$content['slug']}/" : false;
			if (!empty($content['parent']))
				$path = $this->get_path($content['parent'], $path, $admin);
			$url = $admin ? $motor->admin_url($path) : $motor->url($path);
			$this->core[$field]['html'] = "<div id=\"page-url\"><a href=\"". $motor->url_escape($url). "\" title=\"Visit this page\" target=\"_blank\" rel=\"noopener noreferrer\">$url</a></div>";
		}
/*		elseif ($field === 'status') {
			if (empty($content))
				$content = $this->get_by_id($id, $admin);
			if (!empty($content['status']) && $content['status'] === 'draft')
				$this->core[$field]['draft'] = true;
		}*/
		elseif ($field === 'author') {
			// Admin, Staff, User
			// Search the users table for anyone with an access level of Admin or Staff
/*					$items = $motor->db->get_users_where("type = 'admin' OR type = 'staff'");
			if (is_array($items))
				foreach ($items as $item)
					$this->fields[$field]['options'][$item['id']] = !empty($item['name']) ? $item['name'] : $item['username'];*/
		}
		return $this->core[$field];
	}

	public function get_hierarchy($parent = false, $type = false, $admin = false) {
		global $motor;
		$hierarchy = array();
		$where = array('parent' => $parent);
		if (!empty($type))
			$where['type'] = $type;
		$content = $this->get_where($where, $admin);
		if (is_array($content))
			foreach ($content as $item)
				if (!empty($item['type']) && /*!empty($this->types[$item['type']]['url']) &&*/ (!empty($item['slug']) || (!empty($type) && !empty($this->types[$item['type']]['no-slug']))) && $item['status'] !== 'trash') {
					$hierarchy[$item['id']] = array(
						'title' => !empty($item['title']) ? $item['title'] : false,
						'parent' => $item['parent'],
						'status' => $item['status']);
					$hierarchy[$item['id']]['descendants'] = $this->get_hierarchy($item['id'], $type, $admin);
				}
		return $motor->tools->sort_by($hierarchy, 'title', true);
	}

	public function parent_options(int $id, $parents, $options = array(), $level = 0) {
		global $motor;
		foreach ($parents as $parent_id => $parent)
			if ($parent_id !== $id) {
				$options[$parent_id] = (!empty($level) ? str_repeat('—', $level). ' ' : false). $motor->text($parent['title'], 'no-html');
				if (!empty($parent['descendants']))
					$options = $this->parent_options($id, $parent['descendants'], $options, $level + 1);
			}
		return $options;
	}

/*	public function url($content, $admin = false) {
		global $motor;
		if (empty($content) || empty($content['id']) || empty($content['type']))
			return false;
		$base = $admin ? $motor->admin_url : $motor->site_url;
		if (empty($this->types[$content['type']]['url']))
			return false;
		elseif (!empty($this->types[$content['type']]['no-slug'])) {
			if ($content['type'] === 'home')
				return $base;
			else
				return false;
		}
		$path = !empty($content['slug']) ? "{$content['slug']}/" : '';
		if (empty($content['parent']))
			return $base. $path;
		else
			return $base. $this->get_path($content['parent'], $path, $admin);
	}*/

	public function get_url($type, $id, $admin = false) {
		global $motor;
		$base = $admin ? $motor->admin_url : $motor->site_url;
		if (empty($this->types[$type]['url']))
			return false;
		elseif (!empty($this->types[$type]['no-slug'])) {
			if ($type === 'home')
				return $base;
			else
				return false;
		}
		return $base. $this->get_path($id, false, $admin);
	}

	public function get_path($id, $path = false, $admin = false) {
		$content = $this->get_by_id($id, $admin);
		$path = "{$content['slug']}/$path";
		if (!empty($content['parent']))
			$path = $this->get_path($content['parent'], $path, $admin);
		return $path;
	}

	public function get_new_path($slug, $parent, $admin = false) {
		if (empty($slug))
			return false;
		$path = "$slug/";
		return empty($parent) ?
			$path :
			$this->get_path($parent, $path, $admin);
	}

	public function auto_slug($id, $type, $parent, $admin = false) {
		$content = $this->get_by_id($id, $admin);
		return !empty($content) && !empty($content['slug']) ?
			$this->check_slug($id, $content['slug'], $parent, $admin) :
			$this->check_slug($id, "$type-$id", $parent, $admin);
	}

	public function check_slug($id, $slug, $parent, $admin = false, $count = 2) {
		$content = $this->get_where(array('slug' => $slug, 'parent' => $parent), $admin);
		// Need to make sure the slug doesn't change if the only match is the content itself (existing ID)
		if (!empty($content)) {
			if (count($content) === 1 && $content[0]['id'] === $id)
				return $slug;
			else
				return $this->check_slug($id, rtrim($slug, '-'. $count - 1). "-$count", $parent, $admin, $count + 1);
		}
		else
			return $slug;
	}

	public function ancestors($path, $ancestors = array()) {
		$path = rtrim($path, '/');
		if (empty($path))
			return false;
		$slug = basename($path);
		$ancestors[] = $slug;
		$path = rtrim($path, $slug);
		return strlen($path) == 1 && $path == '/' ?
			array_reverse($ancestors) :
			$this->ancestors($path, $ancestors);
	}

/*	public function sort_hierarchy($content, $type, $hierarchy = array(), $admin = false) {
		if (empty($hierarchy))
			$hierarchy = array();
		if (empty($content) || empty($type))
			return $hierarchy;
		foreach ($content as $index => $entry)
			if (!empty($entry['id'])) {
				if (empty($entry['parent'])) {
					$hierarchy["$type-{$entry['id']}"] = $entry;
					unset($content[$index]);
				}
				else
			}
	}*/

	public function has_status($type) {
		return !empty($this->types[$type]) && !empty($this->types[$type]['url']) && empty($this->types[$type]['no-slug']) ? true : false;
	}

	public function has_trash($type) {
		return !empty($this->types[$type]) && (empty($this->types[$type]['url']) || (!empty($this->types[$type]['url']) && empty($this->types[$type]['no-slug']))) ? true : false;
	}

	public function save($fields, $form, $type) {
		global $motor;
		$save = array();
		if (empty($fields) || empty($form) || empty($type))
			return $save;
		$save = $motor->options->set($fields, $form);
		
		foreach ($fields as $name)
			if (isset($this->core[$name]['integer']) && empty($form[$name]))
				$save[$name] = $this->core[$name]['integer'];
			else
				$save[$name] = !empty($form[$name]) ? $motor->db->connection->real_escape_string($form[$name]) : false;
		return $save;
	}

	public function options_form($type, $values = array(), $depth = 0) {
		global $motor;
		$form = false;
		if (empty($type) || empty($this->options))
			return $form;
		$tab = str_repeat("\t", $depth);
		$this->options = $motor->tools->sort_by($this->options, 'order', true);
		// May need to make a provision for groups or other types of options (tabbed UI, etc)
		foreach ($this->options as $class => $options)
			if (!empty($options['fields']) && (!empty($options['types']) && is_array($options['types']) && in_array($type, $options['types'])))
				// Add in title and other UI modes
				$form .=
					"$tab\t<div class=\"content-options-group\">\n".
					$motor->tools->form->fields($options['fields'], !empty($values[$class]) ? $values[$class] : array(), "{$class}_", $class, $depth + 2).
					"$tab\t</div>\n";
		return
			"$tab<div class=\"content-options-groups\">\n".
			$form.
			"$tab</div>\n";
	}

	public function save_options($form, $type) {
		global $motor;
		$save = array();
		if (empty($form) || empty($type))
			return $save;
		foreach ($this->options as $class => $options)
			if (!empty($options['fields']) && (!empty($options['types']) && is_array($options['types']) && in_array($type, $options['types'])))
				$save[$class] = !empty($form[$class]) ?
					$motor->options->set($options['fields'], $form[$class]) : false;
		return $save;
	}
}