<?php
/**
 * PageMotor Database Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Content
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_DB {
	public $connection = false;					// [object] MySQLi connection
	public $charset = 'utf8mb4';				// [string] database charset
	public $collate = 'utf8mb4_unicode_520_ci';	// [string] database collation
	public $prefix = false;						// [string] database table prefix
	public $date_format = 'Y-m-d H:i:s';		// [string] MySQL date format
	public $tables = array(						// [array] core PageMotor tables
		'admin_content',						// Admin content
		'admin_content_options',				// Admin content options
		'content',								// All content
		'content_options',						// Content options
		'options',								// Site options
		'theme_backups',						// Theme backup data
		'users',								// Users
		'user_options');						// User options

	public function __construct($db) {
		if (empty($db) || empty($db['host']) || empty($db['user']) || empty($db['password']) || empty($db['name']))
			return;
		$this->connection = new mysqli($db['host'], $db['user'], $db['password'], $db['name']);
		if ($this->connection->connect_errno)
			throw new RuntimeException('MySQLi Connection Error: '. $this->connection->connect_error);
		$this->connection->set_charset($this->charset = !empty($db['charset']) ? $db['charset'] : $this->charset);
		$this->collate = !empty($db['collate']) ? $db['collate'] : $this->collate;
		if ($this->connection->errno)
			throw new RuntimeException('MySQLi Error: '. $this->connection->error);
		$this->prefix = !empty($db['prefix']) ? $db['prefix'] : $this->prefix;
		$this->tables();
	}

	// Fetch rows from the db
	// Returns an associative array because that makes a billion times more sense than anything else
	public function get_rows($query) {
		if (empty($query))
			return false;
		$result = $this->query($query);
		return $result->fetch_all(MYSQLI_ASSOC);
	}

	// Fetch cell value from the db (returns a single value)
	public function get_cell($query) {
		if (empty($query))
			return false;
		$result = $this->query($query);
		return !empty($result) && $result->num_rows > 0 ?
			$result->fetch_row()[0] : false;
	}

	// Performs a db query
	public function query($query) {
		if (empty($this->connection) || empty($query))
			return false;
		return $this->connection->query($query);
	}

	private function tables() {
		$exists = false;
		foreach ($this->tables as $table) {
			$exists = $this->query("SHOW TABLES LIKE '{$this->prefix}{$table}'");
			if (mysqli_num_rows($exists) < 1 && $create = "table_$table")
				$this->query($this->$create($table). " DEFAULT CHARACTER SET $this->charset COLLATE $this->collate;");
		}
	}

	private function table_admin_content($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				date_gmt datetime default NULL,
				modified_gmt datetime default NULL,
				title text NOT NULL,
				content longtext NOT NULL,
				slug varchar(191) NOT NULL default '',
				parent bigint(20) unsigned NOT NULL default '0',
				author bigint(20) unsigned NOT NULL default '0',
				status varchar(20) NOT NULL default 'live',
				type varchar(30) NOT NULL default '',
				sub_type varchar(30) NOT NULL default '',
				PRIMARY KEY (id),
				KEY slug(slug(191)),
				KEY parent (parent)
			)";
	}

	private function table_admin_content_options($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				content_id bigint(20) unsigned NOT NULL default '0',
				name varchar(255) default NULL,
				value longtext,
				PRIMARY KEY (id),
				KEY content_id (content_id)
			)";
	}

	private function table_content($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				date_gmt datetime default NULL,
				modified_gmt datetime default NULL,
				title text NOT NULL,
				content longtext NOT NULL,
				slug varchar(191) NOT NULL default '',
				parent bigint(20) unsigned NOT NULL default '0',
				author bigint(20) unsigned NOT NULL default '0',
				status varchar(20) NOT NULL default 'live',
				type varchar(30) NOT NULL default '',
				sub_type varchar(30) NOT NULL default '',
				PRIMARY KEY (id),
				KEY slug (slug(191)),
				KEY parent (parent)
			)";
	}

	private function table_content_options($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				content_id bigint(20) unsigned NOT NULL default '0',
				name varchar(191) default NULL,
				value longtext,
				PRIMARY KEY (id),
				KEY content_id (content_id)
			)";
	}

	private function table_options($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				name varchar(191) default NULL,
				value longtext,
				PRIMARY KEY (id),
				UNIQUE KEY name (name)
			)";
	}

	private function table_theme_backups($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				time bigint(20) NOT NULL,
				theme varchar(191) NOT NULL,
				templates longtext NOT NULL,
				instances longtext NOT NULL,
				css_vars longtext NOT NULL,
				css_includes longtext NOT NULL,
				css_includes_editor longtext NOT NULL,
				css longtext NOT NULL,
				css_editor longtext NOT NULL,
				css_custom longtext NOT NULL,
				design longtext NOT NULL,
				display longtext NOT NULL,
				notes longtext NOT NULL,
				PRIMARY KEY (id)
			)";
	}

	private function table_users($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				username varchar(60) NOT NULL default '',
				password varchar(255) NOT NULL default '',
				email varchar(100) NOT NULL default '',
				date_gmt datetime default NULL,
				PRIMARY KEY (id),
				UNIQUE KEY username (username),
				UNIQUE KEY email (email)
			)";
	}

	private function table_user_options($table) {
		return
			"CREATE TABLE {$this->prefix}$table (
				id bigint(20) unsigned NOT NULL auto_increment,
				user_id bigint(20) unsigned NOT NULL default '0',
				name varchar(191) default NULL,
				value longtext,
				PRIMARY KEY (id),
				KEY user_id (user_id)
			)";
	}
}