<?php
/**
 * PageMotor Error Handler for Pre-template Output
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Error
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Error {
	public function __construct($message = false) {
		global $motor;
		$message = !empty($message) ? $message : 'An unspecified error has occurred.';
		// Need to send headers before outputting HTML!
		echo
			"<!DOCTYPE html>\n".
			"<html>\n".
			"<head>\n".
			"<meta charset=\"utf-8\">\n".
			"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n".
			"<style>\n".
			".container {\n".
			"\tbox-sizing: border-box;\n".
			"\tpadding-left: 18px;\n".
			"\tpadding-right: 18px;\n".
			"}\n".
			"@media all and (min-width: 680px) {\n".
			"\t.container {\n".
			"\t\tmax-width: 644px;\n".
			"\t\tpadding-left: 0;\n".
			"\t\tpadding-right: 0;\n".
			"\t\tmargin-left: auto;\n".
			"\t\tmargin-right: auto;\n".
			"\t}\n".
			"}\n".
			"@media all and (min-width: 702px) {\n".
			"\t.container {\n".
			"\t\tmax-width: 100%;\n".
			"\t\tpadding-left: 29px;\n".
			"\t\tpadding-right: 29px;\n".
			"\t\tmargin-left: 0;\n".
			"\t\tmargin-right: 0;\n".
			"\t}\n".
			"}\n".
			"@media all and (min-width: 1098px) {\n".
			"\t.container {\n".
			"\t\tmax-width: 1040px;\n".
			"\t\tpadding-left: 0;\n".
			"\t\tpadding-right: 0;\n".
			"\t\tmargin-left: auto;\n".
			"\t\tmargin-right: auto;\n".
			"\t}\n".
			"}\n".
			"</style>\n".
			"</head>\n".
			"<body>\n".
			"<div class=\"section\">\n".
			"\t<div class=\"container\">\n".
			"\t\t<div class=\"pm-error\">\n".
			"\t\t\t<h3>Error!</h3>\n".
			"\t\t\t<p>". $motor->text($message, 'inline'). "</p>\n".
			"\t\t</div>\n".
			"\t</div>\n".
			"</div>\n".
			"</body>\n".
			"</html>";
		exit;
	}
}