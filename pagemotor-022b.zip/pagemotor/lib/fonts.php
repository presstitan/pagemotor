<?php
/**
 * PageMotor Font Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Fonts
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Fonts {
	public $google = false;			// [object] Google Fonts controller

	public function __construct() {
		define('PM_FONTS', PM_LIB. '/fonts');
		require_once(PM_FONTS. '/google.php');
		$this->google = new PM_Fonts_Google;
	}

	public function add($fonts = array(), $google = array()) {
		if (!empty($fonts))
			foreach ($fonts as $name => $font)
				if (empty($this->fonts[$name]))
					$this->fonts[$name] = $font;
		$this->google->add($google);
	}

	public function all() {
		return array_merge($this->fonts, $this->google->fonts());
	}

	public function select() {
		$select = array();
		$all = $this->all();
		uksort($all, 'strnatcasecmp');
		foreach ($all as $id => $font)
			$select[$id] = !empty($font['name']) ? $font['name'] : ucfirst($id);
		return $select;
	}

	public function family($font) {
		$all = $this->all();
		return !empty($font) && !empty($all) && !empty($all[$font]) && !empty($all[$font]['family']) ?
			$all[$font]['family'] : false;
	}

	public $fonts = array(
		'Arial' => array(
			'family' => 'Arial, "Helvetica Neue", Helvetica, sans-serif',
			'x' => 0.7209,
			'mu' => 2.26,
			'safe' => 'email'),
		'Courier New' => array(
			'name' => 'Courier New',
			'family' => '"Courier New", Courier, Verdana, sans-serif',
			'x' => 0.7427,
			'mu' => 1.67,
			'monospace' => true,
			'safe' => 'email'),
		'Georgia' => array(
			'family' => 'Georgia, "Times New Roman", Times, serif',
			'x' => 0.6923,
			'mu' => 2.27,
			'safe' => 'email'),
		'System' => array(
			'family' => 'system-ui, BlinkMacSystemFont, Roboto, "Segoe UI", Segoe, "Helvetica Neue", Tahoma, sans-serif',
			'x' => 0.7204,
			'mu' => 2.26,
			'safe' => 'email'),
		'Tahoma' => array(
			'family' => 'Tahoma, Geneva, Verdana, sans-serif',
			'x' => 0.7523,
			'mu' => 2.26,
			'safe' => 'email'),
		'Times New Roman' => array(
			'name' => 'Times New Roman',
			'family' => '"Times New Roman", Times, Georgia, serif',
			'x' => 0.6734,
			'mu' => 2.48,
			'safe' => 'email'),
		'Trebuchet MS' => array(
			'name' => 'Trebuchet MS',
			'family' => '"Trebuchet MS", "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", Arial, sans-serif',
			'x' => 0.7290,
			'mu' => 2.2,
			'safe' => 'email'),
		'Verdana' => array(
			'family' => 'Verdana, sans-serif',
			'x' => 0.7523,
			'mu' => 1.96,
			'safe' => 'email'),
		'Arial Black' => array(
			'name' => 'Arial Black',
			'family' => '"Arial Black", "Arial Bold", Arial, sans-serif',
			'x' => 0.7209,
			'mu' => 1.82,
			'safe' => 'web'),
		'Arial Narrow' => array(
			'name' => 'Arial Narrow',
			'family' => '"Arial Narrow", Arial, "Helvetica Neue", Helvetica, sans-serif',
			'x' => 0.7209,
			'mu' => 2.75,
			'safe' => 'web'),
		'Helvetica' => array(
			'name' => 'Helvetica Neue',
			'family' => '"Helvetica Neue", Helvetica, Arial, sans-serif',
			'x' => 0.7243,
			'mu' => 2.24,
			'safe' => 'web'),
		'Lucida Grande' => array(
			'name' => 'Lucida Grande',
			'family' => '"Lucida Grande", "Lucida Sans", "Lucida Sans Unicode", sans-serif',
			'x' => 0.7327,
			'mu' => 2.05,
			'safe' => 'web'),
		'Palatino' => array(
			'family' => '"Palatino Linotype", Palatino, Georgia, "Times New Roman", Times, serif',
			'x' => 0.6553,
			'mu' => 2.26,
			'safe' => 'web'),
		'American Typewriter' => array(
			'name' => 'American Typewriter',
			'family' => '"American Typewriter", Georgia, serif',
			'x' => 0.7424,
			'mu' => 2.09),
		'Andale' => array(
			'name' => 'Andale Mono',
			'family' => '"Andale Mono", Consolas, Monaco, Menlo, Courier, Verdana, sans-serif',
			'x' => 0.7379,
			'mu' => 1.67,
			'monospace' => true),
		'Baskerville' => array(
			'family' => 'Baskerville, "Times New Roman", Times, serif',
			'x' => 0.5980,
			'mu' => 2.51),
		'Calibri' => array(
			'family' => 'Calibri, "Helvetica Neue", Helvetica, Arial, Verdana, sans-serif'),
		'Cambria' => array(
			'family' => 'Cambria, Georgia, "Times New Roman", Times, serif'),
		'Candara' => array(
			'family' => 'Candara, Verdana, sans-serif'),
		'Consolas' => array(
			'family' => 'Consolas, Menlo, Monaco, Courier, Verdana, sans-serif',
			'monospace' => true),
		'Constantia' => array(
			'family' => 'Constantia, Georgia, "Times New Roman", Times, serif'),
		'Corbel' => array(
			'family' => 'Corbel, "Lucida Grande", "Lucida Sans Unicode", Arial, sans-serif'),
		'Gill Sans' => array(
			'name' => 'Gill Sans',
			'family' => '"Gill Sans", "Gill Sans MT", Calibri, "Trebuchet MS", sans-serif',
			'x' => 0.6537,
			'mu' => 2.47),
		'Hoefler' => array(
			'name' => 'Hoefler Text',
			'family' => '"Hoefler Text", Garamond, "Times New Roman", Times, sans-serif',
			'x' => 0.6098,
			'mu' => 2.39),
		'Menlo' => array(
			'family' => 'Menlo, Consolas, Monaco, "Andale Mono", Courier, Verdana, sans-serif',
			'x' => 0.7489,
			'mu' => 1.66,
			'monospace' => true),
		'Monaco' => array(
			'family' => 'Monaco, Consolas, Menlo, Courier, Verdana, sans-serif',
			'x' => 0.7225,
			'mu' => 1.67,
			'monospace' => true));
}