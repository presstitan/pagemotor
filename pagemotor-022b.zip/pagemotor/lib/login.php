<?php
/**
 * PageMotor Admin Login and Registration Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Login
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Login {
	public $jquery = '3.7.1';
	public $js_login = false;
	public $js_registration = false;

	public function __construct($login = false, $register = false) {
		global $motor;
		if ($login)
			$this->log_in();
		elseif ($register)
			$this->register();
		else {
			$this->js_login = PM_JS_URL. '/pm-login.js';
			$this->js_registration = PM_JS_URL. '/pm-registration.js';
			$has_users = $motor->db->query("SELECT * FROM {$motor->users->table} LIMIT 1");
			if (mysqli_num_rows($has_users) > 0)
				$this->login();
			else {
				$motor->users->cookie_registration();
				$this->registration();
			}
		}
		exit;
	}

	private function login() {
		global $motor;
		$options = array(
			'user' => array(
				'type' => 'text',
				'width' => 'full',
				'label' => 'Username or Email',
				'required' => '*'),
			'password' => array(
				'type' => 'text',
				'sub-type' => 'password',
				'width' => 'full',
				'label' => 'Password',
				'required' => '*'));
		$form = $motor->tools->form->fields($options, array(), false, false, 4);
		echo
			"<!DOCTYPE html>\n".
			"<html>\n".
			"<head>\n".
			"<meta charset=\"utf-8\">\n".
			"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n".
			"<link href=\"https://cdnjs.cloudflare.com/\" rel=\"preconnect\" crossorigin>\n".
			$this->css.
			"</head>\n".
			"<body>\n".
			"<div class=\"section\">\n".
			"\t<div class=\"container\">\n".
			"\t\t<div class=\"content\">\n".
			"\t\t\t<div class=\"flex-heading\">\n".
			"\t\t\t\t<div class=\"logo-pagemotor\">\n".
			$motor->tools->svg->icon('pagemotor', 5, false, false, 1).
			"\t\t\t\t</div>\n".
			"\t\t\t\t<h2>PageMotor Login</h2>\n".
			"\t\t\t</div>\n".
			"\t\t\t<form id=\"pm-login\" class=\"callout note pop\" method=\"post\" action=\"\" enctype=\"multipart/form-data\">\n".
			$form.
			"\t\t\t\t<div id=\"pm-login-buttons\" class=\"pm-form-buttons\">\n".
			"\t\t\t\t\t<button id=\"pm-login-button\" class=\"save\">\n".
			$motor->tools->svg->icon('user-circle', 6).
			"\t\t\t\t\t\tLog In\n".
			"\t\t\t\t\t</button>\n".
			"\t\t\t\t\t<button id=\"pm-password-reset\" class=\"\">\n".
			$motor->tools->svg->icon('help-circle', 6).
			"\t\t\t\t\t\tLost Password?\n".
			"\t\t\t\t\t</button>\n".
			"\t\t\t\t</div>\n".
			"\t\t\t</form>\n".
			"\t\t</div>\n".
			"\t</div>\n".
			"</div>\n".
			"<script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/$this->jquery/jquery.min.js\"></script>\n".
			"<script src=\"$this->js_login\"></script>\n".
			"</body>\n".
			"</html>";
	}

	private function registration() {
		global $motor;
		$options = array(
			'username' => array(
				'type' => 'text',
				'width' => 'full',
				'label' => 'Username',
				'required' => '*'),
			'email' => array(
				'type' => 'text',
				'sub-type' => 'email',
				'width' => 'full',
				'label' => 'Email',
				'required' => '*'),
			'password' => array(
				'type' => 'text',
				'sub-type' => 'password',
				'width' => 'full',
				'label' => 'Password',
				'required' => '*'),
			'password-confirm' => array(
				'type' => 'text',
				'sub-type' => 'password',
				'width' => 'full',
				'label' => 'Confirm Password',
				'required' => '*'));
		$form = $motor->tools->form->fields($options, array(), false, false, 4);
		echo
			"<!DOCTYPE html>\n".
			"<html>\n".
			"<head>\n".
			"<meta charset=\"utf-8\">\n".
			"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n".
			"<link href=\"https://cdnjs.cloudflare.com/\" rel=\"preconnect\" crossorigin>\n".
			$this->css.
			"</head>\n".
			"<body>\n".
			"<div class=\"section\">\n".
			"\t<div class=\"container\">\n".
			"\t\t<div class=\"content\">\n".
			"\t\t\t<div class=\"flex-heading\">\n".
			"\t\t\t\t<div class=\"logo-pagemotor\">\n".
			$motor->tools->svg->icon('pagemotor', 5, false, false, 1).
			"\t\t\t\t</div>\n".
			"\t\t\t\t<h2>PageMotor Admin Registration</h2>\n".
			"\t\t\t</div>\n".
			"\t\t\t<p class=\"callout alert\">Looks like this is your first time running PageMotor! Create an Admin user to get started.</p>\n".
			"\t\t\t<form id=\"pm-registration\" class=\"callout note pop\" method=\"post\" action=\"\" enctype=\"multipart/form-data\">\n".
			$form.
			"\t\t\t\t<div id=\"pm-registration-buttons\" class=\"pm-form-buttons\">\n".
			"\t\t\t\t\t<button id=\"pm-register-button\" class=\"save\">\n".
			$motor->tools->svg->icon('user-circle', 6).
			"\t\t\t\t\t\tCreate Admin User\n".
			"\t\t\t\t\t</button>\n".
			"\t\t\t\t</div>\n".
			"\t\t\t</form>\n".
			"\t\t</div>\n".
			"\t</div>\n".
			"</div>\n".
			"<script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/$this->jquery/jquery.min.js\"></script>\n".
			"<script src=\"$this->js_registration\"></script>\n".
			"</body>\n".
			"</html>";
	}

	private function log_in() {
		global $motor;
		if (empty($_POST['form']))
			echo json_encode(array(
				'error' => "<p class=\"callout error\">Nothing was submitted!</p>\n"));
		else {
			parse_str(stripslashes($_POST['form']), $form);
			if (empty($form['user']) && empty($form['password']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">No username or password!</p>\n"));
			elseif (empty($form['user']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">Username not provided!</p>\n"));
			elseif (empty($form['password']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">Password not provided!</p>\n"));
			else {
				$user = $motor->users->get_user($form['user']);
				if (empty($user))
					echo json_encode(array(
						'error' => "<p class=\"callout error\">User not found!</p>\n"));
				elseif (empty($user['password']))
					echo json_encode(array(
						'error' => "<p class=\"callout error\">User has no password!</p>\n"));
				elseif (!password_verify($form['password'], $user['password']))
					echo json_encode(array(
						'error' => "<p class=\"callout error\">Password is incorrect!</p>\n"));
				else {
					$user = new PM_User($user);
					if ($motor->users->cookie_user($user->name)) {
						if ($user->access_level === 'admin')
							echo json_encode(array(
								'redirect' => $motor->admin_url));
						else
							echo json_encode(array(
								'redirect' => $motor->site_url));
					}
					else
						echo json_encode(array(
							'error' => "<p class=\"callout error\">The user cookie was not created!</p>\n"));
				}
			}
		}
	}

	private function register() {
		global $motor;
		if (empty($_POST['form']))
			echo json_encode(array(
				'error' => "<p class=\"callout error\">Nothing was submitted!</p>\n"));
		else {
			parse_str(stripslashes($_POST['form']), $form);
			if (empty($form['username']) && empty($form['password']) && empty($form['password-confirm']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">No username, email, password, or confirmation!</p>\n"));
			elseif (empty($form['username']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">Username not provided!</p>\n"));
			elseif (empty($form['email']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">Email not provided!</p>\n"));
			elseif (empty($form['password']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">Password not provided!</p>\n"));
			elseif (empty($form['password-confirm']))
				echo json_encode(array(
					'error' => "<p class=\"callout error\">Password confirmation not provided!</p>\n"));
			else {
				$has_users = $motor->db->query("SELECT * FROM {$motor->users->table} LIMIT 1");
				if (mysqli_num_rows($has_users) > 0)
					echo json_encode(array(
						'error' => "<p class=\"callout error\">A user already exists in the database, so this operation cannot be run.</p>\n"));
				else {
					if (!preg_match('/^\w+$/', $form['username'])) // Username must be alphanumeric characters only, no spaces!
						echo json_encode(array(
							'error' => "<p class=\"callout error\">Username can only contain alphanumeric characters and underscores!</p>\n"));
					elseif (!filter_var($form['email'], FILTER_VALIDATE_EMAIL))	// Email must be valid
						echo json_encode(array(
							'error' => "<p class=\"callout error\">Invalid email address provided!</p>\n"));
					elseif ($form['password'] != $form['password-confirm'])	// Passwords must match
						echo json_encode(array(
							'error' => "<p class=\"callout error\">Provided passwords do not match!</p>\n"));
					elseif (empty($_COOKIE[$motor->users->cookie_registration]))
						echo json_encode(array(
							'error' => "<p class=\"callout error\">The registration cookie has expired or does not exist. Reload this page to try again.</p>\n"));
					else {
						// Add user registration
						$user = array(
							'username' => $form['username'],
							'email' => $form['email'],
							'password' => $motor->users->password_hash($form['password']),
							'date_gmt' => gmdate($motor->db->date_format));
						$options = array(
							'level' => 'administrator');
						if ($motor->users->add_new($user, $options)) {
							$motor->users->cookie_user($user['username']);
							echo json_encode(array(
								'redirect' => $motor->admin_url));
						}
						else
							echo json_encode(array(
								'error' => "<p class=\"callout error\">The Admin user could not be created!</p>\n"));
					}
				}
			}
		}
	}

	public $css =
		"<style>\n".
		"* {\n".
		"\tpadding: 0;\n".
		"\tmargin: 0;\n".
		"}\n".
		"h1, h2, h3, h4 {\n".
		"\tfont-weight: normal;\n".
		"}\n".
		"button, input[type=submit] {\n".
		"\tcursor: pointer;\n".
		"\toverflow: visible;\n".
		"}\n".
		"body {\n".
		"\tfont-family: system-ui, BlinkMacSystemFont, Roboto, \"Segoe UI\", Segoe, \"Helvetica Neue\", Tahoma, sans-serif;\n".
		"\tfont-size: 18px;\n".
		"\tline-height: 30px;\n".
		"}\n".
		"a {\n".
		"\tcolor: #d42020;\n".
		"}\n".
		"svg {\n".
		"\twidth: 18px;\n".
		"\theight: 18px;\n".
		"\tvertical-align: text-bottom;\n".
		"}\n".
		"svg[fill=none] {\n".
		"\tstroke: #111111;\n".
		"}\n".
		"h1 {\n".
		"\tfont-size: 37px;\n".
		"\tline-height: 58px;\n".
		"\tfont-weight: bold;\n".
		"\ttext-align: center;\n".
		"}\n".
		"h2 {\n".
		"\tfont-size: 29px;\n".
		"\tline-height: 46px;\n".
		"\tfont-weight: bold;\n".
		"\ttext-align: center;\n".
		"\tmargin-bottom: 30px;\n".
		"}\n".
		"h2 svg {\n".
		"\twidth: 29px;\n".
		"\theight: 29px;\n".
//		"\tpadding: 4px;\n".
		"\tvertical-align: -10%;\n".
//		"\tcursor: pointer;\n".
		"}\n".
		"h3 {\n".
		"\tfont-size: 23px;\n".
		"\tline-height: 38px;\n".
		"\tfont-weight: bold;\n".
		"\ttext-align: center;\n".
		"\tmargin-bottom: 19px;\n".
		"}\n".
		"h3 svg {\n".
		"\twidth: 23px;\n".
		"\theight: 23px;\n".
//		"\tpadding: 4px;\n".
		"\tvertical-align: -10%;\n".
//		"\tcursor: pointer;\n".
		"}\n".
		"h3 svg:hover {\n".
		"\tstroke: #111111;\n".
		"\tbackground: rgba(0, 0, 0, 0.18);\n".
		"\tborder-radius: 100%;\n".
		"}\n".
		"h3 svg[fill=none] {\n".
		"\tstroke: rgba(0, 0, 0, 0.5);\n".
		"}\n".
		"h4 {\n".
		"\tfont-size: 18px;\n".
		"\tline-height: 30px;\n".
		"\tfont-weight: bold;\n".
		"\tmargin-bottom: 12px;\n".
		"}\n".
		".logo-pagemotor {\n".
		"\tdisplay: flex;\n".
		"\tjustify-content: center;\n".
		"\talign-items: center;\n".
		"\tbackground-color: #de0404;\n".
		"\tborder-radius: 100%;\n".
		"}\n".
		".logo-pagemotor svg {\n".
		"\tstroke: #ffdf38;\n".
		"}\n".
		".flex-heading {\n".
		"\tdisplay: flex;\n".
		"\tjustify-content: center;\n".
		"\talign-items: center;\n".
		"\tgap: 7px;\n".
		"\tmargin-bottom: 19px;\n".
		"}\n".
		".flex-heading .logo-pagemotor {\n".
		"\twidth: 48px;\n".
		"\theight: 48px;\n".
		"}\n".
		".flex-heading .logo-pagemotor svg {\n".
		"\twidth: 40px;\n".
		"\theight: 40px;\n".
		"\tpadding-left: 0.5px;\n".
		"}\n".
		".flex-heading h2 {\n".
		"\tmargin-bottom: 0;\n".
		"}\n".
		"label {\n".
		"\tdisplay: block;\n".
		"\tfont-weight: bold;\n".
		"}\n".
		"label .required {\n".
		"\tfont-weight: normal;\n".
		"\tcolor: #dd0000;\n".
		"\tmargin-bottom: 4px;\n".
		"}\n".
		"input {\n".
		"\tdisplay: block;\n".
		"\twidth: auto;\n".
		"\tmax-width: 100%;\n".
		"\tbox-sizing: border-box;\n".
		"\tfont-family: inherit;\n".
		"\tfont-size: inherit;\n".
		"\tline-height: 1em;\n".
		"\tfont-weight: inherit;\n".
		"\tpadding: 7px;\n".
		"\tborder: 1px solid rgba(0, 0, 0, 0.12);\n".
		"\tborder-radius: 4px;\n".
		"\tbox-shadow: 0 0 4px rgba(0, 0, 0, 0.2);\n".
		"\tborder-width: 0 1px 1px 0;\n".
		"}\n".
		"input.full {\n".
		"\twidth: 100%;\n".
		"}\n".
		"input:focus {\n".
		"\tbackground: #fffdcc;\n".
		"\ttransition: 1s;\n".
		"}\n".
		"input:-webkit-autofill {\n".
		"\tbox-shadow: 0 0 0px 1000px #ffffd2 inset, 0 0 4px rgba(0, 0, 0, 0.2);\n".
		"}\n".
		"button {\n".
		"\tdisplay: inline-block;\n".
		"\twidth: auto;\n".
		"\tfont-family: inherit;\n".
		"\tfont-size: inherit;\n".
		"\tfont-weight: normal;\n".
		"\tline-height: 1em;\n".
		"\tvertical-align: top;\n".
		"\tcolor: #111111;\n".
		"\ttext-decoration: none;\n".
		"\tbackground-color: #ebdcc8;\n".
		"\tpadding: 12px 12px;\n".
		"\tborder: 1px solid rgba(0, 0, 0, 0.1);\n".
		"\tborder-bottom-width: 4px;\n".
		"\tborder-bottom-color: rgba(0, 0, 0, 0.25);\n".
		"\tborder-radius: 12px;\n".
		"\toutline: 1px solid rgba(0, 0, 0, 0.1);\n".
		"\toutline-offset: -1px;\n".
		"\tcursor: pointer;\n".
		"\tuser-select: none;\n".
		"}\n".
		"button:hover, button:active {\n".
		"\ttext-decoration: none;\n".
		"\tbackground-color: #f4ece1;\n".
		"\ttransition: background-color 0.3s ease;\n".
		"}\n".
		"button:active {\n".
		"\tborder-bottom-width: 2px;\n".
		"\tmargin-top: 2px;\n".
		"}\n".
		"button.save {\n".
		"\tcolor: white;\n".
		"\tbackground-color: #509b26;\n".
		"}\n".
		"button.save:hover, button.save:active {\n".
		"\tbackground-color: #60ba2e;\n".
		"}\n".
		"button.delete {\n".
		"\tcolor: white;\n".
		"\tbackground-color: #d50b0b;\n".
		"}\n".
		"button.delete:hover, button.delete:active {\n".
		"\tbackground-color: #f31313;\n".
		"}\n".
		"button.action {\n".
		"\tcolor: white;\n".
		"\tbackground-color: #12a7ff;\n".
		"}\n".
		"button.action:hover, button.action:active {\n".
		"\tbackground-color: #38b5ff;\n".
		"}\n".
		"button.update {\n".
		"\tcolor: #111111;\n".
		"\tbackground-color: #fcfc0d;\n".
		"}\n".
		"button.update:hover, button.update:active {\n".
		"\tbackground-color: #fcfc33;\n".
		"}\n".
		"button svg {\n".
		"\tvertical-align: inherit;\n".
		"}\n".
		"button.save, button.delete, button.action {\n".
		"\ttext-shadow: 1px 1px 0 rgba(0, 0, 0, 0.25);\n".
		"}\n".
		"button.save svg, button.delete svg, button.action svg {\n".
		"\tstroke: white;\n".
		"\tfilter: drop-shadow(1px 1px 0 rgba(0, 0, 0, 0.2));\n".
		"}\n".
		".option-item {\n".
		"\tmargin-bottom: 19px;\n".
		"\tclear: both;\n".
		"}\n".
		".pm-form-buttons {\n".
		"\tdisplay: flex;\n".
		"\tflex-wrap: wrap;\n".
		"\tgap: 19px;\n".
		"\tjustify-content: space-between;\n".
		"}\n".
		".callout {\n".
		"\tbackground-color: #cce8cc;\n".
		"\tpadding: 19px;\n".
		"\tborder-radius: 12px;\n".
		"}\n".
		".callout.alert {\n".
		"\tbackground-color: #ffe91f;\n".
		"\tmargin-bottom: 19px;\n".
		"}\n".
		".callout.note {\n".
		"\tbackground-color: #ccf1ff;\n".
		"}\n".
		".callout.error {\n".
		"\tbackground-color: #ffdcdc;\n".
		"\tmargin-bottom: 19px;\n".
		"}\n".
		".callout > :last-child {\n".
		"\tmargin-bottom: 0;\n".
		"}\n".
		".pop {\n".
		"\tbox-shadow: 0 0 7px rgba(0,0,0,0.4);\n".
		"}\n".
		".container {\n".
		"\tbox-sizing: border-box;\n".
		"\tdisplay: flex;\n".
		"\tjustify-content: center;\n".
		"\talign-items: center;\n".
		"\theight: 100vh;\n".
		"\tpadding-left: 19px;\n".
		"\tpadding-right: 19px;\n".
		"}\n".
		".content {\n".
		"\tmax-width: 644px;\n".
		"\tmargin-left: auto;\n".
		"\tmargin-right: auto;\n".
		"}\n".
		"@media all and (min-width: 682px) {\n".
		"\t.container {\n".
		"\t\tmax-width: 644px;\n".
		"\t\tpadding-left: 0;\n".
		"\t\tpadding-right: 0;\n".
		"\t\tmargin-left: auto;\n".
		"\t\tmargin-right: auto;\n".
		"\t}\n".
		"}\n".
		"@media all and (min-width: 704px) {\n".
		"\t.container {\n".
		"\t\tmax-width: 100%;\n".
		"\t\tpadding-left: 30px;\n".
		"\t\tpadding-right: 30px;\n".
		"\t\tmargin-left: 0;\n".
		"\t\tmargin-right: 0;\n".
		"\t}\n".
		"}\n".
		"@media all and (min-width: 1100px) {\n".
		"\t.container {\n".
		"\t\tmax-width: 1040px;\n".
		"\t\tpadding-left: 0;\n".
		"\t\tpadding-right: 0;\n".
		"\t\tmargin-left: auto;\n".
		"\t\tmargin-right: auto;\n".
		"\t}\n".
		"}\n".
		"</style>\n";
}