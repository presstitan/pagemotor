<?php
/**
 * PageMotor Options Table Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Options
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Options {
	public $table = 'options';	// [string] PageMotor options table
//	public $all = array();		// [array] base PageMotor options from the database

	// NOTE: Some methods should probably be moved to Tools!
	public function __construct() {
		global $motor;
		$this->table = $motor->db->prefix. $this->table;
//		$this->all = is_array($options = $this->all()) ? $options : $this->all;
	}

/*	public function all() {
		global $motor;
		$all = array();
		$options = $motor->db->get_rows("SELECT name, value FROM $this->table");
		foreach ($options as $option)
			$all[$option['name']] = $option['value'];
		return $all;
	}*/

	/**
	 * Retrieve an option from the PageMotor options table. This method removes the need
	 * to perform an isset() check on every call, making endpoint code cleaner. It
	 * also performs a json_decode() on the retrieved option, if necessary.
	 * @param $option: option_name field in the options table
	 */
	public function option($option, $default = false) {
		// Could use $this->all() to try and get an option
		// Only resort to the db if the option is not found
		// $this->all would need to be updated on each update/delete
		global $motor;
		$result = $motor->db->get_cell("SELECT value FROM $this->table WHERE name = '$option'");
		if (empty($result))
			return $default;
		elseif ((function_exists('json_validate') && json_validate($result) === true) || $motor->tools->is_json($result))
			return json_decode($result, true);
		else
			return $result;
	}

	public function update($name, $value) {
		global $motor;
		if (empty($name))
			return false;
		if (is_array($value) || is_object($value))
			$value = $motor->db->connection->real_escape_string(json_encode($value));
		$motor->db->query("INSERT INTO $this->table (name, value) VALUES ('$name', '$value') ON DUPLICATE KEY UPDATE value = '$value'");
		return true;
	}

	public function delete($name) {
		global $motor;
		if (empty($name))
			return false;
		$motor->db->query("DELETE FROM $this->table WHERE name = '$name'");
		return true;
	}

	public function exists($option) {
		global $motor;
		if (empty($option))
			return false;
		$result = $motor->db->get_rows("SELECT * FROM $this->table WHERE name = '$option'");
		return !empty($result) ? true : false;
	}

/*
	The set() method takes data from a form and returns an array of vaules ready to be stored in a database.
	— $fields: an array of options in Thesis Options API Array Format (https://diythemes.com/thesis/rtfm/api/options/array-format/)
	— $values: an array of values from a form
	— $reference: the 'image' field requires a reference parameter to locate relevant data
	— $upload_type: the 'image' field may require an upload type parameter to function properly
	— $post_id: the 'image' field may require a post ID parameter to function properly
*/
	public function set($fields, $values, $reference = '', $upload_type = 'default', $post_id = 0) {
		global $motor;
		if (!is_array($fields)) return false;
		$save = array();
		foreach ($fields as $id => $field) {
			if (is_array($field) && !empty($field['type'])) {
				if ($field['type'] == 'group') {
					if (is_array($field['fields']))
						if ($group = $this->set($field['fields'], $values))
							foreach ($group as $item_id => $val)
								$save[$item_id] = $val;
				}
				elseif ($field['type'] == 'custom') {
					if (!empty($field['options']) && is_array($field['options']))
						foreach ($field['options'] as $custom_id => $default)
							if (!empty($values[$custom_id]) && $values[$custom_id] != $default)
								$save[$custom_id] = $values[$custom_id];
				}
				else {
					// Image must be fixed for PageMotor contexts
					if ($field['type'] == 'image') {
						$value = !empty($values[$id]) && is_array($values[$id]) ? array_filter($values[$id]) : false;
						if (!empty($_FILES["{$reference}$id"]['name'])) {
							$new_image = $this->save_image("{$reference}$id", $upload_type, $post_id);
							$diff = array_diff(array('url', 'width', 'height', 'id'), array_keys(array_filter($new_image)));
							if ((in_array($upload_type, array('default', 'box')) && empty($diff))
								|| ($upload_type == 'skin' && count($diff) === 3)) {
								$value['url'] = $motor->url_escape($motor->tools->url_relative($new_image['url']), true);
								$value['width'] = (int) $new_image['width'];
								$value['height'] = (int) $new_image['height'];
								if (isset($new_image['id']))
									$value['id'] = (int) $new_image['id'];
							}
						}
					}
					else {
						$value = !empty($values[$id]) ? $values[$id] : false;
						if ($field['type'] == 'checkbox' && is_array($field['options'])) {
							$checkbox = array();
							$value = is_array($value) ? $value : array();
							foreach ($field['options'] as $option => $label)
								if (!empty($value[$option]) && empty($field['default'][$option]))
									$checkbox[$option] = true;
								elseif (isset($value[$option]) && empty($value[$option]) && !empty($field['default'][$option]))
									$checkbox[$option] = false;
							if (!empty($checkbox))
								$value = $checkbox;
							else
								unset($value);
						}
						elseif (in_array($field['type'], array('image-upload', 'add-media')) ) {
							$value = !empty($value['url']) ? array_filter(array(
								'url' => $motor->url_escape($motor->tools->url_relative($value['url']), true),
								'width' => !empty($value['width']) ? (int) $value['width'] : false,
								'height' => !empty($value['height']) ? (int) $value['height'] : false)) : array();
						}
						// Need support for multiple select elements and unlimited ajax fields
					}
					if (!empty($value))
						$save[$id] = is_array($value) ? $value : trim($value);
				}
			}
		}
		return $save;
	}

/*
	The get() method takes saved option data and combines it with default
	option data to determine the current state of options. Use this for
	FINAL decision-making purposes ONLY; do not feed data that has been
	sent through get() to the Form tool.
	— $fields: an array of options in Thesis Options API Array Format (https://diythemes.com/thesis/rtfm/api/options/array-format/)
	— $values: an array of values retrieved from the database
*/
	public function get($fields, $values) { // Returns options + defaults (defaults are not saved to the db)
		if (!is_array($fields)) return array();
		$values = is_array($values) ? $values : array();
		$options = array();
		foreach ($fields as $id => $field)
			if (is_array($field)) {
				if ($field['type'] == 'group') {
					if (is_array($field['fields']))
						$options = is_array($group = $this->get($field['fields'], $values)) ? array_merge($options, $group) : $options;
				}
				elseif ($field['type'] == 'custom') {
					if (!empty($field['options']) && is_array($field['options']))
						foreach ($field['options'] as $custom_id => $default)
							if (!empty($values[$custom_id]))
								$options[$custom_id] = $values[$custom_id];
							elseif (!empty($default))
								$options[$custom_id] = $default;
				}
				else {
					if ($field['type'] == 'checkbox' && is_array($field['options']))
						foreach ($field['options'] as $option => $option_value) {
							$options[$id][$option] = isset($values[$id][$option]) ? (bool) $values[$id][$option] : (!empty($field['default'][$option]) ? $field['default'][$option] : false);
							if (empty($options[$id][$option]))
								unset($options[$id][$option]);
						}
					else
						$options[$id] = !empty($values[$id]) ? $values[$id] : (!empty($field['default']) ? $field['default'] : false);
				}
				if (empty($options[$id]))
					unset($options[$id]);
			}
		return $options;
	}

/*
	Handle uplaoded image data and return a value suitable for saving.
	— $location: the location of the uploaded file in the $_FILES array
	— $type: determines where to store the uploaded image; 'default' and 'box' use the WP upload system, 'skin' uses the active Skin's /images folder.
	— $post_id: provide a post ID if one is associated with the image
*/
	public function save_image($location, $type = 'default', $post_id = 0) {
		global $motor;
		if (empty($_FILES[$location]) || $_FILES[$location]['error'] === 4) // || !current_user_can('upload_files'))
			return false;
		$url = $width = $height = $id = false;
		// plain old upload
		if ($type === 'default' || $type === 'box') {
			$post_id = (int) abs($post_id);
			// returns the attachment id
			$id = media_handle_upload($location, $post_id);
			$id = (int) $id;
			$post = get_post($id);
			if (empty($post->guid))
				return false;
			$url = $post->guid;
			if (empty($url)) return false;
			$metadata = wp_get_attachment_metadata($id);
			if (empty($metadata)) {
				$wp_upload = wp_upload_dir(); // path
				$image_data = @getimagesize("{$wp_upload['path']}/". basename($post->guid));
			}
			$height = !empty($metadata['height']) ? $metadata['height'] : (!empty($image_data[1]) ? $image_data[1] : false);
			$width = !empty($metadata['width']) ? $metadata['width'] : (!empty($image_data[0]) ? $image_data[0] : false);
		}
		elseif ($type === 'skin') {
			$upload = $_FILES[$location];
			if (!@is_uploaded_file($upload['tmp_name']) || ! ($upload_data = @getimagesize($upload['tmp_name'])) || $upload['error'] > 0 ||
				!defined('THESIS_USER_SKIN_IMAGES'))
				return false;
			if (!@is_dir(THESIS_USER_SKIN_IMAGES) && get_filesystem_method() === 'direct') {
				include_once(ABSPATH. 'wp-admin/includes/file.php');
				WP_Filesystem();
				if (!$GLOBALS['wp_filesystem']->mkdir(THESIS_USER_SKIN_IMAGES))
					return false;
			}
			$ext = explode('/', $upload_data['mime']);
			$ext = strtolower($ext[1]) == 'jpeg' ? 'jpg' : (strtolower($ext[1]) == 'tiff' ? 'tif' : strtolower($ext[1]));
			if (!stristr($upload['name'], ".$ext")) {
				$a = explode('.', $upload['name']);
				array_pop($a);
				array_push($a, $ext);
				$upload['name'] = implode('.', $a);
			}
			// make a unique file name
			$upload['name'] = wp_unique_filename(THESIS_USER_SKIN_IMAGES, $upload['name']);
			$path = untrailingslashit(THESIS_USER_SKIN_IMAGES). "/{$upload['name']}";
			if (@move_uploaded_file($upload['tmp_name'], $path) === false)
				return false;
			$url = untrailingslashit(THESIS_USER_SKIN_IMAGES_URL). "/{$upload['name']}";
			$height = $upload_data[0];
			$width = $upload_data[1];
		}
		$return = array_filter(array(
			'url' => $motor->url_escape($motor->tools->url_relative($url), true),
			'width' => !empty($width) ? (int) $width : false,
			'height' => !empty($height) ? (int) $height : false,
			'id' => !empty($id) ? $id : false));
		return !empty($return) ? $return : false;
	}

/*---:[ Options Helpers ]:---*/

/*
	Shortcut method to add standard HTML options to a Box.
	— $tags: to add an HTML tag option, provide an array of potential tags here
	— $default: indicate a default HTML tag value here
	— $attributes: set to true to add an HTML attributes option
	— $group: to make these HTML options a group, set this to true
*/
	public function html($tags = false, $default_tag = false, $attributes = false, $group = false) {
		$options['tag'] = !empty($tags) && is_array($tags) ? array_filter(array(
			'type' => 'select',
			'label' => 'HTML Tag',
			'options' => $tags,
			'default' => $default_tag)) : false;
		$options = array_filter(array_merge($options, array(
			'id' => array(
				'type' => 'text',
				'width' => 'medium',
				'code' => true,
				'label' => 'HTML <code>id</code>',
				'tooltip' => 'If you need to target this box individually with CSS or JavaScript, you can enter an <code>id</code> here.<br /><br /><strong>Note:</strong> <code>id</code>s cannot begin with numbers, and only one <code>id</code> is valid per box!'),
			'class' => array(
				'type' => 'text',
				'width' => 'medium',
				'code' => true,
				'label' => 'HTML <code>class</code>',
				'tooltip' => 'If you want to target this box with CSS or JavaScript, you should enter a <code>class</code> name here.<br /><br /><strong>Note:</strong> <code>class</code> names cannot begin with numbers!'),
			'attributes' => $attributes ? array(
				'type' => 'text',
				'width' => 'medium',
				'code' => true,
				'label' => 'HTML Attributes',
				'tooltip' => 'You can add attributes to your HTML containers; for example, <code>data-type="box"</code>. You can even use this field for multiple attribute declarations (separate with a space).') : false)));
		return !empty($group) ? array(
			'group-html' => array(
				'type' => 'group',
				'label' => 'HTML Options',
				'fields' => $options)) : $options;
	}
}