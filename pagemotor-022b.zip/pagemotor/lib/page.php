<?php
/**
 * PageMotor Page Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Content
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Page {
	public $url = false;					// [string] URL of the current page (with query string removed)
	public $parsed = array();				// [array] parsed URL of the current page (includes query string)
	public $slug = false;					// [string] slug of the page being rendered
	public $type = false;					// [string] current content type, if applicable
	public $content = array();				// [array] content data for the current page
	public $options = array();				// [array] content options for the current page
	public $parent_slug = false;			// [string] slug of the parent page
	public $parent = array();				// [array] parent page content, if applicable
	public $ancestors = array();			// [array] 
	public $ancestor_slug = false;			// [string] slug of the current page's highest-level ancestor
	public $query = false;					// [string] current URL query string, if applicable
	public $search_param = 's';				// [string] query string parameter to trigger searches
	public $search_term = false;			// [string] current search term, if applicable
	public $ajax = 'pm_ajax';				// [string] reference to include in $_POST data for an ajax request
	public $ajax_login = 'pm_login';		// [string] reference to include in $_POST data for login request
	public $ajax_register = 'pm_register';	// [string] reference to include in $_POST data for admin registration request
	public $home = 'home';					// [string] option reference for home page
	public $admin_home = 'admin_home';		// [string] option reference for Admin home page
	public $admin_access_level = 'admin';	// [string] user must have this access level to use the Admin
	// Quick-reference environmental properties
	public $is_theme = false;				// [bool]
	public $is_admin = false;				// [bool]
	public $is_home = false;				// [bool]
	public $is_search = false;				// [bool]
	public $is_ajax = false;				// [bool]
	public $error = false;					// [bool] is 404?
	public $type_error = 'error';			// [string] Content Type for error page

	public function __construct() {
		global $motor;
		$this->url = $motor->protocol. $_SERVER['HTTP_HOST']. $_SERVER['REQUEST_URI'];
		// URL will be stripped of query variables in the page() method
		$this->environment();
	}

	private function environment() {
		global $motor;
		$this->parsed = parse_url($this->url);
		// Search forms need to redirect to the home page
		// Therefore, a properly identified search request must also match is_home before now
		$this->query = !empty($this->parsed['query']) ? $this->parsed['query'] : $this->query;
		if (!empty($this->query)) {
			$query = $this->parse_query($this->query);
			if (!empty($query) && !empty($query[$this->search_param])) {
				$this->is_search = true;
				$this->search_term = !empty($_GET[$this->search_param]) ? $_GET[$this->search_param] : $this->search_term;
			}
			$this->url = str_replace($this->query, '', $this->url);
		}
		// Home URL will have a '/' path
		if (strpos($this->parsed['path'], $motor->admin_slug) !== false) {
			$path = $this->parsed['path'];
			if (!empty($motor->install_slug))
				$path = str_replace("/$motor->install_slug", '', $this->parsed['path']);
			if (explode('/', trim($path, '/'))[0] === $motor->admin_slug)
				$this->is_admin = true;
		}
		else
			$this->is_theme = true;
		if (!empty($_POST) && !empty($_POST[$this->ajax])) {
			if (!empty($_POST[$this->ajax_login]))
				new PM_Login(true);
			elseif (!empty($_POST[$this->ajax_register]))
				new PM_Login(false, true);
			else
				$this->is_ajax = true;
		}
	}

	public function run() {
		global $motor;
		if ($this->is_theme) {
			if ($this->url == $motor->site_url) {
				$this->is_home = true;
				if ($home = $motor->options->option($this->home))
					$this->content = $motor->content->get_by_id($home);
			}
			else {
				$this->slug = basename($this->parsed['path']);
				$this->parent_slug = ($parent_slug = $this->parent_slug($this->parsed['path'], $this->slug)) && $parent_slug != $motor->install_slug ?
					$parent_slug : $this->parent_slug;
				$this->content = $this->get_content_by_slug($this->slug, $this->parent_slug);
				if (empty($this->content) || (!empty($this->content['status']) && $this->content['status'] !== 'live' /*&& not logged in as admin*/))
					$this->error = true;
			}
		}
		elseif ($this->is_admin) {
			$this->admin_login();
			if ($this->url == $motor->admin_url) {
				$this->is_home = true;
				if ($admin_home = $motor->options->option($this->admin_home))
					$this->content = $motor->content->get_by_id($admin_home, $this->is_admin);
			}
			else {
				$this->slug = basename($this->parsed['path']);
				// We probably do NOT need parent slug as a core URL property
				// (because content types can be used instead to determine locales)
				// Still need to modify core Plugins to prove this
				$this->parent_slug = ($parent_slug = $this->parent_slug($this->parsed['path'], $this->slug)) && $parent_slug != $motor->admin_slug ?
					$parent_slug : $this->parent_slug;
				$this->content = $this->get_content_by_slug($this->slug, $this->parent_slug, $this->is_admin);
				if (empty($this->content) || (!empty($this->content['status']) && $this->content['status'] !== 'live' /*&& not logged in as admin*/))
					$this->error = true;
			}
		}
		if ($this->error) {
			$results = $motor->content->get_where(array('type' => $this->type_error), $this->is_admin);
			if (!empty($results))
				$this->content = $results[0];
		}
		$this->type = !empty($this->content['type']) ? $this->content['type'] : $this->type;
		if (!empty($this->content['id']))
			$this->options = $motor->content->get_options($this->content['id'], $this->is_admin);
		$this->ancestor_slug = ($ancestor = $this->ancestor_slug($this->parsed['path'], $motor->install_slug)) && $ancestor != $this->slug ?
			$ancestor : $this->ancestor_slug;
	}

	private function admin_login() {
		global $motor;
		if (empty($motor->user))
			new PM_Login;
		elseif ($motor->user->access_level !== $this->admin_access_level)
			$motor->redirect($motor->site_url);
	}

	public function get_content_by_slug($slug, $parent_slug, $admin = false) {
		global $motor;
		if (empty($slug))
			return false;
		$results = $motor->content->get_where(array('slug' => $slug), $admin);
		if (count($results) > 1) {
			foreach ($results as $content)
				if (!empty($content['parent'])) {
					$this->parent = $motor->content->get_by_id($content['parent'], $admin);
					if (!empty($this->parent['slug']) && $this->parent['slug'] == $parent_slug)
						return $content;
				}
		}
		else
			return count($results) === 1 ?
				$results[0] :
				array();
	}

	public function parent_slug($path, $slug) {
		$path = rtrim($path, '/');
		if (empty($path) || empty($slug))
			return false;
		if (($parent_dir = rtrim($path, $slug))
		&& strlen($parent_dir) > 1
		&& ($parent_slug = basename($parent_dir)))
			return $parent_slug;
		else
			return false;
	}

	public function ancestor_slug($path, $root = false) {
		$path = rtrim($path, '/');
		if (empty($path))
			return false;
		$slug = basename($path);
		$this->ancestors[] = $slug;
		$path = rtrim($path, $slug);
		return (!empty($root) && $path == "/$root/") || (strlen($path) == 1 && $path == '/') ?
			$slug :
			$this->ancestor_slug($path, $root);
	}

	public function parse_query($query) {
		if (empty($query))
			return false;
		$parameters = array();
		$params = explode('&', $query);
		foreach ($params as $param) {
			list($name, $value) = explode('=', $param, 2);
			if (isset($parameters[$name])) {
				if (is_array($parameters[$name]))
					$parameters[$name][] = $value;
				else
					$parameters[$name] = array($parameters[$name], $value);
			}
			else
				$parameters[$name] = $value;
		}
		return $parameters;
	}

	public function is_tree($id, $admin = false) {
		if (empty($id) || empty($this->content['id']) || empty($this->ancestor_slug))	// May need to tweak this per testing
			return false;
		elseif ($id == $this->content['id']) 	// Match content
			return true;
		elseif (!empty($this->parent)			// Match parent or grandparent
		&& ((!empty($this->parent['id']) && $id == $this->parent['id']) || (!empty($this->parent['parent']) && $id == $this->parent['parent'])))
			return true;
		else {
			// Find the parent's parent and continue to do that until we reach the oldest ancestor
			$ancestors = $this->ancestors;
			array_splice($ancestors, false, 3);			// remove slug, parent slug, and grandparent slug
			if (!empty($this->parent['parent'])) {
				$try = $this->parent['parent'];			// start with grandparent ID
				for ($i = 1; $i <= count($ancestors); $i++) {
					$ancestor = $motor->content->get_by_id($try, $admin);
					if (!empty($ancestor) && !empty($ancestor['parent']) && $id == $ancestor['parent'])
						return true;
					elseif (!empty($ancestor['parent']))
						$try = $ancestor['parent'];
				}
			}
			return false;
		}
	}
}