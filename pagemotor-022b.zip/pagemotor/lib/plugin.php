<?php
/**
 * PageMotor Plugin Model
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license 	MIT2
 * @since		0.1
 */
class PM_Plugin {
	// essential properties for extensions to be defined by developer as necessary
	public $title = false;					// [string] not required, per se, but every Plugin should have one
	public $type = false;					// [string] possible types: box, container, false (false = does not appear in template editors)
	// reserved properties for 'box' and 'container' to be set by developer as necessary (for template editors)
	public $name = false;					// [string] required for multi-instance! ('box' and 'container' only)
	public $root = false;					// [bool] Currently, only <head> and <body> should be considered roots
	public $head = false;					// [bool] 'box' only; true = box goes in the <head>; false = <body>.
	public $custodians = array();			// [array] 'box' and 'container' only, specifies custodian Plugins and initial states
	public $toggle = false;					// [bool] 'container' only, set to true if the Box contents should be visible on admin page load
	// reserved properties set by the constructor and intended for use in extensions
	public $admin_theme = false;			// [bool] is the activating Theme an Admin Theme?
	public $site_options = array();			// [array] saved sitewide options (indepedent of Theme)
	public $content_options = array();		// [array] saved options that appear on the content editing screen (independent of Theme)
	public $theme_options = array();		// [array] saved options relative to the current Theme
	public $box_options = array();			// [array] 'box', 'container' only; saved options for this instance (includes Admin + HTML options)
	public $template_options = array();		// [array] 'box', 'container' only: saved options for the current template
	// modify certain core Plugin behaviors
	protected $docs = array(				// [array] documentation links for various Plugin UIs
		'site' => false,
		'content' => false,
		'theme' => false,
		'box' => false,
		'template' => false);
	// critical reserved properties set by the core Plugin constructor
	public $_class;							// [string] quick reference for this Plugin's class name
	public $_id;							// [string] unique identifier for this instance
	// reserved properties set by the constructor and NOT intended for use by extensions
	public $_parent = false;				// [string] unique ID of parent Box
	public $_lineage = false;				// [string] breadcrumb-style ID showing parent/child Box relationships
	public $_site_options = array();		// [array] sitewide options (independent of Theme)
	public $_content_options = array();		// [array] options for the content editing screen (independent of Theme)
	public $_theme_options = array();		// [array] options for the current Theme
	public $_admin_options = array();		// [array] Admin options for this instance when deployed in templates
	public $_html_options = array();		// [array] HTML options for this instance when deployed in templates
	public $_box_options = array();			// [array] options for this instance when deployed in templates
	public $_template_options = array();	// [array] options for the current template
	public $_uploader = array();			// [array] contains uploader options
	public $_toggle = false;				// [bool] toggle the container open by default in the template editor
	public $_boxes = array();				// [array] Boxes within this container
	public $_dependents = array();			// [array] dependent Boxes as launched by the Theme Plugins controller
	public $_startup = array();				// [array] dependent Boxes to be shown in the active area of this container
	public $_add_boxes = array();			// [array] dependent Boxes to be added when Container is added to template

	public function __construct($plugin = array(), $theme_options_saved = array()) {
		global $motor;
		extract($plugin); // $id, $options, $admin_theme
		$this->_class = get_class($this);
		$this->_id = !empty($id) ? $id : $this->_class;
		$options = !empty($options) ? $options : array();
		if (!empty($options['_parent'])) {
			$this->_parent = $options['_parent'];
			$this->_id = !empty($id) ? $this->_id : "{$this->_parent}_$this->_id";
		}
		$this->name = !empty($options['_name']) ? $options['_name'] : $this->name;
		$this->admin_theme = !empty($admin_theme);
		// Add content types
		$motor->content->add_types($this->content_types());
		// Add fonts
		$motor->fonts->add($this->fonts(), $this->google_fonts());
/*		if (is_array($content_types = $this->content_types()) && !empty($content_types))
			foreach ($content_types as $id => $type)
				$motor->content->add_type($id, $type);*/
		// Acquire options fields
		$this->_site_options = $this->site_options();
		$this->_content_options = $this->content_options();
		$this->_theme_options = $this->theme_options();
		$this->_admin_options = $this->_admin_options();
		$this->_html_options = $this->html_options();
		$this->_box_options = $this->box_options();
		$this->_template_options = $this->template_options();
		// Add Content Options
		if (!empty($this->_content_options) && empty($motor->plugins->content[$this->_class]))
			$motor->content->options[$this->_class] = $this->_content_options;
		// Add Site Options and set saved values if they exist
		if (!empty($this->_site_options) && empty($motor->plugins->options[$this->_class]))
			$motor->plugins->options[$this->_class] = $this->_site_options;
		$this->site_options = is_array($site_options_saved = $motor->options->option($this->_class)) ?
			$site_options_saved : $this->site_options;
		// Set saved options values
		$this->theme_options = !empty($theme_options_saved[$this->_class]) ?
			$theme_options_saved[$this->_class] : $this->theme_options;
		$this->box_options = $motor->options->get(array_merge($this->_admin_options, $this->_html_options, $this->_box_options), $options);
		$this->_uploader = is_array($uploader = $this->uploader()) ? $uploader : $this->_uploader;
		$this->_toggle = isset($this->box_options['_admin']['open']) ? (bool) $this->box_options['_admin']['open'] : $this->toggle;
		$this->construct();
	}

/*
	Secondary constructor for plugins that need to initiate things before the page loads
*/
	protected function construct() {}

	public function content_types() {
		return array();
	}

	public function fonts() {
		return array();
	}

	public function google_fonts() {
		return array();
	}

	public function site_options() {
		return array();
	}

	public function content_options() {
		return array();
	}

	public function theme_options() {
		return array();
	}

	public function html_options() {
		return array();
	}

	public function box_options() {
		return array();
	}

	public function template_options() {
		return array();
	}

	public function uploader() {
		return array();
	}

	public function register_js() {
		return array();
	}

	public function font_js() {
		return array();
	}

	public function css() {
		return array();
	}

	public function site_options_css() {
		return array();
	}

	public function js() {
		return array();
	}

	public function site_options_js() {
		return array();
	}

	public function content_options_js() {
		return array();
	}

	public function theme_options_js() {
		return array();
	}

	public function box_options_js() {
		return array();
	}

	public function template_options_js() {
		return array();
	}

	public function scss_mixins() {
		return array();
	}

	public function scss_includes() {
		return array();
	}

	public function scss_includes_editor() {
		return array();
	}

	public function preload() {
		return false;
	}

	public function write_css($filename, $content) {
		global $motor;
		$motor->tools->write(PM_USER_CSS. "/$filename", $content);
	}

/*
	FOR BOXES: Determines the Plugin's HTML output
*/
	public function html($depth = 0) {}

/*
	FOR CONTAINERS: Determines the Plugin's HTML output before the interior Boxes
*/
	public function container_open($depth = 0) {}

/*
	FOR CONTAINERS: Determines the Plugin's HTML output after the interior Boxes
*/
	public function container_close($depth = 0) {}

	public function _display() {
		global $motor;
		return !apply_filters("{$this->_class}-".
			((!empty($this->name) || !empty($this->_parent))
			&& !$this->root
			&& !empty($this->box_options['_id']) ?
				trim($motor->text($this->box_options['_id'])). '-' : ''). "show", true) ? false : true;
	}

	public function _site_options($depth = 0) {
		global $motor;
		return array(
			'name' => !empty($this->title) ? $this->title : $this->_class,
			'docs' => !empty($this->docs['site']) ? $this->docs['site'] : false,
			'html' => $motor->tools->form->fields($this->_site_options, $this->site_options, "{$this->_class}_", $this->_class, $depth));
	}

	public function _theme_options($depth = 0) {
		global $motor;
		return array(
			'name' => !empty($this->title) ? $this->title : $this->_class,
			'docs' => !empty($this->docs['theme']) ? $this->docs['theme'] : false,
			'html' => $motor->tools->form->fields($this->_theme_options, $this->theme_options, "{$this->_class}_", $this->_class, $depth));
	}

	public function _box_options($depth = 0) {
		global $motor;
		return array(
			'name' => (!empty($this->_lineage) ? $this->_lineage : ''). (!empty($this->name) ? $this->name : $this->title),
			'docs' => !empty($this->docs['box']) ? $this->docs['box'] : false,
			'html' => $motor->tools->form->fields($this->_box_options, $this->box_options, '', "{$this->_class}[$this->_id]", $depth));
	}

	public function _admin_options() {
		$html = array();
		if ($this->root)
			return $html;
		$html['_admin'] = $this->type == 'container' ? array(
			'type' => 'checkbox',
			'label' => 'Template Editor Visibility',
			'options' => array(
				'open' => 'Container is open by default'),
			'default' => array(
				'open' => (bool) $this->toggle)) : false;
		$html['_id'] = !empty($this->name) || !empty($this->_parent) ? array_merge(array(
			'type' => 'text',
			'width' => 'medium',
			'code' => true), $this->type == 'container' ? array(
			'label' => 'Display ID (and Hook Name)',
			'description' => sprintf('Display ID syntax: %s_{ID}', $this->_class)) : array(
			'label' => 'Display ID',
			'tooltip' => sprintf('Specify a Display ID here, and you&#8217;ll be able to control this Box with <a href="%s">Theme Display Options</a>.', 'https://diythemes.com/thesis/rtfm/api/skin/display-options/'),
			'description' => sprintf('Display ID syntax: %s_{ID}', $this->_class))) : false;
		return array_filter($html);
	}
}