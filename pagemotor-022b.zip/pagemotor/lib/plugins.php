<?php
/**
 * PageMotor Plugin Manager
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Plugins
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Plugins {
	public $core = array();			// [array] info about core Plugins referenced by class
	public $user = array();			// [array] info about user Plugins referenced by class
	public $option = 'plugins';		// [string] DB reference for active user Plugins
	public $all = array();			// [array] info about all installed Plugins (including inactive)
	public $active = array();		// [array] class names of core + active user Plugins
	public $options = array();		// [array] list of Plugins with site_options() admin pages
	public $content = array();		// [array] list of Plugins with content_options()
	public $updates = array();		// [array] Plugin update notifications

	public function __construct() {
		global $motor;
		// Directories
		define('PM_CORE_PLUGINS', PM_LIB. '/plugins');
		define('PM_USER_PLUGINS', PM_USER_CONTENT. '/plugins');
		// URLs
		define('PM_CORE_PLUGINS_URL', PM_LIB_URL. '/plugins');
		define('PM_USER_PLUGINS_URL', PM_USER_CONTENT_URL. '/plugins');
		// Gather Plugin information
		$this->core = $motor->tools->files->info(PM_CORE_PLUGINS, 'plugin');
		$this->user = $motor->tools->files->info(PM_USER_PLUGINS, 'plugin');
		$active = $motor->options->option($this->option, array());
		// Include installed Plugin files for at-will instantiation
		foreach ($this->core as $class => $info)
			if (file_exists(PM_CORE_PLUGINS. "/{$info['folder']}/plugin.php")) {
				define(strtoupper($class), PM_CORE_PLUGINS. "/{$info['folder']}");
				define(strtoupper($class). '_URL', PM_CORE_PLUGINS_URL. "/{$info['folder']}");
				include_once(PM_CORE_PLUGINS. "/{$info['folder']}/plugin.php");
			}
			else
				unset($this->core[$class]);
		foreach ($this->user as $class => $info)
			if (!file_exists(PM_USER_PLUGINS. "/{$info['folder']}/plugin.php"))
				unset($this->user[$class]);
			elseif (in_array($class, $active)) {
				define(strtoupper($class), PM_USER_PLUGINS. "/{$info['folder']}");
				define(strtoupper($class). '_URL', PM_USER_PLUGINS_URL. "/{$info['folder']}");
				include_once(PM_USER_PLUGINS. "/{$info['folder']}/plugin.php");
			}
		$this->all = array_merge($this->core, $this->user);
		$this->active = array_merge(array_keys($this->core), $active);
	}

	public function admin($depth = 0) {
		global $motor;
		if (!empty($_POST) && !empty($_POST['manage']))
			return $this->manage($depth);
		$tab = str_repeat("\t", $depth);
		$settings = false;
		if (!empty($_POST)) {
			if (!empty($_POST['manage']))
				return $this->manage($depth);
			elseif (!empty($_POST['plugin']))
				return $this->settings($_POST['plugin'], $depth);
		}
		if (empty($this->options))
			$settings .= "$tab\t<p>No active Plugins have settings pages. Use the <strong>Manage Plugins</strong> button above to install and activate new Plugins.</p>\n";
		else {
			$plugins = $motor->tools->sort_by($this->all, 'name', true);
			foreach ($plugins as $class => $plugin)
				if (array_key_exists($class, $this->options))
					$settings .=
						"$tab\t<form class=\"pm-ui-form pm-ui-flex-item\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}\" enctype=\"multipart/form-data\">\n".
						"$tab\t\t<input type=\"hidden\" name=\"plugin\" value=\"$class\">\n".
						"$tab\t\t<h4>". (!empty($plugin['name']) ? $motor->text($plugin['name'], 'inline-no-links') : $class). "</h4>\n".
						"$tab\t\t<button class=\"plugin-settings-button action\" title=\"Plugin Settings\">\n".
						$motor->tools->svg->icon('settings', $depth + 3).
						"$tab\t\t\tSettings\n".
						"$tab\t\t</button>\n".
						"$tab\t</form>\n";
		}
		return
			"$tab<div class=\"pm-ui-title-controls\">\n".
			"$tab\t<h2>Plugin Settings</h2>\n".
			"$tab\t<form id=\"manage-plugins\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}\" enctype=\"multipart/form-data\">\n".
			// Add update number to Manage Plugins button
			"$tab\t\t<button name=\"manage\" value=\"1\" title=\"Manage Plugins\">\n".
			$motor->tools->svg->icon('shopping-bag', $depth + 3).
			"$tab\t\t\tManage Plugins\n".
			"$tab\t\t</button>\n".
			"$tab\t</form>\n".
			"$tab</div>\n".
			"$tab<p>The Plugins below have <strong>Sitewide Settings</strong> that provide functionality for your site, regardless of the Theme you&rsquo;re using.</p>\n".
			"$tab<div class=\"pm-plugin-settings-ui pm-ui-flex pm-ui-flex-3\">\n".
			$settings.
			"$tab</div>\n";
	}

	public function settings($class, $depth = 0) {
		global $motor;
		if (empty($class))
			return; // No Plugin was specified
		$plugin = false;
		$theme = $motor->theme->_class;
		if (!empty($motor->theme->_plugins->active[$class]))
			$plugin = $motor->theme->_plugins->active[$class];
		else
			foreach ($motor->theme->_plugins->active as $active_class => $active_plugin)
				if ($active_plugin->_class === $class) {
					$plugin = $active_plugin;
					break;
				}
		if (empty($plugin)) {
			$theme = $motor->admin->_class;
			if (!empty($motor->admin->_plugins->active[$class]))
				$plugin = $motor->admin->_plugins->active[$class];
			else
				foreach ($motor->admin->_plugins->active as $active_class => $active_plugin)
					if ($active_plugin->_class === $class) {
						$plugin = $active_plugin;
						break;
					}
		}
		if (empty($plugin))
			return; // Plugin was not found
		$options = $plugin->_site_options($depth + 1);
		return
			$motor->tools->ui->admin_options_form(array(
				'title' => "{$options['name']} Options",
				'name' => 'Options',
				'docs' => $options['docs'],
				'form' => $options['html'],
				'hidden' => array(
					'theme' => $theme,
					'plugin' => $class),
				'class' => 'plugin-site-options',
				'ajax' => true,
				'type' => 'site_options',	// Save is handled inside the base Theme model
				'depth' => $depth,
				'save_icon' => 'check-circle'));
	}

	public function manage($depth) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$sort = array();
		$list = '';
		foreach ($this->user as $class => $plugin)
			$sort[$class] = $plugin['name'];
		natcasesort($sort);
		foreach ($sort as $class => $name)
			$list .= $this->plugin_info($this->user[$class], $this->updates, $depth + 2);
		$update_nag = !empty($this->updates) ?
			' <span class="pm-updates" title="Plugin updates are available">'. count($this->updates). '</span>' : '';
		return
			"$tab<form id=\"select-plugins\" class=\"pm-component-form\" method=\"post\" action=\"". $_SERVER['REQUEST_URI']. "\">\n".
			$motor->tools->ui->alert('Saving Plugins&hellip;', 'saving-plugins', false, 'action', $depth + 1).
			"$tab\t<div class=\"pm-ui-title-controls\">\n".
			"$tab\t\t<h2>Manage Plugins$update_nag</h2>\n".
			"$tab\t\t<button id=\"plugin-upload\" class=\"action\" title=\"upload a new Plugin\">\n".
			$motor->tools->svg->icon('upload', $depth + 3).
			"$tab\t\t\tUpload a New Plugin\n".
			"$tab\t\t</button>\n".
			"$tab\t\t<button id=\"save-plugins\" class=\"save\">\n".
			$motor->tools->svg->icon('check-circle', $depth + 3).
			"$tab\t\t\tSave Plugins\n".
			"$tab\t\t</button>\n".
			"$tab\t</div>\n".
			"$tab\t<div class=\"plugin-list\">\n".
			$list.
			"$tab\t</div>\n".
#			"$tab\t", wp_nonce_field('thesis-update-boxes', '_wpnonce-thesis-update-boxes', true, false), "\n",
			"$tab</form>\n".
			$motor->tools->ui->popup(array(
				'id' => 'plugin-uploader',
				'title' => 'Upload a Plugin',
				'body' => $motor->tools->ui->uploader('plugin-uploader', $depth + 3),
				'depth' => $depth));
	}

	public function plugin_info($plugin, $updates = array(), $depth = 0) {
		global $motor;
		if (empty($plugin) || !is_array($plugin) || empty($plugin['class']))
			return;
		$tab = str_repeat("\t", $depth);
		$id = $motor->text($plugin['class']);
		$active = in_array($plugin['class'], $this->active) ? true : false;
		$checked = $active ? ' checked="checked"' : '';
		$version = '<span class="plugin-version">v '. (!empty($plugin['changelog']) ?
			'<a href="'. $motor->url_escape($plugin['changelog']). '" target="_blank" rel="noopener">'. $motor->text($plugin['version'], 'inline-no-links'). '</a>' :
			$motor->text($plugin['version'], 'inline-no-links')). '</span>';
		$author = !empty($plugin['author']) ?
			" <span class=\"plugin-by\">by</span> <span class=\"plugin-author\">". $motor->text($plugin['author'], 'inline-no-links'). "</span>" : '';
		$docs = !empty($plugin['docs']) ?
			"$tab\t\t\t\t<a href=\"". $motor->url_escape($plugin['docs']). "\" title=\"See Plugin Documentation\" target=\"_blank\" rel=\"noopener noreferrer\">\n".
			$motor->tools->svg->icon('info', $depth + 5).
			"$tab\t\t\t\t</a>\n" : '';
		// Settings could be triggered by the Theme Plugin activation routine; just check for site_options and theme_options
		// (and may need to provide links to both places)
		$settings = false;
		if (array_key_exists($plugin['class'], $this->options)) {
			$settings =
				"$tab\t\t\t\t<button class=\"plugin-settings-button action\" title=\"Plugin Settings\" name=\"plugin\" value=\"{$plugin['class']}\">\n".
				$motor->tools->svg->icon('settings', $depth + 5).
				"$tab\t\t\t\t\tSettings\n".
				"$tab\t\t\t\t</button>\n";
		}
//		$update = !empty($updates[$plugin['class']]) && version_compare($updates[$plugin['class']]['version'], $plugin['version'], '>') ?
//			"<a onclick=\"if(!pm_update_boxes()) return false;\" data-style=\"button update\" href=\"". $motor->admin_url("update.php?action=thesis_update_objects&type=box&class=$id&name=". urlencode($motor->text($plugin['name']))). '"><span data-style="dashicon">&#xf463;</span> '. sprintf('Update %s', $motor->text($plugin['name'], 'inline-no-links')). '</a>' : '';
		$update = false;
		return
			"$tab\t\t<div id=\"plugin-$id\" class=\"plugin". (!empty($checked) ? ' plugin-active' : ''). "\">\n".
			"$tab\t\t\t<label for=\"$id\">\n".
			"$tab\t\t\t\t". $motor->text($plugin['name'], 'inline-no-links'). " $version$author\n".
			$docs.
			"$tab\t\t\t</label>\n".
			"$tab\t\t\t<p class=\"plugin-description\">". $motor->text($plugin['description'], 'inline'). "</p>\n".
			(!empty($update) || !empty($settings) ?
			"$tab\t\t\t<p class=\"plugin-actions\">\n".
			$update.
			$settings.
			"$tab\t\t\t</p>\n" : '').
			"$tab\t\t\t<input type=\"hidden\" name=\"plugins[$id]\" value=\"0\">\n".
			"$tab\t\t\t<input type=\"checkbox\" class=\"plugin-select\" id=\"$id\" name=\"plugins[$id]\" value=\"1\"$checked>\n".
			"$tab\t\t\t<button class=\"button delete plugin-delete\" data-type=\"plugin\" data-class=\"$id\" data-name=\"". $motor->text($plugin['name'], 'no-html'). "\">\n".
			$motor->tools->svg->icon('x-circle', $depth + 4).
			"$tab\t\t\t\tDelete Plugin\n".
			"$tab\t\t\t</button>\n".
			"$tab\t\t</div>\n";
	}

	public function save() {
		global $motor;
		if (empty($_POST['form']))
			return false;
		parse_str(stripslashes($_POST['form']), $form);
		$plugins = array();
		if (!empty($form['plugins']))
			foreach ($form['plugins'] as $class => $active)
				if ($active && !empty($this->user[$class]))
					$plugins[] = $class;
		if (empty($plugins))
			$motor->options->delete($this->option);
		else
			$motor->options->update($this->option, $plugins);
		return true;
	}
}