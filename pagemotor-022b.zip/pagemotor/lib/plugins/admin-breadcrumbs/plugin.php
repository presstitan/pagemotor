<?php
/*
Name: Admin Breadcrumbs
Author: Pearsonified
Description: Output Breadcrumbs for enhanced Admin navigation
Version: 1.0
Requires: 0.1
Class: Admin_Breadcrumbs
Type: Admin
Docs: https://pagemotor.com/plugins/admin/breadcrumbs/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin Breadcrumbs Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_Breadcrumbs extends PM_Plugin {
	public $title = 'Admin Breadcrumbs';
	public $type = 'box';
	public $home = 'PageMotor Admin';
	public $site_title = false;
	public $site_title_plugin = 'Site_Title';

	public function theme_options() {
		return array(
			'home' => array(
				'type' => 'text',
				'width' => 'medium',
				'label' => 'Admin Home Breadcrumb',
				'tooltip' => 'Default is <strong>PageMotor Admin</strong>, but you can make the Home Breadcrumb anything you want!'));
	}

	public function construct() {
		global $motor;
		$this->home = !empty($this->site_options['home']) ? $motor->text($this->site_options['home'], 'inline-no-links') : $this->home;
		$site_title_plugin = $motor->options->option($this->site_title_plugin);
		$site_title = !empty($site_title_plugin) && !empty($site_title_plugin['title']) ? $site_title_plugin['title'] : false;
		$this->site_title = !empty($site_title) ? trim($motor->text($site_title, 'inline-no-links')) : $motor->site_url;
	}

	public function html($depth = 0) {
		global $motor;
		$parents = array();
		$tab = str_repeat("\t", $depth);
		$url = $_SERVER['REQUEST_URI'];
		$base = '/'. (!empty($motor->install_slug) ? "$motor->install_slug/" : ''). "$motor->admin_slug/";
		$id = false;
		if (!$motor->page->is_home) {
			if (empty($motor->page->parent)) {
				if ($motor->page->slug == 'content' || $motor->page->slug == 'admin-content') {
					if (!empty($_POST['content_type'])) {
						if (!empty($_POST['edit_content'])) {
							$parents[] = "<span itemprop=\"name\">Edit Content</span>\n";
							$parents[] =
								"<form class=\"crumbs-form\" method=\"post\" action=\"$url\" enctype=\"multipart/form-data\" itemprop=\"item\">\n".
								"$tab\t\t\t<input type=\"hidden\" name=\"content_type\" value=\"{$_POST['content_type']}\" />\n".
								"$tab\t\t\t<a href=\"\" onclick=\"this.closest('form').submit(); return false;\" itemprop=\"name\">Select Content</a>\n".
								"$tab\t\t</form>\n";
							$parents[] = "<a href=\"$url\" itemprop=\"item\"><span itemprop=\"name\">". ($motor->page->slug == 'admin-content' ? 'Admin ' : ''). "Content Type</span></a>\n";
						}
						else {
							$parents[] = "<span itemprop=\"name\">Select Content</span>\n";
							$parents[] = "<a href=\"$url\" itemprop=\"item\"><span itemprop=\"name\">". ($motor->page->slug == 'admin-content' ? 'Admin ' : ''). "Content Type</span></a>\n";
						}
					}
					else
						$parents[] = "<span itemprop=\"name\">". ($motor->page->slug == 'admin-content' ? 'Admin ' : ''). "Content Type</span>\n";
				}
				elseif ($motor->page->slug === 'plugins' && empty($motor->page->parent)) {
					if (!empty($_POST['plugin']) || !empty($_POST['manage'])) {
						$parents[] = "<span itemprop=\"name\">". (!empty($_POST['plugin']) ? 'Plugin Settings' : 'Manage'). "</span>\n";
						$parents[] = "<a href=\"$url\" itemprop=\"item\"><span itemprop=\"name\">". $motor->text($motor->page->content['title'], 'inline-no-links'). "</span></a>\n";
					}
					else
						$parents[] = "<span itemprop=\"name\">". $motor->text($motor->page->content['title'], 'inline-no-links'). "</span>\n";
				}
				else
					$parents[] = "<span itemprop=\"name\">". $motor->page->content['title']. "</span>\n";
			}
			else {	// Page parent is NOT empty
				if ($motor->page->content['sub_type'] == 'elements' && $motor->page->parent['type'] == 'admin-theme' && !empty($_POST['instance'])) {
					$parents[] = "<span itemprop=\"name\">Edit Element</span>\n";
					$parents[] = "<a href=\"$url\" itemprop=\"item\"><span itemprop=\"name\">Editable Content</span></a>\n";
				}
				elseif ($motor->page->content['sub_type'] === 'options' && $motor->page->parent['type'] === 'admin-theme' && !empty($_POST['plugin'])) {
					$parents[] = "<span itemprop=\"name\">Settings</span>\n";
					$parents[] = "<a href=\"$url\" itemprop=\"item\"><span itemprop=\"name\">". $motor->text($motor->page->content['title'], 'inline-no-links'). "</span></a>\n";
				}
				else
					$parents[] = "<span itemprop=\"name\">". $motor->page->content['title']. "</span>\n";
				$id = $motor->page->parent['id'];
				$parents = $this->get_parents($id, $url, $base, $parents);
			}
		}
		$parents[] = $motor->page->is_home ?
			"<span itemprop=\"name\" class=\"logo-pagemotor\">\n".
			$motor->tools->svg->icon('pagemotor', $depth + 3, false, false, 1).
			"$tab\t\t</span>\n".
			"$tab\t\t<strong>$this->home</strong>\n" :
			"<a href=\"$base\" class=\"logo-pagemotor\" itemprop=\"item name\">\n".
			$motor->tools->svg->icon('pagemotor', $depth + 3, false, false, 1).
			"$tab\t\t</a>\n";
		if (!empty($parents)) {
			foreach ($parents as $count => $parent)
				$parents[$count] =
					$parent.
					"$tab\t\t<meta itemprop=\"position\" content=\"". (count($parents) - $count). "\">";
			echo
				"$tab<div class=\"crumbs\" itemscope itemtype=\"https://schema.org/BreadcrumbList\">\n".
				"$tab\t<span class=\"crumbs-crumb crumbs-item crumb-root\" itemprop=\"itemListElement\" itemscope itemtype=\"https://schema.org/ListItem\">\n".
				"$tab\t\t". implode("\n$tab\t</span>\n$tab\t<span class=\"crumbs-sep crumbs-item\">". apply_filters("{$this->_class}-separator", '&rarr;'). "</span>\n$tab\t<span class=\"crumbs-crumb crumbs-item\" itemprop=\"itemListElement\" itemscope itemtype=\"https://schema.org/ListItem\">\n$tab\t\t", apply_filters("{$this->_class}-trail", array_reverse($parents))). "\n".
				"$tab\t</span>\n".
//				"$tab</div>\n".
				"$tab</div>\n";
		}
	}

	private function get_parents($id, $url, $base, $parents = array()) {
		global $motor;
		if (empty($id) || $url == $base || empty($url))
			return $parents;
		$parent = $motor->content->get_by_id($id, true);
		$url = preg_replace('/'. preg_quote(basename($url). '/', '/'). '$/', '', $url);
		$parents[] = "<a href=\"". $motor->url_escape($url). "\" itemprop=\"item\"><span itemprop=\"name\">". $parent['title']. "</span></a>\n";
		if (!empty($parent['parent']))
			$this->get_parents($parent['parent'], $url, $base, $parents);
		return $parents;
	}
}