<?php
/*
Name: Admin Footer
Author: Pearsonified
Description: Output the PageMotor version number with a pithy message
Version: 1.0
Requires: 0.1
Class: Admin_Footer
Type: Admin
Docs: https://pagemotor.com/plugins/admin/footer/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin Footer Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_Footer extends PM_Plugin {
	public $title = 'Admin Footer';
	public $type = 'box';

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$beta = $motor->beta ? " <span class=\"pm-beta\">beta</span>" : false;
		echo
			"<p>You are running PageMotor version {$motor->version}$beta</p>\n";
	}
}