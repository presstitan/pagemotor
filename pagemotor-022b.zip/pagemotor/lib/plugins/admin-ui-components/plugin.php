<?php
/*
Name: Admin UI: Components
Author: Pearsonified
Description: Output the appropriate Admin Component UI based on the current URL
Version: 1.0
Requires: 0.1
Class: Admin_UI_Components
Type: Admin
Docs: https://pagemotor.com/plugins/admin/ui/components/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin UI: Components Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_UI_Components extends PM_Plugin {
	public $title = 'Admin UI: Components';
	public $type = 'box';
	private $types = array(
		'admin-plugins',
		'admin-themes');

	public function js() {
		global $motor;
		if ($motor->page->is_admin && in_array($motor->page->content['type'], $this->types)) {
			if (!empty($_POST['manage']))
				return array(
					'ajax',
					'jquery',
					'pm-components');
			elseif (!empty($_POST['plugin']))
				return array(
					'ajax',
					'jquery',
					'pm-options',
					'pm-options-save');
			else
				return array();
		}
		else
			return array();
	}

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		if (empty($motor->page->parent_slug) && !empty($motor->page->content['type']) && in_array($motor->page->content['type'], $this->types)) {
			$admin_theme = false;
			if ($motor->tools->text->contains($motor->page->slug, 'admin-')) {
				$admin = '_'. str_replace('admin-', '', $motor->page->slug);
				$admin_theme = true;
			}
			else
				$admin = "_{$motor->page->slug}";
			echo
				"$tab<div id=\"admin-canvas\">\n".
				$motor->admin->$admin($admin_theme, $depth + 1).
				"$tab</div>\n";
		}
		else
			echo
				"$tab<div id=\"admin-canvas\">\n".
				"$tab\t<p>The Admin UI: Components Plugin is not designed to run on this Admin page.</p>\n".
				"$tab</div>\n";
	}
}