<?php
/*
Name: Admin UI: Content Editor
Author: Pearsonified
Description: Output the Content Editor UI
Version: 1.0
Requires: 0.1
Class: Admin_UI_Content_Editor
Type: Admin
Docs: https://pagemotor.com/plugins/admin/ui/content-editor/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin UI: Content Editor Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_UI_Content_Editor extends PM_Plugin {
	public $title = 'Admin UI: Content Editor';
	public $type = 'box';
	public $slug_theme = 'content';
	public $slug_admin = 'admin-content';
	public $content_type = 'admin-content';
	public $textarea = '#_content';

	public function register_js() {
		$css = $css_path = false;
		$location = $this->get_location();
		if (!empty($location)) {
			$css = ($location == 'admin' ? PM_ADMIN_THEME_URL : PM_THEME_URL). '/css-editor.css';
			$css_path = ($location == 'admin' ? PM_ADMIN_THEME : PM_THEME). '/css-editor.css';
		}
		return array(
			'content-editor-info' => array(
				'script' =>
					"<script>\n".
					"var pm_editor_id = '$this->textarea';\n".
					(!empty($css) ?
					"var pm_editor_css = '$css?v=". filemtime($css_path). "';\n" : '').
					"</script>"));
	}

	public function js() {
		return array(
			'ajax',
			'jquery',
			'content-editor-info',
			'tinymce',
			'content-manager',
			'content-editor',
			'pm-options');
	}

	private function get_location() {
		global $motor;
		if (!empty($motor->page->content) && !empty($motor->page->content['type'])
		&& $motor->page->content['type'] == $this->content_type
		&& ($motor->page->slug == $this->slug_theme || $motor->page->slug == $this->slug_admin)) {
			if ($motor->page->slug == $this->slug_admin)
				return 'admin';
			else
				return 'theme';
		}
		else
			return false;
	}

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		if (!empty($motor->page->content) && !empty($motor->page->content['type'])
		&& $motor->page->content['type'] == $this->content_type
		&& ($motor->page->slug == $this->slug_theme || $motor->page->slug == $this->slug_admin)) {
			$admin = false;
			if ($motor->page->slug == $this->slug_admin)
				$admin = true;
			echo
				"$tab<div id=\"admin-canvas\">\n".
				$motor->admin->_content($admin, $depth + 1).
				"$tab</div>\n";
		}
		else
			echo
				"$tab<div id=\"admin-canvas\">\n".
				"$tab\t<p>The Admin UI: Content Editor Plugin is not designed to run on this Admin page.</p>\n".
				"$tab</div>\n";
	}
}