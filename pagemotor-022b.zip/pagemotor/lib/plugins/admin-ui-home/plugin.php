<?php
/*
Name: Admin UI: Home
Author: Pearsonified
Description: Output the Admin Home UI
Version: 1.0
Requires: 0.1
Class: Admin_UI_Home
Type: Admin
Docs: https://pagemotor.com/plugins/admin/ui/home/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin UI: Home Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_UI_Home extends PM_Plugin {
	public $title = 'Admin UI: Home';
	public $type = 'box';

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		if ($motor->page->is_admin && $motor->page->is_home)
			$motor->admin->_home($depth);
		else
			echo
				"$tab<div id=\"admin-canvas\">\n".
				"$tab\t<p>The Admin UI: Home Plugin is not designed to run on this Admin page.</p>\n".
				"$tab</div>\n";
	}
}