<?php
/*
Name: Admin UI: Theme Editor Tabs
Author: Pearsonified
Description: Output tabs to control the active pane in the Theme Editor
Version: 1.0
Requires: 0.1
Class: Admin_UI_Theme_Editor_Tabs
Type: Admin
Docs: https://pagemotor.com/plugins/admin/ui/theme/editor-tabs/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin UI: Theme Editor Tabs Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_UI_Theme_Editor_Tabs extends PM_Plugin {
	public $title = 'Admin UI: Theme Editor Tabs';
	public $type = 'box';

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		echo
			"$tab<ul class=\"theme-editor-tabs select-flex\">\n".
			"$tab\t<li><button class=\"ui theme-pane-tab\" data-pane=\"html\" title=\"Edit HTML Templates\">HTML</button></li>\n".
			"$tab\t<li><button class=\"ui theme-pane-tab\" data-pane=\"css\" title=\"Edit CSS\">CSS</button></li>\n".
			"$tab\t<li><button class=\"ui theme-pane-tab\" data-pane=\"images\" title=\"Edit Images\">Images</button></li>\n".
			"$tab\t<li><button class=\"ui theme-pane-tab\" data-pane=\"data\" title=\"Backup and restore Theme data\">Data Manager</button></li>\n".
			"$tab\t<li>\n".
			"$tab\t\t<button id=\"pm-launch-canvas\" class=\"action\">\n".
			$motor->tools->svg->icon('external-link', $depth + 3).
			"$tab\t\t\tCanvas\n".
			"$tab\t\t</button>\n".
			"$tab\t</li>\n".
			"$tab</ul>\n";
	}
}