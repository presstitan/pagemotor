<?php
/*
Name: Admin UI: Theme Elements
Author: Pearsonified
Description: Output the Theme Editable Elements UI
Version: 1.0
Requires: 0.1
Class: Admin_UI_Theme_Elements
Type: Admin
Docs: https://pagemotor.com/plugins/admin/ui/theme/elements/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin UI: Theme Elements Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_UI_Theme_Elements extends PM_Plugin {
	public $title = 'Admin UI: Theme Elements';
	public $type = 'box';
	public $editor_slug = 'elements';
	public $content_type = 'admin-theme';
	public $content_sub_type = 'elements';

	public function js() {
		return array(
			'ajax',
			'jquery',
			'pm-options',
			'pm-options-save');
	}

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		if ($motor->page->slug == $this->editor_slug
		&& !empty($motor->page->content) && !empty($motor->page->content['type']) && !empty($motor->page->content['sub_type'])
		&& $motor->page->content['type'] == $this->content_type && $motor->page->content['sub_type'] == $this->content_sub_type) {
			if ($motor->page->parent_slug == $motor->admin->_admin_slug)
				$theme = $motor->admin;
			elseif ($motor->page->parent_slug == $motor->theme->_admin_slug)
				$theme = $motor->theme;
			echo
				"$tab<div id=\"admin-canvas\">\n".
				$theme->_admin_elements($depth + 1).
				"$tab</div>\n";
		}
		else
			echo
				"$tab<div id=\"admin-canvas\">\n".
				"$tab\t<p>The Admin UI: Theme Elements Plugin is not designed to run on this Admin page.</p>\n".
				"$tab</div>\n";
	}
}