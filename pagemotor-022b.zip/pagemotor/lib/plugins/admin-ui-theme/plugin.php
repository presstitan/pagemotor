<?php
/*
Name: Admin UI: Theme
Author: Pearsonified
Description: Output the Theme and Admin Theme UI
Version: 1.0
Requires: 0.1
Class: Admin_UI_Theme
Type: Admin
Docs: https://pagemotor.com/plugins/admin/ui/theme/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin UI: Theme Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_UI_Theme extends PM_Plugin {
	public $title = 'Admin UI: Theme';
	public $type = 'box';
	public $content_type = 'admin-theme';
	public $type_options = 'options';

	public function js() {
		global $motor;
		if ($motor->page->is_admin && $motor->page->content['type'] === $this->content_type && $motor->page->content['sub_type'] === $this->type_options)
			return array(
				'ajax',
				'jquery',
				'pm-options',
				'pm-options-save');
		else
			return array();
	}

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		if ($motor->page->is_admin && $motor->page->content['type'] === $this->content_type) {
			$theme = in_array($motor->admin->_admin_slug, array($motor->page->slug, $motor->page->parent_slug)) ?
				$motor->admin :
				$motor->theme;
			$admin = '_admin'. (!empty($motor->page->content['sub_type']) ? "_{$motor->page->content['sub_type']}" : '');
			echo
				"$tab<div id=\"admin-canvas\">\n".
				$theme->$admin($depth + 1).
				"$tab</div>\n";
		}
		else
			echo
				"$tab<div id=\"admin-canvas\">\n".
				"$tab\t<p>The Admin UI: Theme Plugin can only run on a Theme UI admin page.</p>\n".
				"$tab</div>\n";
	}
}