<?php
/*
Name: Admin View Site
Author: Pearsonified
Description: Output button to view site
Version: 1.0
Requires: 0.1
Class: Admin_View_Site
Type: Admin
Docs: https://pagemotor.com/plugins/admin/view-site/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Admin View Site Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Admin_View_Site extends PM_Plugin {
	public $title = 'Admin View Site';
	public $type = 'box';

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		echo
			"$tab<a href=\"". $motor->url(). "\" class=\"button ui-alt\" target=\"blank\" rel=\"noopener noreferrer\">\n".
			$motor->tools->svg->icon('external-link', $depth + 1).
			"$tab\tView Site\n".
			"$tab</a>\n";
	}
}