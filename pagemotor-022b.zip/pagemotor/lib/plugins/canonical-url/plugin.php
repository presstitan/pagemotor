<?php
/*
Name: Canonical URL
Author: Pearsonified
Description: Output an HTML &lt;link&gt; to indicate a Canonical URL for the current page
Version: 1.0
Requires: 0.1
Class: Canonical_URL
Docs: https://pagemotor.com/plugins/html/head/canonical-url/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Canonical URL Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class Canonical_URL extends PM_Plugin {
	public $title = 'Canonical URL';
	public $type = 'box';
	public $head = true;
	public $custodians = array(
		'HTML_Head' => array(
			'order' => 10,
			'startup' => true));
//	public $links = array();

	public function content_options() {
		return array(
			'title' => $this->title,
			'types' => apply_filters("{$this->_class}-content-types", array('page')),
			'fields' => array(
				'url' => array(
					'type' => 'text',
					'width' => 'full',
					'code' => true,
					'label' => 'Canonical URL Override',
					'tooltip' => 'Use this option for certain situations where you want to supply your own canonical URL for a given page.',
					'description' => '(including <code>https://</code>)')));
	}

	public function html($depth = 0) {
		global $motor;
		$url = !empty($this->content_options) && !empty($this->content_options['url']) ?
			$this->content_options['url'] :
			$motor->page->url;
		if (!empty($url))
			echo "<link href=\"$url\" rel=\"canonical\">\n";
	}
}