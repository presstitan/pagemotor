<?php
/*
Name: Favicon
Author: Pearsonified
Description: Output a favicon
Version: 1.0
Requires: 0.1
Class: Favicon
Docs: https://pagemotor.com/plugins/html/head/favicon/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Favicon Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Favicon extends PM_Plugin {
	public $title = 'Favicon';
	public $type = 'box';
	public $head = true;
	public $custodians = array(
		'HTML_Head' => array(
			'order' => 15,
			'startup' => true));
	public $favicon = PM_IMAGES_URL. '/pagemotor.png';

	public function theme_options() {
		return array(
			'url' => array(
				'type' => 'text',
				'width' => 'text-column',
				'code' => true,
				'label' => 'Favicon URL',
				'tooltip' => $this->admin_theme ? 'PageMotor will use the PageMotor logo as the default Favicon on all Admin pages. You can override this by entering your own Favicon URL here.' : false));
/*		return array(
			'image' => array(
				'type' => 'image_upload',
				'label' =>  'Upload a Favicon',
				'tooltip' => sprintf('If you don&#39;t already have a favicon, you can create one with this handy <a href="%s" target="_blank" rel="noopener noreferrer">online tool</a>.', 'https://www.favicon-generator.org/'),
				'upload_label' => 'Upload Image',
				'prefix' => $this->_class));*/
	}

	protected function construct() {
		global $motor;
		if ($motor->page->is_admin)
			new PM_Uploader(array(
				'title' => 'Upload Image',
				'prefix' => $this->_class,
				'file_type' => 'image',
				'show_delete' => !empty($this->theme_options['image']) && !empty($this->theme_options['image']['url']) ? true : false,
				'delete_text' => 'Remove Image',
				'save_callback' => array($this, 'save')));
	}

	public function html($depth = 0) {
		global $motor;
		$url = !empty($this->theme_options['url']) ? $this->theme_options['url'] : ($this->admin_theme ? $this->favicon : false);
/*		$url = !empty($this->theme_options['image']) && !empty($this->theme_options['image']['url']) ?
			$this->theme_options['image']['url'] :
			false; //THESIS_IMAGES_URL. '/favicon.ico';*/
//		$url = apply_filters($this->class, !empty($this->theme_options['image']) && !empty($this->theme_options['image']['url']) ?
//			$this->theme_options['image']['url'] :
//			THESIS_IMAGES_URL. '/favicon.ico');
		// need to escape the URL
		if (!empty($url))
			echo "<link href=\"". $motor->url_escape($url). "\" rel=\"shortcut icon\">\n";
	}
}