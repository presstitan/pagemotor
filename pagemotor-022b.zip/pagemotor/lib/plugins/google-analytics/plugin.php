<?php
/*
Name: Google Analytics
Author: Pearsonified
Description: Add Google Analytics to your site
Version: 1.0
Requires: 0.1
Class: PM_Google_Analytics
Docs: https://pagemotor.com/plugins/google-analytics/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Google Analytics Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Google_Analytics extends PM_Plugin {
	public $title = 'Google Analytics';
	public $type = 'box';
	public $head = true;
	public $custodians = array(
		'HTML_Head' => array(
			'order' => 1,
			'startup' => true));

	public function register_js() {
		return array(
			'google-analytics' => array(
				'prefetch' => array(
					'google-tag-manager' => 'https://googletagmanager.com'),
				'preconnect' => array(
					'google-analytics' => 'https://www.google-analytics.com')));
	}

	public function js() {
		return !empty($this->site_options['ga']) ?
			array('google-analytics') : array();
	}

	public function site_options() {
		return array(
			'ga' => array(
				'type' => 'text',
				'width' => 'medium',
				'label' => 'Google Analytics Measurement ID',
				'tooltip' => sprintf('To add Google Analytics tracking to your site, simply enter your Measurement ID here. This number takes the general form <code>G-XXXXXXXXXX</code> and can be found in your <a href="%s">Google Analytics dashboard</a> (login required).', 'https://google.com/analytics/')));
	}

	public function html($depth = 0) {
		global $motor;
		if (empty($this->site_options['ga']) || ($motor->page->is_admin && !apply_filters("{$this->_class}-show-on-admin", false)))
			return false;
		$tracking = trim($motor->text($this->site_options['ga']));
		$events = apply_filters("{$this->_class}-gtag-events", false);
		echo
			"<script src=\"https://www.googletagmanager.com/gtag/js?id=$tracking\" async></script>\n",
			"<script>\n",
			"window.dataLayer = window.dataLayer || [];\n",
			"function gtag(){dataLayer.push(arguments);}\n",
			"gtag('js', new Date());\n",
			apply_filters("{$this->_class}-gtag-config", "gtag('config', '$tracking');", $tracking), "\n",
			(!empty($events) ?
			"$events\n" : ''),
			"</script>\n";
	}
}