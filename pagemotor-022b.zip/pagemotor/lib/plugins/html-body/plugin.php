<?php
/*
Name: HTML Body
Author: Pearsonified
Description: Output the HTML &lt;body&gt; tag
Version: 1.0
Requires: 0.1
Class: HTML_Body
Docs: https://pagemotor.com/plugins/html/body/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor HTML Body Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class HTML_Body extends PM_Plugin {
	public $title = 'HTML Body';
	public $type = 'container';
	public $root = true;
	public $toggle = true;
	public $admin_class = 'pm-admin';

	public function html_options() {
		global $motor;
		$html = $motor->options->html(false, false, true);
		unset($html['id']);
		return $html;
	}

	public function content_options() {
		return array(
			'title' => 'Custom Body Class',
			'types' => apply_filters("{$this->_class}-content-types", array('page')),
			'order' => 11,
			'fields' => array(
				'class' => array(
					'type' => 'text',
					'width' => 'medium',
					'code' => true,
					'label' => 'HTML Body Class',
					'tooltip' => 'If you want to style this page individually, you should enter a class name here. Anything you enter here will appear on this page&#8217;s <code>&lt;body&gt;</code> tag. Separate multiple classes with spaces.<br /></br /><strong>Note:</strong> Class names cannot begin with numbers!')));
	}

	public function template_options() {
		return array(
			'title' => 'Body Class',
			'fields' => array(
				'class' => array(
					'type' => 'text',
					'width' => 'medium',
					'code' => true,
					'label' => 'Template Body Class',
					'tooltip' => 'If you wish to provide a custom body class for this template, you can do that here. Please note that a naming conflict could cause unintended results, so be careful when choosing a class name.')));
	}

	public function container_open($depth = 0) {
		$id = is_string($id = $this->id()) && !empty($id) ? " id=\"$id\"" : '';
		echo "<body$id", $this->classes(), (!empty($this->box_options['attributes']) ? ' '. trim($this->box_options['attributes']) : ''), ">\n";
		// hook_top_body
	}

	private function id() {
		global $motor;
		return $motor->page->is_admin ?
			$motor->admin->_body_id() : false;
	}

	private function classes() {
		global $motor;
		$classes = array();
		if (($motor->page->is_admin && is_array($theme_classes = $motor->admin->_body_classes()))
		|| ($motor->page->is_theme && is_array($theme_classes = $motor->theme->_body_classes())))
			$classes = $theme_classes;
		if (!empty($this->template_options['class']))
			$classes[] = trim($this->template_options['class']);
		if (!empty($this->box_options['class']))
			$classes[] = trim($this->box_options['class']);
		if (!empty($this->content_options['class']))
			$classes[] = trim($this->content_options['class']);
//		$classes = is_array($filtered = apply_filters("{$this->class}_class", $classes)) && !empty($filtered) ? $filtered : $classes;
		return !empty($classes) ?
			' class="'. trim($motor->text(implode(' ', array_map('trim', $classes)))). '"' : '';
	}

	public function container_close($depth = 0) {
		global $motor;
		$theme = $this->admin_theme ? 'admin' : 'theme';
		$js = array();
		if (!empty($motor->$theme->_js))
			foreach ($motor->$theme->_js as $name)
				if (!empty($motor->$theme->_registered_js[$name]['url']))
					$js[] = "<script src=\"". $motor->url_escape($motor->$theme->_registered_js[$name]['url']). "\"></script>";
				elseif (!empty($motor->$theme->_registered_js[$name]['script']))
					$js[] = $motor->$theme->_registered_js[$name]['script'];
		if (!empty($js))
			echo implode("\n", $js). "\n";
		// hook_bottom_body
		echo "</body>\n";
	}
}