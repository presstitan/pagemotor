<?php
/*
Name: HTML Container
Author: Pearsonified
Description: Output an HTML container
Version: 1.0
Requires: 0.1
Class: HTML_Container
Docs: https://pagemotor.com/plugins/html/container/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor HTML Container Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class HTML_Container extends PM_Plugin {
	public $title = 'HTML Container';
	public $name = 'Container';
	public $type = 'container';
	public $tab = false;
	public $tag = 'div';
	public $hook = false;

	public function html_options() {
		global $motor;
		$html = $motor->options->html(array(
			'div' => 'div',
			'p' => 'p',
			'section' => 'section',
			'article' => 'article',
			'header' => 'header',
			'footer' => 'footer',
			'aside' => 'aside',
			'span' => 'span',
			'nav' => 'nav',
			'none' => 'no HMTL wrap'), 'div', true);
		$html['tag']['dependents'] =
			array('div', 'p', 'section', 'article', 'header', 'footer', 'aside', 'span', 'nav');
		$html['id']['parent'] = $html['class']['parent'] = $html['attributes']['parent'] =
			array('tag' => array('div', 'p', 'section', 'article', 'header', 'footer', 'aside', 'span', 'nav'));
		return $html;
	}

	public function container_open($depth = 0) {
		global $motor;
		$this->tab = str_repeat("\t", $depth);
		$this->tag = !empty($this->box_options['tag']) ? $this->box_options['tag'] : $this->tag;
		if ($this->tag == 'none')
			return;
		$this->hook = trim($motor->text(!empty($this->box_options['_id']) ?
			$this->box_options['_id'] : (!empty($this->box_options['hook']) ?
			$this->box_options['hook'] : false)));
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_before_$this->hook");
		$id = trim($motor->text(!empty($this->box_options['id']) ? $this->box_options['id'] : ''));
		$class = trim($motor->text(!empty($this->box_options['class']) ? $this->box_options['class'] : ''));
		$attributes = trim(!empty($this->box_options['attributes']) ? $this->box_options['attributes'] : '');
		echo
			"$this->tab<$this->tag",
			(!empty($id) ? " id=\"$id\"" : ''),
			(!empty($class) ? " class=\"$class\"" : ''),
			(!empty($attributes) ? " $attributes" : ''), ">\n";
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_top_$this->hook");
	}

	public function container_close($depth = 0) {
		global $motor;
		if ($this->tag == 'none')
			return;
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_bottom_$this->hook");
		echo
			"$this->tab</$this->tag>\n";
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_after_$this->hook");
	}
}