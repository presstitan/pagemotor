<?php
/*
Name: HTML Head
Author: Pearsonified
Description: Output the HTML &lt;head&gt; tag
Version: 1.0
Requires: 0.1
Class: HTML_Head
Docs: https://pagemotor.com/plugins/html/head/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor HTML Head Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class HTML_Head extends PM_Plugin {
	public $title = 'HTML Head';
	public $type = 'container';
	public $root = true;
	public $head = true;

	public function container_open($depth = 0) {
		global $motor;
		$theme = $this->admin_theme ? 'admin' : 'theme';
		// make this an option?
		$attributes = false;
		$prefetch = $preconnect = $preload = array();
//		$attributes = apply_filters("{$this->class}-attributes", false);
		echo
			"<head", (!empty($attributes) ? " $attributes" : ''), ">\n",
			"<meta charset=\"$motor->charset\">\n",
			"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n";
		foreach ($motor->$theme->_prefetch as $name => $source)
			$prefetch[] = "<link href=\"". $motor->url_escape($source). "\" rel=\"dns-prefetch\">";
		foreach ($motor->$theme->_preconnect as $name => $source)
			$preconnect[] = "<link href=\"". $motor->url_escape($source). "\" rel=\"preconnect\" crossorigin>";
		foreach ($motor->$theme->_preload as $name => $resource)
			if (!empty($resource['url']) && !empty($resource['as']))
				$preload[] = "<link href=\"". $motor->url_escape($resource['url']). "\" rel=\"preload\" as=\"{$resource['as']}\"". (!empty($resource['crossorigin']) ? ' crossorigin' : ''). ">";
		if (!empty($prefetch) || !empty($preconnect) || !empty($preload))
			echo implode("\n", array_merge($prefetch, $preconnect, $preload)). "\n";
		// NOTE: Head hooks intentionally named differently to avoid conflicts with user-defined hooks in the <body>
#		$thesis->api->hook('hook_head_top');
	}

	public function container_close($depth = 0) {
#		$thesis->api->hook('hook_head_bottom');
		echo
			"</head>\n";
	}
}