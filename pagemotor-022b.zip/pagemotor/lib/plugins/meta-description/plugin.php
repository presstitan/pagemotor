<?php
/*
Name: Meta Description
Author: Pearsonified
Description: Output an HTML &lt;meta&gt; description tag
Version: 1.0
Requires: 0.1
Class: Meta_Description
Docs: https://pagemotor.com/plugins/html/head/meta-description/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Meta Description Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Meta_Description extends PM_Plugin {
	public $title = 'Meta Description';
	public $type = 'box';
	public $head = true;
	public $custodians = array(
		'HTML_Head' => array(
			'order' => 26,
			'startup' => true));

	public function content_options() {
		return array(
			'title' => $this->title,
			'types' => apply_filters("{$this->_class}-content-types", array('page')),
			'order' => 13,
			'fields' => array(
				'description' => array(
					'type' => 'textarea',
					'rows' => 3,
					'label' => $this->title,
					'tooltip' => 'Entering a meta description is just one more thing you can do to seize an on-page SEO opportunity. Remember&#8212;a good meta description is both informative and concise.',
					'counter' => 'Search engines allow up to 165 characters for the description.')));
	}

	public function html($depth = 0) {
		global $motor;
		$meta = !empty($this->content_options) && !empty($this->content_options['description']) ?
			$this->content_options['description'] : false;
		if (!empty($meta))
			echo "<meta name=\"description\" content=\"", trim($motor->text($meta, 'no-html')), "\" />\n";
	}
}