<?php
/*
Name: Meta Robots
Author: Pearsonified
Description: Output an HTML &lt;meta&gt; robots tag
Version: 1.0
Requires: 0.1
Class: Meta_Robots
Docs: https://pagemotor.com/plugins/html/head/meta-robots/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Meta Robots Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Meta_Robots extends PM_Plugin {
	public $title = 'Meta Robots';
	public $type = 'box';
	public $head = true;
	public $custodians = array(
		'HTML_Head' => array(
			'order' => 20,
			'startup' => true));
//	private $robots = array();

	public function box_options() {
		return array(
			'directory' => array(
				'type' => 'checkbox',
				'label' => 'Directory Tags (Sitewide)',
				'tooltip' => 'For SEO purposes, we recommend turning on both of these options.', 
				'options' => array(
					'noodp' => '<code>noodp</code>',
					'noydir' => '<code>noydir</code>'),
				'default' => array(
					'noodp' => true,
					'noydir' => true)));
	}

	public function content_options() {
		return array(
			'title' => $this->title,
			'types' => apply_filters("{$this->_class}-content-types", array('page')),
			'order' => 14,
			'fields' => array(
				'robots' => array(
					'type' => 'checkbox',
					'label' => $this->title,
					'tooltip' => 'Fine-tune the SEO on every page of your site with these handy robots meta tag selectors.',
					'options' => array(
						'noindex' => '<code>noindex</code> this page',
						'nofollow' => '<code>nofollow</code> this page',
						'noarchive' => '<code>noarchive</code> this page'))));
	}

	public function html($depth = 0) {
		global $motor;
		$content = array();
		$robots = !empty($this->content_options['robots']) ?
			$this->content_options['robots'] : ($motor->page->is_search || $motor->page->error ?
			array('noindex' => true, 'nofollow' => true, 'noarchive' => true) : array());
		if (!empty($this->box_options['directory']) && !empty($this->box_options['directory']['noodp']))
			$robots['noodp'] = true;
		if (!empty($this->box_options['directory']) && !empty($this->box_options['directory']['noydir']))
			$robots['noydir'] = true;
		if (!empty($robots))
			foreach ($robots as $tag => $value)
				if ($value)
					$content[] = $tag;
		if (!empty($content))
			echo '<meta name="robots" content="', apply_filters($this->_class, implode(', ', $content)), "\">\n";
	}
}