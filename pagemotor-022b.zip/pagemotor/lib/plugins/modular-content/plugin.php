<?php
/*
Name: Modular Content
Author: Pearsonified
Description: Add Modular Content capabilities to any PageMotor Theme
Version: 1.0
Requires: 0.1
Class: Modular_Content
Docs: https://pagemotor.com/plugins/modular-content/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Modular Content Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Modular_Content extends PM_Plugin {
	public $title = 'Modular Content';
	public $type = 'box';
	protected $filters = array(
		'docs' => 'https://diythemes.com/thesis/rtfm/modular-content/#section-fallbacks');
	public $content_type = 'modular';
	public $styles = array();
	public $content = array();
	public $fetched = false;
	public $hooked = false;
	public $class = 'modular';

	public function content_types() {
		return array(
			'modular' => array(
				'name' => $this->title,
				'environment' => array('admin', 'theme'),
				'no-slug' => true,
				'fields' => array('title', 'content')));
	}

	public function theme_options() {
		if (empty($this->content)) {
			if ($this->fetched)
				return false;
			else
				$this->get_content();
		}
		$options = array('' => 'Select fallback content:');
		if (!empty($this->content))
			foreach ($this->content as $id => $content)
				if (!empty($content['title']))
					$options[$id] = $content['title'];
		$tab = "\t\t\t\t";
		return array(
			'info' => array(
				'type' => 'custom',
				'output' =>
					"$tab<div class=\"text note\">\n".
					"$tab\t<p>Set <strong>Modular Content fallbacks</strong> to display content automatically on Pages where you have not specified Modular Content within the Page Editor.</p>\n".
					"$tab\t<p>This is useful if you want to display something like a primary email form on every Page, but you also want to be able to display a different form only on certain Pages.</p>\n".
					"$tab</div>\n"),
			'pages' => array(
				'type' => 'select',
				'label' => 'Fallback for Pages',
				'options' => $options),
			'style' => array(
				'type' => 'select',
				'label' => 'Default Display Style',
				'description' => '<strong>Note:</strong> Themes may not support all styles!',
				'options' => array_merge(array(
					'' => 'Unstyled'),
					$this->styles)));
	}

	public function content_options() {
		global $motor;
		$this->get_content();
		$mc_options = array(
			// Just formatting?
			"{$this->_class}_formatting" => array(
				'title' => sprintf('%s Formatting Options', $this->title),
				'types' => array($this->content_type),
				'fields' => array(
					'format' => array(
						'type' => 'checkbox',
						'options' => array(
							'no-autop' => sprintf('disable automatic <code>&lt;p&gt;</code> tags for this %s', $this->title))))),
			// Just shortcode?
			"{$this->_class}_shortcode" => array(
				'title' => sprintf('%s Shortcode', $this->title),
				'types' => array($this->content_type),
//				'context' => 'side',
				'fields' => array(
					'shortcode' => array(
						'type' => 'custom',
						'output' =>
							"<p class=\"field-option\" id=\"{$this->content_type}-shortcode\"></p>\n".
							"<a href=\"https://diythemes.com/thesis/rtfm/modular-content/#section-shortcodes\" target=\"_blank\" rel=\"noopener noreferrer\">See MC shortcode options &nearr;</a>\n"))));
		if (!empty($this->content)) {
			$options = array(
				'' => sprintf('Display %s fallback', $this->title),
				'no-fallback' => sprintf('Do not display %s on this page', $this->title));
			foreach ($this->content as $content)
				if (!empty($content['id']) && !empty($content['title']))
					$options[$content['id']] = $content['title'];
			$mc_options[$this->class] = array(
				'title' => $this->title,
				'types' => apply_filters("{$this->class}-content-types", array('page')),
				'fields' => array(
					'content' => array(
						'type' => 'select',
						'label' => 'Content to Display',
						'tooltip' => sprintf('Visit the <a href="%1$s">%2$s options page</a> to set your default fallback for Pages.', $motor->admin_url('admin.php?page=thesis&canvas=skin_thesis_modular_content'), $this->title),
						'options' => $options),
					'location' => array(
						'type' => 'select',
						'label' => 'Output Location',
						'options' => array_merge(array(
							'' => sprintf('%s Box', $this->title)),
							apply_filters("{$this->class}-locations", array()))),
					'style' => array(
						'type' => 'select',
						'label' => 'Display Style',
						'description' => '<strong>Note:</strong> Styles may not work with all Themes and output locations!',
						'options' => array_merge(array(
							'' => 'Default',
							'unstyled' => 'Unstyled')),
							$this->styles)));
		}
		return $mc_options;
	}

	protected function construct() {
		global $motor;
		$this->styles = apply_filters("{$this->_class}-styles", array(
			'alert' => 'Alert',
			'box' => 'Box',
			'note' => 'Note'));
		// Custom content options initiation sequence
//		add_filter('thesis_post_meta', array($this, 'custom_post_meta'));
//		if (!in_array($this->_class, $thesis->box_post_meta))
//			$thesis->box_post_meta[] = $this->_class;
		// End custom post meta initiation sequence
#		add_shortcode('modular_content', array($this, 'shortcode'));
//		add_action('admin_menu', array($this, 'menu'));
//		add_action('admin_bar_menu', array($this, 'admin_bar'), 1000);
//		add_filter("manage_{$this->cpt}_posts_columns", array($this, 'columns'));
//		add_action("manage_{$this->cpt}_posts_custom_column", array($this, 'column_content'), 10, 2);
//		if (is_admin() && in_array($pagenow, array('edit.php')) && !empty($_GET) && !empty($_GET['post_type']) && $_GET['post_type'] == $this->cpt)
//			add_action('admin_footer', array($this, 'edit_js'));
	}

	public function preload() {
		global $motor;
//		$this->content_options = is_object($post) ? get_post_meta($post->ID, "_$this->_class", true) : array();
		if (empty($this->content_options['content']) && empty($this->theme_options['pages']))
			return;
		$this->get_content();
		if (!empty($this->content_options) && !empty($this->content_options['location'])) {
			add_action($this->content_options['location'], array($this, 'output'));
			$this->hooked = true;
		}
	}

	public function get_content() {
		global $motor;
		// Need to know if this instance belongs to the Admin Theme...
		$content = $motor->content->get_where(array('type' => $this->content_type));
//		$content = $motor->db->get_content(array('type' => 'modular'));
		if (is_object($content) && !empty($content->posts))
			foreach ($content as $mc)
				if (!empty($mc['content']))
					$this->content[$mc['id']] = array(
						'id' => $mc['id'],
						'title' => !empty($mc['title']) ? $mc['title'] : "Modular Content {$mc['id']}",
						'content' => $mc['content'],
						'options' => $motor->content->get_options($mc['id']));
//						'options' => $motor->db->get_content_options($mc['id']));
		$this->content = apply_filters("{$this->_class}-content", $this->content);
		if (!empty($this->content))
			$this->content = $motor->tools->sort_by($this->content, 'title', true);
		$this->fetched = true;
	}

	public function html($depth = 0) {
		global $motor;
		if (empty($this->content) || !empty($this->hooked))
			return;
		$this->output($depth);
	}

	public function output($depth = 0) {
		global $motor;
		$classes = $filters = array();
		$output = '';
		$classes[] = apply_filters("{$this->_class}-class", $this->class);
		if (!empty($this->content_options['style'])) {
			if ($this->content_options['style'] != 'unstyled')
				$classes[] = $this->content_options['style'];
		}
		elseif (!empty($this->theme_options['style']))
			$classes[] = $this->theme_options['style'];
		$content = !empty($this->content_options['content']) ? ($this->content_options['content'] == 'no-fallback' ? false : (!empty($this->content[$this->content_options['content']]) ?
			$this->content[$this->content_options['content']] : false)) :
			(!empty($this->theme_options['pages']) && !empty($this->content[$this->theme_options['pages']]) ?
			$this->content[$this->theme_options['pages']] : false);
		if (empty($content) || empty($content['id']) || empty($content['content']))
			return;
		$tab = str_repeat("\t", $depth);
		// get filters
		$filters = $this->filters($content);
//		$embed = new WP_Embed;
//		add_filter("{$this->_class}_{$content['id']}_output", array($embed, 'run_shortcode'), 8);
//		add_filter("{$this->_class}_{$content['id']}_output", array($embed, 'autoembed'), 8);
		// add filters
#		$thesis->wp->filter("{$this->class}-{$content['id']}-output", $filters);
		// apply filters
		$output = trim(apply_filters("{$this->_class}-{$content['id']}-output", $content['content']));
		// remove filters
#		if (!empty($filters))
#			foreach ($filters as $filter => $priority)
#				remove_filter("{$this->class}-{$content['id']}-output", $filter);
		echo
			"$tab<div". (!empty($classes) ? ' class="'. $motor->text(implode(' ', $classes)). '"' : ''). ">\n",
			"$output\n",
			"$tab</div>\n";
	}

	public function shortcode($args) {
		global $motor;
		extract($args);
		if (empty($id))
			return;
		if (empty($this->fetched))
			$this->get_content();
		if (empty($this->content[$id]))
			return;
		$classes = $filters = array();
		$output = '';
		$classes[] = apply_filters("{$this->_class}-class", $this->class);
		if (!empty($style))
			$classes[] = trim($style);
		$tag = !empty($inline) ? 'span' : 'div';
		$tab = $tag == 'div' ? str_repeat("\t", $depth = !empty($depth) ? $depth : 0) : '';
		$newline = $tag == 'div' ? "\n" : '';
		// get filters
		$filters = $this->filters($content = $this->content[$id], !empty($inline) ? true : false);
//		$embed = new WP_Embed;
//		add_filter("{$this->class}-{$content['id']}-output", array($embed, 'run_shortcode'), 8);
//		add_filter("{$this->class}-{$content['id']}-output", array($embed, 'autoembed'), 8);
		// add filters
#		$thesis->wp->filter("{$this->class}-{$content['id']}-output", $filters);
		// apply filters
		$output = trim(apply_filters("{$this->_class}-{$content['id']}-output", $content['content']));
		// remove filters
#		if (!empty($filters))
#			foreach ($filters as $filter => $priority)
#				remove_filter("{$this->class}-{$content['id']}-output", $filter);
		return
			"$tab<$tag". (!empty($classes) ? ' class="'. $motor->text(implode(' ', $classes)). '"' : ''). ">$newline".
			$output. $newline.
			"$tab</$tag>". (empty($trim) ? $newline : '');
	}

	private function filters($content, $inline = false) {
		return
			(!empty($content) && !empty($content['options']) && !empty($content['options']['format'])
			&& !empty($content['options']['format']['no-autop'])) || !empty($inline) ?
			array(
				'wptexturize' => false,
				'convert_smilies' => false,
				'do_shortcode' => false) :
			array(
				'wptexturize' => false,
				'convert_smilies' => false,
				'wpautop' => false,
				'shortcode_unautop' => false,
				'do_shortcode' => false);
	}
}