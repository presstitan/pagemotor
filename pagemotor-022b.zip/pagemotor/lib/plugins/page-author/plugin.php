<?php
/*
Name: Page Author
Author: Pearsonified
Description: Output a Page Author in HTML
Version: 1.0
Requires: 0.1
Class: Page_Author
Docs: https://pagemotor.com/plugins/page/author/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Page Author Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Page_Author extends PM_Plugin {
	public $title = 'Author';
	public $type = 'box';
	public $custodians = array(
		'Page_Container' => array(
			'order' => 15));
	public $class = 'page-author';

	public function html_options() {
		global $motor;
		$html = $motor->options->html();
		$html['class']['tooltip'] = "This box already contains a class, <code>$this->class</code>. If you wish to add an additional class, you can do that here. Separate multiple classes with spaces.<br /><br /><strong>Note:</strong> Class names cannot begin with numbers!";
		unset($html['id']);
		return $html;
	}

	public function box_options() {
		return array(
			'intro' => array(
				'type' => 'text',
				'width' => 'short',
				'label' => 'Author Intro Text',
				'tooltip' => "Any text you supply here will be wrapped in HTML, like so:<br /><code>&lt;span class=\"$this->class-intro\"&gt</code>your text<code>&lt;/span&gt;</code>."));
	}

	public function html($depth = 0) {
		global $motor;
		// Need a way to fetch the real author name and not just the username
		echo
			str_repeat("\t", $depth), (!empty($this->box_options['intro']) ?
			"<span class=\"$this->class-intro\">". trim($motor->text($this->box_options['intro'], 'inline')). '</span> ' : ''),
			"<span class=\"$this->class". (!empty($this->box_options['class']) ? ' '. trim($motor->text($this->box_options['class'])) : ''). "\">{$motor->page->content['author']}</span>\n";
	}
}