<?php
/*
Name: Page Container
Author: Pearsonified
Description: A container with dependent Boxes for outputting current Page content
Version: 1.0
Requires: 0.1
Class: Page_Container
Docs: https://pagemotor.com/plugins/page/container/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Page Container Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Page_Container extends PM_Plugin {
	public $title = 'Page Container';
	public $name = 'Page Container';
	public $type = 'container';
	public $tab = false;
	public $tag = 'div';
	public $class = 'page-container';
	public $page_count = 1;
	public $hook = false;

	public function html_options() {
		global $motor;
		$html = $motor->options->html(array(
			'div' => 'div',
			'section' => 'section',
			'article' => 'article'), 'div');
		unset($html['id']);
		$html['class']['tooltip'] = "This container already contains a class, <code>$this->class</code>. If you wish to add an additional class, you can do that here. Separate multiple classes with spaces.<br /><br /><strong>Note:</strong> Class names cannot begin with numbers!";
		return $html;
	}

	public function container_open($depth = 0) {
		global $motor;
		$classes = array();
		$this->tab = str_repeat("\t", $depth);
		$this->tag = !empty($this->box_options['tag']) ? $motor->text($this->box_options['tag']) : $this->tag;
		if (!empty($this->box_options['class']))
			$classes[] = trim($this->box_options['class']);
		if ($this->page_count == 1)
			$classes[] = 'top';
		$classes = apply_filters("{$this->_class}-classes", $classes);
		$this->hook = trim($motor->text(!empty($this->box_options['_id']) ?
			$this->box_options['_id'] : (!empty($this->box_options['hook']) ?
			$this->box_options['hook'] : $this->hook)));
		// Begin HTML output
#		$thesis->api->hook('hook_before_page_container', $this->page_count); // universal
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_before_page_container_$this->hook", $this->page_count); // specific
		echo "$this->tab<$this->tag", ($motor->page->error ? '' : " id=\"page-{$motor->page->content['id']}\""), " class=\"$this->class", (!empty($classes) ? ' '. trim($motor->text(implode(' ', $classes))) : ''), '"', ">\n";
#		$thesis->api->hook('hook_top_page_container', $this->page_count); // universal
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_top_page_container_$this->hook", $this->page_count); // specific
	}

	public function container_close($depth = 0) {
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_bottom_page_container_$this->hook", $this->page_count); // specific
#		$thesis->api->hook('hook_bottom_page_container', $this->page_count); // universal
		echo "$this->tab</$this->tag>\n";
#		if (!empty($this->hook))
#			$thesis->api->hook("hook_after_page_container_$this->hook", $this->page_count); // specific
#		$thesis->api->hook('hook_after_page_container', $this->page_count); // universal
	}
}