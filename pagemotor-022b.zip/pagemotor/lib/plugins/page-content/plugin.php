<?php
/*
Name: Page Content
Author: Pearsonified
Description: Output a textified Content field for the current Page
Version: 1.0
Requires: 0.1
Class: Page_Content
Docs: https://pagemotor.com/plugins/page/content/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Page Content Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Page_Content extends PM_Plugin {
	public $title = 'Content';
	public $type = 'box';
	public $custodians = array(
		'Page_Container' => array(
			'order' => 10,
			'startup' => true));
	public $class = 'page-content';

	public function html_options() {
		global $motor;
		$html = $motor->options->html();
		$html['class']['tooltip'] = "This box already contains a class of <code>$this->class</code>. If you&#8217;d like to supply another class, you can do that here.<br /><br /><strong>Note:</strong> Class names cannot begin with numbers!";
		unset($html['id']);
		return $html;
	}

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$hook = trim($motor->text(!empty($this->box_options['_id']) ? $this->box_options['_id'] : ''));
		/*---:[ begin HTML output ]:---*/
#		$thesis->api->hook('hook_before_page_content'); // universal
#		if (!empty($hook))
#			$thesis->api->hook("hook_before_page_content_$hook"); // specific
		echo "$tab<div class=\"$this->class", (!empty($this->box_options['class']) ? ' '. trim($motor->text($this->box_options['class'])) : ''), "\">\n";
#		$thesis->api->hook('hook_top_page_content'); // universal
#		if (!empty($hook))
#			$thesis->api->hook("hook_top_page_content_$hook"); // specific
		echo $motor->text(trim($motor->page->content['content']), 'content'). "\n";
//		if ($wp_query->is_singular && apply_filters("{$this->_class}_page_links", true))
//			wp_link_pages(array(
//				'before' => '<div class="page-links">'. __($thesis->api->strings['pages'], 'thesis'). ':',
//				'after' => '</div>'));
#		if (!empty($hook))
#			$thesis->api->hook("hook_bottom_page_content_$hook"); // specific
#		$thesis->api->hook('hook_bottom_page_content'); // universal
		echo "$tab</div>\n";
#		if (!empty($hook))
#			$thesis->api->hook("hook_after_page_content_$hook"); // specific
#		$thesis->api->hook('hook_after_page_content'); // universal
	}
}