<?php
/*
Name: Page Date
Author: Pearsonified
Description: Output the current Page Date in HTML
Version: 1.0
Requires: 0.1
Class: Page_Date
Docs: https://pagemotor.com/plugins/page/date/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Page Date Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Page_Date extends PM_Plugin {
	public $title = 'Date';
	public $type = 'box';
	public $custodians = array(
		'Page_Container' => array(
			'order' => 20));
	public $format = 'F j, Y';
	public $class = 'page-date';
	public $class_modified = 'page-modified';

	public function box_options() {
		global $motor;
		return array(
			// In a "no defaults" environment, this should be an override instead.
			'format' => array(
				'type' => 'text',
				'width' => 'short',
				'code' => true,
				'label' => 'Date Format',
				'tooltip' => sprintf('This field accepts a <a href="%s" target="_blank" rel="noopener noreferrer">PHP date format</a>.', 'https://php.net/manual/en/function.date.php'),
				'default' => $this->format),
			'show' => array(
				'type' => 'checkbox',
				'label' => 'Display Settings',
				'options' => array(
					'published' => 'Show the publication date',
					'modified' => 'Show the last modified date'),
				'dependents' => array(
					'published',
					'modified'),
				'default' => array(
					'published' => true)),
			'intro' => array(
				'type' => 'text',
				'width' => 'short',
				'label' => 'Publication Date Intro Text',
				'tooltip' => "Any text you supply here will be wrapped in HTML, like so:<br /><code>&lt;span class=\"$this->class-intro\"&gt;</code>your text<code>&lt;/span&gt;</code>.",
				'parent' => array(
					'show' => 'published')),
			'modified' => array(
				'type' => 'text',
				'width' => 'short',
				'label' => 'Last Modification Date Intro Text',
				'tooltip' => "Any text you supply here will be wrapped in HTML, like so:<br /><code>&lt;span class=\"$this->class_modified-intro\"&gt;</code>your text<code>&lt;/span&gt;</code>.",
				'parent' => array(
					'show' => 'modified')));
	}

	public function html($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
//		$options = $motor->options->get($this->_box_options(), $this->box_options);
		$format = strip_tags(!empty($this->box_options['format']) ? $this->box_options['format'] : $this->format);
		$published = !empty($this->box_options['show']) && !empty($this->box_options['show']['published']) ?
			((!empty($this->box_options['intro']) ?
				"<span class=\"$this->class-intro\">". trim($motor->text($this->box_options['intro'], 'inline')). '</span> ' : '').
				"<span class=\"$this->class\" title=\"". $motor->tools->date($motor->page->content['date_gmt'], 'Y-m-d'). "\">".
				$motor->tools->date($motor->page->content['date_gmt'], $format).
				"</span>") : '';
		$modified = !empty($this->box_options['show']) && !empty($this->box_options['show']['modified']) ?
			((!empty($this->box_options['modified']) ?
				"<span class=\"$this->class-intro $this->class_modified-intro\">". trim($motor->text($this->box_options['modified'], 'inline')). '</span> ' : '').
				"<span class=\"$this->class $this->class_modified\" title=\"". $motor->tools->date($motor->page->content['modified_gmt'], 'Y-m-d'). "\">".
				$motor->tools->date($motor->page->content['modified_gmt'], $format).
				"</span>") : '';
		echo (!empty($published) ?
			"$tab$published\n" : ''), (!empty($modified) ?
			"$tab$modified\n" : '');
	}
}