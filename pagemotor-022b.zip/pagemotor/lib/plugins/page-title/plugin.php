<?php
/*
Name: Page Title
Author: Pearsonified
Description: Output the current Page Title in HTML
Version: 1.0
Requires: 0.1
Class: Page_Title
Docs: https://pagemotor.com/plugins/page/title/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Page Title Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Page_Title extends PM_Plugin {
	public $title = 'Title';
	public $type = 'box';
	public $custodians = array(
		'Page_Container' => array(
			'order' => 5,
			'startup' => true));
	public $tag = 'h1';
	public $class = 'page-title';

	public function html_options() {
		global $motor;
		$html = $motor->options->html(array(
			'h1' => 'h1',
			'h2' => 'h2',
			'h3' => 'h3',
			'h4' => 'h4',
			'p' => 'p',
			'span' => 'span'), 'h1');
		$html['class']['tooltip'] = "This box already contains a class, <code>$this->class</code>. If you wish to add an additional class, you can do that here. Separate multiple classes with spaces.<br /><br /><strong>Note:</strong> Class names cannot begin with numbers!";
		unset($html['id']);
		return array_merge($html, array(		// Should this option even exist? Probably not...
			'link' => array(
				'type' => 'checkbox',
				'options' => array(
					'on' => 'Link title to article page'))));
	}

	public function html($depth = 0) {
		global $motor;
		$id = !empty($this->box_options['_id']) ? trim($motor->text($this->box_options['_id'])) : false;
		$this->tag = !empty($this->box_options['tag']) ? $motor->text($this->box_options['tag']) : $this->tag;
		$class = " class=\"$this->class". (!empty($this->box_options['class']) ? ' '. trim($motor->text($this->box_options['class'])) : ''). "\"";
		$title = $motor->text($motor->page->content['title'], 'inline-no-links');
	 	echo
			str_repeat("\t", $depth),
			"<$this->tag$class>",
			(!empty($this->box_options['link']) && !empty($this->box_options['link']['on']) ?
			"<a href=\"{$motor->page->url}\">$title</a>" :
			$title),
			"</$this->tag>\n";
	}
}