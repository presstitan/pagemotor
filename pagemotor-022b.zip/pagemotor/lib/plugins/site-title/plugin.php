<?php
/*
Name: Site Title
Author: Pearsonified
Description: Output the Site Title in HTML
Version: 1.0
Requires: 0.1
Class: Site_Title
Docs: https://pagemotor.com/plugins/html/site-title/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Site Title Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Site_Title extends PM_Plugin {
	public $title = 'Site Title';
	public $type = 'box';
	public $tag = 'div';
	public $id = 'site-title';

	// Could add logo as a site option and also the ability to replace the
	// site title with a logo...
	// Or logo could simply be a separate Plugin...
	// But then how could 2 Plugins deliver options to the same admin page?
/*	public function site_options() {
		return array(
			'title' => array(
				'type' => 'text',
				'width' => 'medium',
				'label' => 'Site Title'));
	}*/

	public function html_options() {
		global $motor;
		$html = $motor->options->html(array('div' => 'div', 'p' => 'p'), 'div');
		unset($html['id'], $html['class']);
		return $html;
	}

	public function box_options() {
		return array(
			'link' => array(
				'type' => 'radio',
				'label' => 'Link Site Title?',
				'options' => array(
					'' => 'No link',
					'home' => 'Link to home page',
					'custom' => 'Custom link'),
				'dependents' => array('custom')),
			'custom' => array(
				'type' => 'text',
				'width' => 'long',
				'label' => 'Custom Link',
				'tooltip' => 'Enter a custom URL here.',
				'parent' => array(
					'link' => 'custom')));
	}

	public function html($depth = 0) {
		global $motor;
		$title = trim($motor->text($motor->settings->title, 'inline-no-links'));
//			apply_filters($this->_class, !empty($this->site_options['title']) ?
//				htmlspecialchars_decode($this->site_options['title'], ENT_QUOTES) : false), 'inline-no-links'));
		$logo = false;
//		$logo = ($logo = apply_filters("{$this->_class}-logo", $title)) ?
//			strip_tags(html_entity_decode($logo), '<img>') : false;
		if (empty($title) && empty($logo)) return;
//		extract($args = is_array($args) ? $args : array());
		$this->tag = !empty($this->box_options['tag']) ? $motor->text($this->box_options['tag']) : $this->tag;
		$title = !empty($logo) ? $logo : $title;
		if (!empty($this->box_options['link']) && in_array($this->box_options['link'], array('home', 'custom')) && apply_filters("{$this->_class}-link", true))
			$title = "<a href=\"". $motor->url_escape($this->box_options['link'] == 'custom' && !empty($this->box_options['custom']) ?
				$this->box_options['custom'] : $motor->site_url). "\">$title</a>";
		echo
			str_repeat("\t", !empty($depth) ? $depth : 0),
			"<$this->tag id=\"$this->id\"". (!empty($logo) ? ' class="has-logo"' : ''). ">$title</$this->tag>\n";
	}
}