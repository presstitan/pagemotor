<?php
/*
Name: Stylesheets
Author: Pearsonified
Description: Output an HTML &lt;link&gt; to include CSS and relevant assets
Version: 1.0
Requires: 0.1
Class: Stylesheets
Docs: https://pagemotor.com/plugins/html/head/stylesheets/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Stylesheets Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Stylesheets extends PM_Plugin {
	public $title = 'Stylesheets';
	public $type = 'box';
	public $head = true;
	public $custodians = array(
		'HTML_Head' => array(
			'order' => 5,
			'startup' => true));

	public function html($depth = 0) {
		global $motor;
		$theme = $this->admin_theme ? 'admin' : 'theme';
		$theme_css_path = ($this->admin_theme ? PM_ADMIN_THEME : PM_THEME). '/css.css';
		$theme_css_file = ($this->admin_theme ? PM_ADMIN_THEME_URL : PM_THEME_URL). '/css.css';
		$font_js = $add_css = $css = array();
		foreach ($motor->$theme->_font_js as $name => $js)
			if (!empty($js['url']))
				$font_js[] = "<script src=\"". $motor->url_escape($js['url']). "\"></script>";
		foreach ($motor->$theme->_add_css as $name => $sheet)
			if (!empty($sheet['url']))
				$add_css[] = "<link href=\"". $motor->url_escape($sheet['url']). "\" rel=\"stylesheet\">";
		foreach (apply_filters($this->_class, array(array('url' => $theme_css_file, 'path' => $theme_css_path))) as $sheet)
			if (!empty($sheet['url']))
				$css[] = '<link href="'. $motor->url_escape($sheet['url']). (($version = apply_filters("{$this->_class}-version", filemtime($sheet['path']))) ? "?v=$version" : ''). '" rel="stylesheet">';
		echo
			implode("\n", array_merge($font_js, $add_css, $css)). "\n";
	}
}