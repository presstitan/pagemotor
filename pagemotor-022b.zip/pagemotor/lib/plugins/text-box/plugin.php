<?php
/*
Name: Text Box
Author: Pearsonified
Description: Output a Text Box in HTML
Version: 1.0
Requires: 0.1
Class: Text_Box
Docs: https://pagemotor.com/plugins/html/text-box/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Text Box Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Text_Box extends PM_Plugin {
	public $title = 'Text Box';
	public $name = 'Text Box';
	public $type = 'box';
	public $class = 'text-box';

	public function html_options() {
		global $motor;
		$html = $motor->options->html();
		$html['class']['tooltip'] = "This box already contains a class, <code>$this->class</code>. If you&#8217;d like to supply another class, you can do that here.<br /><br /><strong>Note:</strong> Class names cannot begin with numbers!";
		unset($html['id']);
		return $html;
	}

	public function box_options() {
		global $motor;
		$styles = apply_filters("{$this->_class}-styles", array(
			'' => 'As-is',
			'alert' => 'Alert',
			'box' => 'Box',
			'note' => 'Note'));
		$fields = array(
			'info' => array(
				'type' => 'custom',
				'html' =>
					"<div class=\"text callout note\">\n".
					"\t<p>Insert plain text and/or HTML. All text will be formatted like a normal Page, and all valid HTML tags and shortcodes are allowed. <strong>PHP code is not allowed.</strong></p>\n".
//					"\t<p><strong>Pro tip:</strong> Inserting a <code>&lt;form&gt;</code> or <code>&lt;script&gt;</code>? For best results, use the &ldquo;disable automatic <code>&lt;p&gt;</code> tags&rdquo; option!</p>\n".
					"</div>\n"),
			'text' => array(
				'type' => 'textarea',
				'rows' => 8,
				'code' => true,
				'label' => 'Text/HTML',
				'tooltip' => 'This box allows you to insert plain text and/or HTML. All text will be formatted just like a normal Page, and all valid HTML tags are allowed.<br /><br /><strong>Note:</strong> PHP code is not allowed here.',
				'description' => 'Use HTML tags and shortcodes just like in a Page!'),
/*			'filter' => array(
				'type' => 'checkbox',
				'options' => array(
					'on' => 'disable automatic <code>&lt;p&gt;</code> tags for this Text Box'))*/);
		if (!empty($styles))
			$fields['style'] = array(
				'type' => 'select',
				'item-class' => 'inline-select last-select',
				'label' => 'Display Style',
				'description' => '<strong>Note:</strong> Themes and output locations may not support all styles!',
				'options' => $styles);
		return $fields;
	}

	public function html($depth = 0) {
		global $motor;
		if (empty($this->box_options['text'])) // && !is_user_logged_in()) return;
			return;
		$tab = str_repeat("\t", $depth);
		$class = trim($motor->text(apply_filters("{$this->_class}-class", $this->class)));
		echo
			"$tab<div", (!empty($this->box_options['id']) ? ' id="'. trim($motor->text($this->box_options['id'])). '"' : ''), " class=\"$class", (!empty($this->box_options['class']) ? ' '. trim($motor->text($this->box_options['class'])) : ''), (!empty($this->box_options['style']) ? ' '. trim($motor->text($this->box_options['style'])) : ''), "\">\n",
			"$tab\t", trim($motor->text($this->box_options['text'], 'content')), "\n", //!empty($this->box_options['text']) ?
//				$this->options['text'] :
//				sprintf('This is a Text Box named <strong>%1$s</strong>. <a href="%2$s">Edit this Text Box</a>', $this->name, $motor->admin_url("admin.php?page=thesis&canvas=$this->_id")))), "\n",
			"$tab</div>\n";
	}
}