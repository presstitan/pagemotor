<?php
/*
Name: Title Tag
Author: Pearsonified
Description: Output an HTML &lt;title&gt; tag
Version: 1.0
Requires: 0.1
Class: Title_Tag
Docs: https://pagemotor.com/plugins/html/head/title-tag/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Title Tag Plugin
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class Title_Tag extends PM_Plugin {
	public $title = 'Title Tag';
	public $type = 'box';
	public $head = true;
	public $custodians = array(
		'HTML_Head' => array(
			'order' => 25,
			'startup' => true));

	public function content_options() {
		// This should apply to all types that are URL-enabled
		// (and it can ONLY apply to types that are UI-enabled)
		return array(
			'title' => $this->title,
			'types' => apply_filters("{$this->_class}-content-types", array('page')),
			'order' => 12,
			'fields' => array(
				'title' => array(
					'type' => 'text',
					'width' => 'full',
					'label' => sprintf('Custom %s', $this->title),
					'tooltip' => 'By default, the title of your page serves as the contents of the Title Tag. You can override this and further extend your on-page SEO by entering your own Title Tag here.',
					'counter' => 'Search engines allow a maximum of 70 characters for the title.')));
	}

	public function html($depth = 0) {
		global $motor;
		$title = $motor->page->is_search ?
			"Search: {$motor->page->search_term}" :
			(!empty($this->content_options) && !empty($this->content_options['title']) ?
				$this->content_options['title'] : (!empty($motor->page->content['title']) ?
				$motor->page->content['title'] : false));
		echo
			'<title>',
			trim($motor->text($title, 'no-html')),
			"</title>\n";
	}
}