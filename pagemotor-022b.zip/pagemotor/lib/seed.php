<?php
/**
 * PageMotor Content Seed Data
 * =========================
 * Contains the content PageMotor needs to set up a working environment
 * Note: Theme data is seeded separately and is necessary for a working environment
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Seed
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Seed {
	public $admin_content = array(
		'home' => array(
			'title' => 'PageMotor Admin Home',
			'type' => 'home'),
		'content' => array(
			'title' => 'Content',
			'slug' => 'content',
			'type' => 'admin-content'),
		'admin-content' => array(
			'title' => 'Admin Content',
			'slug' => 'admin-content',
			'type' => 'admin-content'),
		'plugins' => array(
			'title' => 'Plugins',
			'slug' => 'plugins',
			'type' => 'admin-plugins'),
		'themes' => array(
			'title' => 'Themes',
			'slug' => 'themes',
			'type' => 'admin-themes'),
		'admin-themes' => array(
			'title' => 'Admin Themes',
			'slug' => 'admin-themes',
			'type' => 'admin-themes'),
		'theme' => array(
			'title' => 'Theme',
			'slug' => 'theme',
			'type' => 'admin-theme'),
		'admin-theme' => array(
			'title' => 'Admin Theme',
			'slug' => 'admin-theme',
			'type' => 'admin-theme'),
		'settings' => array(
			'title' => 'Site Settings',
			'slug' => 'settings',
			'type' => 'admin-settings'));
	public $theme_ui = array(
		'display' => array(
			'title' => 'Display Options',
			'slug' => 'display',
			'type' => 'admin-theme',
			'sub_type' => 'display'),
		'editable-content' => array(
			'title' => 'Editable Content',
			'slug' => 'elements',
			'type' => 'admin-theme',
			'sub_type' => 'elements'),
		'design' => array(
			'title' => 'Design Options',
			'slug' => 'design',
			'type' => 'admin-theme',
			'sub_type' => 'design'),
		'plugin-options' => array(
			'title' => 'Plugin Options',
			'slug' => 'options',
			'type' => 'admin-theme',
			'sub_type' => 'options'),
		'custom-css' => array(
			'title' => 'Custom CSS',
			'slug' => 'css',
			'type' => 'admin-theme',
			'sub_type' => 'css'),
		'editor' => array(
			'title' => 'Editor',
			'slug' => 'editor',
			'type' => 'admin-theme',
			'sub_type' => 'editor'));
	public $content = array(
		'home' => array(
			'title' => 'PageMotor Theme Home',
			'content' => '<div class="bleed orange">
<div class="container">
<div class="text page-content">
<h1>Behold the Power of PageMotor</h1>
<p class="caption">Faster, smarter, better&mdash;just how you always imagined the future would be!</p>
<p><span class="drop-cap">Y</span>ou don\'t get any do-overs in life. Every once in a while, though, you get a unique <strong>opportunity for a fresh start.</strong> You get a chance to play the game again, but this time, with more wisdom.</p>
<p>When it comes to websites, PageMotor is your fresh start. <strong>It\'s the reset button.</strong></p>
<p>PageMotor knows all those things that sucked about your experience with websites. It knows your headaches. <strong>It knows your pain.</strong></p>
<p>And it has your answers. <strong>PageMotor is here to fix everything you\'ve ever hated about creating websites.</strong></p>
</div>
</div>
</div>
<h2 class="center">How is PageMotor so Smart?</h2>
<p class="caption">It\'s all in the code. (Always has been.)</p>
<p><span class="drop-cap">C</span>omputer Science matters. One of the foundational principles of Computer Science is something called <strong>object-oriented programming (OOP).</strong></p>
<p>For software to do amazing things, it <em>must</em> leverage OOP. Without it, developers get lost in an infinitely expanding game they can never win.</p>
<p>OOP is the key to infinite outcomes. In order for software to do as much as possible&mdash;and to be as useful in as many different situations as possible&mdash;OOP is the <em>only</em> way to get there. <strong>It\'s the only way to go from finite input to infinite output. That\'s the magic of OOP.</strong></p>
<p>PageMotor delivers this magic in a package so simple and fast, you\'ll find yourself asking, "Where has this been all my life?"</p>
<p>Difficult projects become easy. This "AI future" everybody keeps talking about is not just within reach, <strong>it\'s a reality with PageMotor.</strong></p>
<p>And it\'s all because you\'ve got that secret OOP sauce under the hood!</p>
<div class="bleed salmon">
<div class="container">
<div class="text page-content">
<h2>What will you build with PageMotor?</h2>
<p class="caption">The only limit is your imagination.</p>
<p><span class="drop-cap">Y</span>ou won\'t need a Page Builder. Or a custom form generator. Or some fancy CSS add-on with a complicated interface and a billion options.</p>
<p>(You\'ve already got all that stuff, and it\'s <strong>simpler than you ever imagined.</strong>)</p>
<p>You won\'t wrestle with a clunky editor that asks you to deal with technical nonsense.</p>
<p>You can just... write. Add some delightful formatting. And <strong>create the types of pages you dream about.</strong></p>
<p>Easy to build. Easy to use. <strong>Easy to love.</strong></p>
<p>PageMotor is the future of websites.</p>
</div>
</div>
</div>',
			'type' => 'home'));

//	public function error_pages() {
	public function __construct() {
		global $motor;
		$this->admin_content['error'] = array(
			'title' => 'Awkward! This is the PageMotor Admin 404 page',
			'content' => '<p>You were never supposed to end up here. But here you are. Click the button below to head back to the admin home page.</p>
<p class="center"><a class="button action" href="'. $motor->admin_url(). '">&larr; Back to PageMotor</a></p>',
			'type' => 'error');
		$this->content['error'] = array(
			'title' => 'Whoops! You found the 404 page',
			'content' => '<p><span class="drop-cap">Y</span>ou were never supposed to see this. But here you are. Let\'s fix this as quickly as possible and move on with our lives. Click the button below to head back home.</p>
<p class="center"><a class="button action" href="'. $motor->url(). '">&larr; Back to Home Page</a></p>',
			'type' => 'error');
	}
}