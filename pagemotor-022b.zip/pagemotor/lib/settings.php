<?php
/**
 * PageMotor Site Settings Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Settings
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Settings {
	public $options = array();							// [array] saved Site Settings
	public $title = 'A Blazing Fast PageMotor Website';	// [string] Site Title (with default preset)
	public $admin_management = false;					// [bool] enable Admin Management UIs

	public function __construct() {
		global $motor;
		if ($motor->options->exists(__CLASS__)) {
			$this->options = $motor->options->option(__CLASS__, $this->options);
			if (!empty($this->options['title']))
				$this->title = $this->options['title'];
			if (!empty($this->options['manage']) && !empty($this->options['manage']['admin']))
				$this->admin_management = true;
		}
		else
			$motor->options->update(__CLASS__, array(
				'title' => $this->title));
	}

	public function options() {
		global $motor;
		$options = array(
			'title' => array(
				'type' => 'text',
				'width' => 'long',
				'label' => 'Site Title'));
//			'timezone' => array(),
		if (!empty($motor->user) && !empty($motor->user->admin))
			$options['manage'] = array(
				'type' => 'checkbox',
				'label' => 'Admin Management',
				'options' => array(
					'admin' => 'Enable management of Admin Content, Plugins, and Themes (Admins only)'));
		return $options;
	}

	public function admin($depth = 0) {
		global $motor;
		$options = $motor->tools->form->fields($this->options(), $this->options, '', '', $depth);
		return
			$motor->tools->ui->admin_options_form(array(
				'title' => 'Site Settings',
				'name' => 'Settings',
				'form' => $options,
				'hidden' => array(
					'theme' => $motor->admin->_class),
				'class' => 'pm-site-settings',
				'ajax' => true,
				'type' => 'settings',
				'depth' => $depth,
				'save_icon' => 'check-circle'));
	}

	public function save() {
		global $motor;
		if (empty($_POST) || empty($_POST['form']))
			return false;
		parse_str(stripslashes($_POST['form']), $form);
		$options = $motor->options->set($this->options(), $form);
		$motor->options->update(__CLASS__, $options);
		return true;
	}
}