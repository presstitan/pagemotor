<?php
/**
 * PageMotor Theme CSS Editor
 *
 * @package 	PageMotor Theme
 * @subpackage 	PageMotor Theme CSS Editor
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Theme_CSS_Editor {
	public $theme = false;						// [string] Theme CSS
	public $editor = false;						// [string] Content Editor CSS
	public $custom = false;						// [string] Custom CSS
	public $vars = false;						// [object] CSS variable controller
	public $mixins = array();					// [array] SCSS mixin files
	public $includes = array();					// [array] SCSS include files
	public $includes_active = array();			// [array] active SCSS includes + output order
	public $includes_editor = array();			// [array] SCSS include files for the Content Editor
	public $includes_editor_active = array();	// [array] active SCSS includes for the content editor + output order

	public function __construct($args = array()) {
		if (!defined('PM_THEME_CSS_EDITOR'))
			define('PM_THEME_CSS_EDITOR', PM_THEME_ENGINE. '/css-editor');
		require(PM_THEME_CSS_EDITOR. '/variables.php');
		extract($args); // $theme, $editor, $custom, $vars, $mixins, $includes, $includes_active, $includes_editor, $includes_editor_active
		$this->theme = !empty($theme) ? $theme : $this->theme;
		$this->editor = !empty($editor) ? $editor : $this->editor;
		$this->custom = !empty($custom) ? $custom : $this->custom;
		$this->vars = new PM_Theme_CSS_Variables($vars);
		$this->mixins = !empty($mixins) ? $mixins : $this->mixins;
		$this->includes = !empty($includes) ? $includes : $this->includes;
		$this->includes_active = !empty($includes_active) ? $includes_active : $this->includes_active;
		$this->includes_editor = !empty($includes_editor) ? $includes_editor : $this->includes_editor;
		$this->includes_editor_active = !empty($includes_editor_active) ? $includes_editor_active : $this->includes_editor_active;
	}

	public function editor($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		return
			"$tab<h3 id=\"theme-css-tabs\">\n".
			"$tab\t<span class=\"css-tab css-tab-current\" data-type=\"theme\">Theme CSS</span><span class=\"css-tab\" data-type=\"editor\">Editor CSS</span>\n".
			"$tab</h3>\n".
			"$tab<div id=\"css-canvas\">\n".
			$this->css_editor(array(
				'type' => 'theme',
				'id' => 'css-theme',
				'class' => 'css-droppable',
				'css' => $this->theme,
				'depth' => $depth + 1)).
			$this->css_editor(array(
				'type' => 'editor',
				'id' => 'css-editor',
				'class' => 'css-droppable',
				'css' => $this->editor,
				'depth' => $depth + 1)).
			$this->assets($depth + 2).
			"$tab</div>\n".
			"$tab<div id=\"theme-css-popup\" class=\"pm-popup force-trigger\">\n".
			"$tab\t<div class=\"pm-popup-html\">\n".
			"$tab\t</div>\n".
			"$tab</div>\n".
			"$tab<button id=\"css-save\" class=\"save pm-ui-save\">\n".
			$motor->tools->svg->icon('check-circle', $depth + 1).
			"$tab\tSave CSS\n".
			"$tab</button>\n".
			$motor->tools->ui->alert('Saving CSS&hellip;', 'saving-css', false, 'action', $depth);
	}

	public function custom($theme, $docs = false, $depth = 0) {
		global $motor;
		return
			$motor->tools->ui->admin_options_form(array(
				'title' => 'Custom CSS',
				'name' => 'Custom CSS',
				'docs' => $docs,
				'id' => 'custom-css',
				'form' => $this->css_editor(array(
					'type' => 'css-custom',
					'id' => 'css-custom',
					'css' => $this->custom,
					'slideout' => true,
					'depth' => $depth + 1)),
				'class' => 'pm-theme-options',
				'hidden' => array(
					'theme' => $theme),
				'ajax' => true,
				'depth' => $depth,
				'save_icon' => 'check-circle'));
	}

	public function css_editor($args = array()) {
		global $motor;
		$type = $id = $class = $saved = false;
		$depth = 0;
		extract($args);	// $type, $id, $class, $css, $slideout, $depth
		$type = !empty($type) ? " data-type=\"$type\"" : '';
		$id = !empty($id) ? " id=\"$id\"" : '';
		$class = 'css-input language-css'. (!empty($class) ? " $class" : '');
		$tab = str_repeat("\t", $depth);
		return
			"$tab<div class=\"theme-css\"$type data-style=\"box\">\n".
			"$tab\t<textarea$id class=\"$class\" data-style=\"box\" spellcheck=\"false\">$css</textarea>\n".
			(!empty($slideout) ?
			"$tab\t<div class=\"slideout-toggle\">\n".
			$motor->tools->svg->icon('plus', $depth + 2, false, 'toggle-on').
			$motor->tools->svg->icon('minus', $depth + 2, false, 'toggle-off').
			"$tab\t</div>\n".
			"$tab\t<div class=\"slideout\">\n".
			"$tab\t\t<h4>Variables</h4>\n".
			$this->vars->list(false, $depth + 2).
			"$tab\t</div>\n" : '').
			"$tab</div>\n";
	}

	public function assets($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		// Provide a message about the Theme not having these items instead...
		$mixins = empty($this->mixins) ? ' disabled' : '';
		$includes = empty($this->includes) ? ' disabled' : '';
		return
			"$tab<div id=\"css-assets\">\n".
			"$tab\t<div id=\"css-asset-controls\">\n".
			"$tab\t\t<button class=\"css-asset-control active\" data-type=\"vars\">Variables</button>\n".
			"$tab\t\t<button class=\"css-asset-control$mixins\" data-type=\"mixins\">Mixins</button>\n".
			"$tab\t\t<button class=\"css-asset-control$includes\" data-type=\"includes\">Includes</button>\n".
			"$tab\t</div>\n".
			"$tab\t<div id=\"css-asset-panels\">\n".
			$this->vars($depth + 2).
			$this->mixins($depth + 2).
			$this->includes($depth + 2).
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

	public function vars($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		return
			"$tab<div id=\"css-vars\" class=\"css-asset-panel active\">\n".
			"$tab\t<div id=\"css-var-controls\" class=\"css-asset-header\">\n".
			"$tab\t\t<h3>Variables</h3>\n".
			"$tab\t\t<button id=\"css-var-create\" class=\"action\">\n".
			$motor->tools->svg->icon('plus-circle', $depth + 3).
			"$tab\t\t\tCreate Variable\n".
			"$tab\t\t</button>\n".
			"$tab\t</div>\n".
			$this->vars->list(true, $depth + 1).
			"$tab</div>\n";
	}

	public function mixins($depth = 0) {
		global $motor;
		if (empty($this->mixins))
			return false;
		$tab = str_repeat("\t", $depth);
		$mixins = '';
		foreach ($this->mixins as $ref => $mixin)
			$mixins .=
				"$tab\t\t<li>\n".
				"$tab\t\t\t<div class=\"css-mixin\">\n".
				"$tab\t\t\t\t<code>$ref</code>\n".
				$motor->tools->svg->icon('info', $depth + 4, false, 'tooltip-show').
				"$tab\t\t\t\t<div class=\"tooltip\">\n".
				(!empty($mixin['description']) ?
				"$tab\t\t\t\t\t". $motor->text($mixin['description'], 'escape-html'). "<br><br>\n" : false).
				"$tab\t\t\t\t\t<strong>Source:</strong> ". $motor->text($mixin['source'], 'escape-html'). "\n".
				"$tab\t\t\t\t</div>\n".
				"$tab\t\t\t</div>\n".
				"$tab\t\t</li>\n";
		return
			"$tab<div id=\"css-mixins\" class=\"css-asset-panel\">\n".
			"$tab\t<div class=\"css-asset-header\">\n".
			"$tab\t\t<h3>SCSS Mixins</h3>\n".
			$motor->tools->svg->icon('help-circle', $depth + 2, false, 'tooltip-show').
			"$tab\t</div>\n".
			"$tab\t<div class=\"tooltip\"><strong>Note:</strong> Any mixins listed here will be available for use in the SCSS Editors and SCSS Includes.</div>\n".
			"$tab\t<ul class=\"css-asset-list css-mixin-list\">\n".
			$mixins.
			"$tab\t</ul>\n".
			"$tab</div>\n";
	}

	public function includes($depth = 0) {
		global $motor;
		if (empty($this->includes))
			return false;
		$tab = str_repeat("\t", $depth);
		$includes = $includes_editor = '';
		foreach ($this->load_includes() as $id => $include)
			$includes .= $this->include($id, $include, false, $depth + 3);
		foreach ($this->load_includes(true) as $id => $include)
			$includes_editor .= $this->include($id, $include, true, $depth + 3);
		return
			"$tab<form id=\"css-includes\" class=\"css-asset-panel\" action=\"javascript:void(0);\">\n".
			"$tab\t<div class=\"css-includes-manager\" data-type=\"theme\">\n".
			"$tab\t\t<div class=\"css-asset-header\">\n".
			"$tab\t\t\t<h3>SCSS Includes</h3>\n".
			$motor->tools->svg->icon('help-circle', $depth + 3, false, 'tooltip-show').
			"$tab\t\t</div>\n".
			"$tab\t\t<div class=\"tooltip\">Includes will appear in the compiled CSS in the exact order they appear here. Drag Includes up or down to change the output order.<br><br>De-select any Include to remove it from the compiled CSS.</div>\n".
			"$tab\t\t<ul class=\"css-asset-list css-include-list\">\n".
			$includes.
			"$tab\t\t</ul>\n".
			"$tab\t</div>\n".
			"$tab\t<div class=\"css-includes-manager\" data-type=\"editor\">\n".
			"$tab\t\t<div class=\"css-asset-header\">\n".
			"$tab\t\t\t<h3>SCSS Includes (Editor)</h3>\n".
			$motor->tools->svg->icon('help-circle', $depth + 3, false, 'tooltip-show').
			"$tab\t\t</div>\n".
			"$tab\t\t<div class=\"tooltip\">Includes will appear in the compiled CSS in the exact order they appear here. Drag Includes up or down to change the output order.<br><br>De-select any Include to remove it from the compiled CSS.</div>\n".
			"$tab\t\t<ul class=\"css-asset-list css-include-list\">\n".
			$includes_editor.
			"$tab\t\t</ul>\n".
			"$tab\t</div>\n".
			"$tab</form>\n";
	}

	private function load_includes($editor = false) {
		$all = 'includes' . ($editor ? '_editor' : false);
		$active = "{$all}_active";
		$includes = array();
		foreach ($this->$active as $id => $is_active)
			if (array_key_exists($id, $this->$all)) {	// if the include exists in the system, put it in the active order
				$includes[$id] = $this->$all[$id];
				$includes[$id]['active'] = $is_active;	// add whether or not it should be active
			}
		foreach ($this->$all as $id => $include)
			if (!array_key_exists($id, $includes)) {	// if the include isn't scheduled to be loaded yet, add it
				$includes[$id] = $include;
				$includes[$id]['active'] = true;		// new stuff is automatically on by default (for Plugin convenience)
			}
		return $includes;	// include list is now ordered and indicates whether or not each include should be active
	}

	private function include($id, $include, $editor = false, $depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$includes = 'includes'. ($editor ? '_editor' : false);
		$checked = $include['active'] ? ' checked="checked"' : false;
		return
			"$tab<li class=\"css-include-item". (!$checked ? ' inactive' : ''). "\">\n".
			"$tab\t<div class=\"css-include\">\n".
			"$tab\t\t<input type=\"hidden\" name=\"{$includes}[$id]\" value=\"0\">\n".
			"$tab\t\t<input type=\"checkbox\" class=\"css-include-active\" id=\"css-include-$id\" name=\"{$includes}[$id]\" value=\"1\"$checked>\n".
			"$tab\t\t<label for=\"css-include-$id\">". ucwords(!empty($include['name']) ? $include['name'] : $id). "</label>\n".
			$motor->tools->svg->icon('info', $depth + 2, false, 'tooltip-show').
			"$tab\t\t<div class=\"tooltip\">\n".
			(!empty($include['mixins']) ?
			"$tab\t\t\t<strong>Uses Mixins:</strong> <code>". implode('</code>, <code>', $include['mixins']). "</code><br><br>\n" : false).
			"$tab\t\t\t<strong>Source:</strong> ". $motor->text($include['source'], 'escape-html'). "\n".
			"$tab\t\t</div>\n".
			"$tab\t</div>\n".
			"$tab</li>\n";
	}

	private function scss($file) {
		return !empty($file) ?
			strip_tags(file_get_contents($file)) : false;
	}

	public function compile($css = false, $custom = false, $editor = false) {
		global $motor;
		$mixins = $includes = false;
		foreach ($this->mixins as $id => $mixin)
			if (!empty($mixin['path']))
				$mixins .= $this->scss($mixin['path']). "\n";
		foreach ($this->load_includes($editor) as $id => $include)
			if (!empty($include['path']) && !empty($include['active']))
				$includes .= $this->scss($include['path']). "\n";
		$css = $mixins. $includes. ($css ? $css : false). ($custom ? "\n/*---:[ Custom CSS ]:---*/\n$custom" : false);
		if (empty($css))
			return '';
		$css = $this->vars->css($css);
		require_once(PM_THEME_CSS_EDITOR. '/sass/SassParser.php');
		try {
			$sass = new SassParser(array(
				'style' => 'nested',
				'cache' => false,
				'syntax' => 'scss',
				'debug' => false));
			$css = $sass->toCss($css, false);
		}
		catch (Exception $e) {
			print_r($e->getMessage());
			// Maybe this can still return some borked CSS?
			die();
		}
		return $css;
	}
}