<?php
/**
 * PageMotor Theme CSS Variables Controller
 *
 * @package 	PageMotor Theme CSS Editor
 * @subpackage 	PageMotor Theme CSS Variables
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Theme_CSS_Variables {
	private $vars = array();		// [array] saved/active variables
	private $symbol = '$';			// [string] character symbol to use as variable delimiter
	private $css = array();			// [array] variable references and their associated values
	private $scrub = array();		// [array] variables yet to be scrubbed
	private $scrubbed = array();	// [array] scrubbed variables

	public function __construct($vars = false) {
		global $motor;
		$this->vars = is_array($vars) ? $vars : $this->vars;
	}

	private function options() {
		return array(
			'name' => array(
				'type' => 'text',
				'width' => 'medium',
				'label' => 'Name',
				'req' => '*'),
			'ref' => array(
				'type' => 'text',
				'width' => 'medium',
				'code' => true,
				'label' => 'Reference',
				'req' => '*'),
			'css' => array(
				'type' => 'textarea',
				'rows' => 3,
				'code' => true,
				'label' => 'Variable Value',
				'tooltip' => 'You can use variables to represent anything in your CSS. Ideally, you will create variables for repeating items, such as colors, sizes, or even <code>property: value</code> pairs. Bonus: You can use variables within variables, too. Inception, you guys.'));
	}

	public function list($buttons = true, $depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$vars = array();
		$list = '';
		foreach ($this->vars as $id => $var)
			$vars[$id] = $var['ref'];
		natcasesort($vars);
		foreach ($vars as $id => $name) {
			$var = $this->vars[$id];
			$list .= $this->var($id, $var, $buttons, $depth + 1);
		}
		return
			"$tab<ul id=\"css-var-list\">\n".
			$list.
			"$tab</ul>\n";
	}

	public function var($id, $var, $buttons = true, $depth = 9) {
		global $motor;
		if (empty($id))
			return;
		$tab = str_repeat("\t", $depth);
		return
			"$tab<li>".
			($buttons ?
			"<button class=\"css-var-edit css-draggable\" data-type=\"var\" data-id=\"$id\" data-value=\"$this->symbol". $motor->text($var['ref']). "\" data-tooltip=\"". $motor->text($var['name'], 'escape-html'). ' &rarr; '. $motor->text(str_replace(array("\r\n", "\n", "\r", "\t"), ' ', $var['css'])). "\" title=\"click to edit\">" :
			"<code class=\"css-var\" data-value=\"$this->symbol". $motor->text($var['ref']). "\" data-tooltip=\"". $motor->text($var['name'], 'escape-html'). ' &rarr; '. $motor->text(str_replace(array("\r\n", "\n", "\r", "\t"), ' ', $var['css'])). "\">").
			$this->symbol. $motor->text($var['ref']).
			($buttons ?
			"</button>" :
			"</code>").
			"</li>\n";
	}

	private function form($id) {
		global $motor;
		if (!$id) return;
		$values = array(
			'name' => !empty($this->vars[$id]['name']) ? $this->vars[$id]['name'] : '',
			'ref' => !empty($this->vars[$id]['ref']) ? $this->vars[$id]['ref'] : '',
			'css' => !empty($this->vars[$id]['css']) ? $this->vars[$id]['css'] : '');
		return
			"\t<div class=\"pm-popup-head\" data-style=\"box\">\n".
			"\t\t<div class=\"pm-popup-head-controls\">\n".
			"\t\t\t<div class=\"pm-popup-title\">Edit Variable</div>\n".
			"\t\t\t<div class=\"pm-popup-head-buttons\">\n".
			"\t\t\t\t<button class=\"css-var-save save\">Save</button>\n".
			"\t\t\t\t<button class=\"css-var-cancel\">Cancel</button>\n".
			"\t\t\t</div>\n".
			"\t\t</div>\n".
			"\t</div>\n".
			"\t<div class=\"pm-popup-body\">\n".
			$motor->tools->form->fields($this->options(), $values, 'css-var-', false, 2).
			"\t\t<input type=\"hidden\" id=\"css-var-id\" name=\"id\" value=\"". $motor->text($id). "\" />\n".
			"\t\t<input type=\"hidden\" id=\"css-var-symbol\" name=\"symbol\" value=\"$this->symbol\" />\n".
			"\t\t<div class=\"pm-popup-bottom-controls\">\n".
			"\t\t\t<button class=\"css-var-delete delete\">Delete</button>\n".
			"\t\t</div>\n".
			"\t</div>\n";
//			"\t". wp_nonce_field('thesis-save-css-variable', '_wpnonce-thesis-save-css-variable', true, false). "\n".
	}

	public function edit($var) {
		global $motor;
//		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-css');
		$id = !empty($var) && $var == 'new' ? 'css-var-'. time() : $var;
		echo $this->form($id);
	}

	public function save($var) {
		global $motor;
		if (!is_array($var) || (!$var['id'] || !$var['name'] || !$var['ref']))
			return false;
		$this->vars[$var['id']] = array(
			'name' => $motor->text(stripslashes($var['name']), 'escape-html'),
			'ref' => $motor->text(stripslashes($var['ref'])),
			'css' => stripslashes($var['css']));
		return array(
			'var' => $this->var($var['id'], $this->vars[$var['id']]),
			'vars' => $this->vars);
	}

	public function delete($var) {
		if (!is_array($var) || (!$var['id'] || !$var['name'] || !$var['ref']) || !array_key_exists($var['id'], $this->vars))
			return false;
		unset($this->vars[$var['id']]);
		return $this->vars;
	}

	public function update($vars) {
		$update = array();
		foreach ($this->vars as $id => $var)
			$update[$var['ref']] = $id;
		foreach ($vars as $ref => $value)
			if (!empty($update[$ref]))
				$this->vars[$update[$ref]]['css'] = $value;
		return $this->vars;
	}

	public function css($css) {
		foreach ($this->vars as $id => $var)
			$this->css[$var['ref']] = $this->scrub[$var['ref']] = $var['css'];
		$this->scrub($this->scrub);
		foreach ($this->scrubbed as $ref => $var_css)
			$css = preg_replace("/\\{$this->symbol}$ref". '((?=[\s\r\n;}\)])|\Z)/i', $var_css, $css);
		return $css;
	}

	private function scrub($to_scrub) {
		if (!(is_array($to_scrub) && !empty($to_scrub))) return;
		foreach ($to_scrub as $ref => $css) {
			if (strpos($css, $this->symbol) !== false)
				$this->scrub[$ref] = preg_replace_callback("/\\{$this->symbol}". '[A-Za-z0-9-_]+'. '((?=[\\$\s\r\n;}\)])|\Z)/i', array($this, 'replace'), $css);
			else {
				if (isset($this->scrub[$ref]))
					unset($this->scrub[$ref]);
				$this->scrubbed[$ref] = $css;
			}
		}
		if (!empty($this->scrub))
			$this->scrub($this->scrub);
	}

	public function replace($matches) {
		return is_array($matches) && !empty($matches[0]) && ($ref = trim($matches[0], $this->symbol)) ? (array_key_exists($ref, $this->scrubbed) ?
			$this->scrubbed[$ref] : (array_key_exists($ref, $this->css) ?
			$this->css[$ref] : '')) : '';
	}
}