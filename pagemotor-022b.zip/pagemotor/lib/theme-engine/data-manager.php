<?php
/**
 * PageMotor Theme Data Manager
 *
 * @package 	PageMotor Theme
 * @subpackage 	PageMotor Theme Data Manager
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
final class PM_Theme_Data_Manager {
	public $theme = false;						// Theme class name
	public $name = false;						// Theme name
	public $folder = false;						// Theme folder
	public $table = 'theme_backups';			// PageMotor Theme backups table
	public $options = array(
		'templates',
		'instances',
		'css_vars',
		'css_includes',
		'css_inclues_editor',
		'css',
		'css_editor',
		'css_custom',
		'design',
		'display');

	public function __construct($args = array()) {
		global $motor;
		if ($motor->page->is_theme)
			return;
		extract($args); // $theme, $name, $folder
		$this->theme = !empty($theme) ? trim($this->verify_class_name($theme)) : $this->theme;
		$this->name = isset($name) ? $name : $this->name;
		$this->folder = !empty($folder) ? $folder : $this->folder;
		$this->table = $motor->db->prefix. $this->table;
		// This is wonky. What happens when a new Theme is created but has zero initial data?
		if (!$motor->options->option("{$this->theme}_templates"))
			$this->defaults('new');
		// TODO: The Exporter could probably be run through ajax like everything else...
/*		if ($thesis->environment == 'admin')
			add_action('admin_post_export_skin', array($this, 'export'));
		if ($thesis->environment == 'ajax') {
			add_action('wp_ajax_backup_skin', array($this, 'backup'));
			add_action('wp_ajax_update_backup_skin_table', array($this, 'update_backup'));
			add_action('wp_ajax_restore_skin_backup', array($this, 'restore_backup'));
			add_action('wp_ajax_delete_skin_backup', array($this, 'delete_backup'));
			add_action('wp_ajax_restore_skin_default', array($this, 'restore_default'));
		}*/
	}

/*---:[ Theme Manager UI ]:---*/

	public function ui($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$defaults = array();
		$options = array_combine($this->options, array(
			'Templates',
			'Boxes',
			'CSS Variables',
			'CSS Includes',
			'CSS Includes Editor',
			'Theme CSS',
			'Editor CSS',
			'Custom CSS',
			'Design Options',
			'Display Options'));
		foreach ($options as $option)
			$defaults[$option] = true;
		$export = $motor->tools->form->fields(array(
			'export' => array(
				'type' => 'checkbox',
				'label' => 'Export the Following Theme Data:',
				'tooltip' => 'Share your masterpiece, move your design, or get help from an expert by exporting your Theme in whole or in part. Choose the options you want to share, and PageMotor will create a handy export file for you.',
				'options' => $options,
				'default' => $defaults)), array(), 'pm-', false, $depth + 4);
		$default = $motor->tools->form->fields(array(
			'restore' => array(
				'type' => 'checkbox',
				'label' => 'Restore Default Settings:',
				'tooltip' => 'PageMotor allows you to restore individual parts of your Theme or the whole shebang.',
				'options' => $options,
				'default' => $defaults)), array(), 'pm-', false, $depth + 4);
		return
//			"$tab<h3 id=\"t_manager_head\"><span>Manage $this->name Theme Data</span></h3>\n".
			"$tab<div class=\"data-boxes\">\n".
			"$tab\t<div class=\"data-box\">\n".
			"$tab\t\t<h4>Backup Theme Data</h4>\n".
			"$tab\t\t<p>Create a Theme backup that you can restore at any time.</p>\n".
			"$tab\t\t<button id=\"data-backup\" class=\"save\">\n".
			$motor->tools->svg->icon('plus-circle', $depth + 3).
			"$tab\t\t\tCreate New Backup\n".
			"$tab\t\t</button>\n".
			"$tab\t</div>\n".
			"$tab\t<div class=\"data-box\">\n".
			"$tab\t\t<h4>Import Theme Data</h4>\n".
			"$tab\t\t<p>Import Theme data from a PageMotor Theme export file.</p>\n".
			"$tab\t\t<button id=\"data-import\" class=\"action\">\n".
			$motor->tools->svg->icon('arrow-in', $depth + 3).
			"$tab\t\t\tImport Theme Data\n".
			"$tab\t\t</button>\n".
			"$tab\t</div>\n".
			"$tab\t<div class=\"data-box\">\n".
			"$tab\t\t<h4>Restore Default Data</h4>\n".
			"$tab\t\t<p>Restore default data for the $this->name Theme.</p>\n".
			"$tab\t\t<button id=\"data-defaults\" class=\"action\">\n".
			$motor->tools->svg->icon('refresh-ccw', $depth + 3).
			"$tab\t\t\tRestore Defaults\n".
			"$tab\t\t</button>\n".
			"$tab\t</div>\n".
			"$tab</div>\n".
			"$tab<div id=\"data-restore-backups\">\n".
			"$tab\t<h3><span>$this->name Theme Backups</span></h3>\n".
			"$tab\t<div id=\"data-backup-table\">\n".
			$this->backup_table($depth + 2).
			"$tab\t</div>\n".
			"$tab</div>\n".
			$motor->tools->ui->popup(array(
				'id' => 'theme-export',
				'title' => "Export $this->name Data",
				'depth' => $depth,
				'body' =>
					"$tab\t\t\t<form id=\"data-export\" method=\"post\" action=\"". $motor->admin_url('admin-post.php?action=export_skin'). "\">\n".
					$export.
					"$tab\t\t\t\t<input type=\"hidden\" id=\"export-id\" name=\"export[id]\" value=\"\" />\n".
					"$tab\t\t\t\t<button id=\"theme-export\" class=\"action\">\n".
					$motor->tools->svg->icon('arrow-out', $depth + 5).
					"$tab\t\t\t\t\tExport Theme Data\n".
					"$tab\t\t\t\t</button>\n".
#					"$tab\t\t\t\t". wp_nonce_field('thesis-skin-export', '_wpnonce-thesis-skin-export', true, false). "\n".
					"$tab\t\t\t</form>\n")).
			$motor->tools->ui->popup(array(
				'id' => 'theme-import',
				'title' => "Import $this->name Data",
				'depth' => $depth,
				'body' => $motor->tools->ui->uploader('theme-import'))).
			$motor->tools->ui->popup(array(
				'id' => 'theme-default',
				'title' => "Restore $this->name Defaults",
				'depth' => $depth,
				'body' =>
					"$tab\t\t\t<form id=\"data-default-form\" method=\"post\" action=\"\">\n".
					// Need to know if this is an Admin Theme...
					(file_exists(PM_THEME. '/default.php') ?
					$default.
					"$tab\t\t\t\t<button id=\"data-restore-defaults\" class=\"save\">\n".
					$motor->tools->svg->icon('refresh-ccw', $depth + 5).
					"$tab\t\t\t\t\tRestore Selected Defaults\n".
					"$tab\t\t\t\t</button>\n" :
					"$tab\t\t\t\t<p>Your Theme does not have the ability to restore individual data components. Hit the button below to restore <strong>all</strong> default settings.</p>\n".
					"$tab\t\t\t\t<button id=\"theme-restore-defaults\" class=\"save\">\n".
					$motor->tools->svg->icon('refresh-ccw', $depth + 5).
					"$tab\t\t\t\t\tRestore Defaults\n".
					"$tab\t\t\t\t</button>\n").
#					"$tab\t\t\t\t". wp_nonce_field('thesis-restore-defaults', '_wpnonce-thesis-restore-defaults', true, false). "\n".
					"$tab\t\t\t</form>\n"));
#			"$tab". wp_nonce_field('thesis-skin-manager', '_wpnonce-thesis-skin-manager', true, false). "\n";
	}

	public function backup_table($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$backups = '';
		foreach ((is_array($points = $this->get()) ? $points : array()) as $id => $backup) {
			$td = '';
			if (is_array($backup))
				foreach ($backup as $prop => $val) {
					$class = $prop == 'notes' ? ' class="pm-backup-notes"' : '';
					$value = $prop == 'time' ? date('n/j/y H:i', $val) : ($prop == 'notes' ? trim($motor->text($val)) : false);
					$td .= "$tab\t\t\t<td$class>$value</td>\n";
				}
			$backups .=
				"$tab\t\t<tr>\n".
				$td.
				"$tab\t\t\t<td>\n".
				"$tab\t\t\t\t<button class=\"data-restore-backup\" class=\"save\" data-id=\"$id\">\n".
				$motor->tools->svg->icon('refresh-ccw', $depth + 5).
				"$tab\t\t\t\t\tRestore\n".
				"$tab\t\t\t\t</button>\n".
				"$tab\t\t\t</td>\n".
				"$tab\t\t\t<td>\n".
				"$tab\t\t\t\t<button class=\"data-export-backup\" class=\"action\" data-id=\"$id\">\n".
				$motor->tools->svg->icon('arrow-out', $depth + 5).
				"$tab\t\t\t\t\tExport\n".
				"$tab\t\t\t\t</button>\n".
				"$tab\t\t\t</td>\n".
				"$tab\t\t\t<td>\n".
				"$tab\t\t\t\t<button class=\"data-delete-backup\" class=\"delete\" data-id=\"$id\">\n".
				$motor->tools->svg->icon('x-circle', $depth + 5).
				"$tab\t\t\t\t\tDelete\n".
				"$tab\t\t\t\t</button>\n".
				"$tab\t\t\t</td>\n".
				"$tab\t\t</tr>\n";
		}
		return
			"$tab<table>\n".
			"$tab\t<thead>\n".
			"$tab\t\t<tr>\n".
			"$tab\t\t\t<th>Backup Date</th>\n".
			"$tab\t\t\t<th class=\"data-backup-notes\">Notes</th>\n".
			"$tab\t\t\t<th>Restore</th>\n".
			"$tab\t\t\t<th>Export</th>\n".
			"$tab\t\t\t<th>Delete</th>\n".
			"$tab\t\t</tr>\n".
			"$tab\t</thead>\n".
			"$tab\t<tbody>\n".
			$backups.
			"$tab\t</tbody>\n".
			"$tab</table>\n";
	}

/*---:[ Theme Manager core database actions ]:---*/

	public function add($notes = false) {
		global $motor;
		$data = array(); 												// start
		foreach ($this->options as $option)
			$data[$option] = get_option("{$this->theme}_$option");		// fetch options
		$data = array_filter($data); 									// filter out empty options
		if (empty($data))
			return true;												// there are no options, so we don't need to save anything.
		if (!empty($notes)) 											// if we got to here, add notes, only if they're present
			$data['notes'] = $notes;
		// Probably want to use JSON encoding instead, which will change this entire process
		$data = array_map('maybe_serialize', $data); 					// returns an array of serialized data
		$data['time'] = current_time('timestamp'); 						// add timestamp
		$data['theme'] = $this->theme;									// add Theme class
		return (bool) $motor->db->insert($this->table, $data); 			// return true on success, false on failure
	}

	public function delete($id = false) {
		global $motor;
		if ($id === false || !is_int($id) || !($check = $this->get_entry($id)))
			return false;
		$where = array(
			'id' => $id,
			'theme' => $this->theme);
		return (bool) $motor->db->delete($this->table, array(
			'id' => $id,
			'theme' => $this->theme));
	}

	public function get() {
		global $motor;
		if (!is_array($results = $motor->db->get_rows("SELECT id, time, notes FROM $this->table WHERE theme = '$this->theme'")))
			return false;
		$valid = array();
		foreach ($results as $result)
			if (is_array($result) && !empty($result['id']) && !empty($result['time']))
				$valid[maybe_unserialize($result['id'])] = array(
					'time' => maybe_unserialize($result['time']),
					'notes' => !empty($result['notes']) ? maybe_unserialize($result['notes']) : false);
		krsort($valid);
		return !empty($valid) ? $valid : array();
	}

	public function get_entry($id = false) {
		global $motor;
		if (!is_int($id) || empty($this->theme))
			return false;
		$result = $motor->db->get_rows("SELECT * FROM $this->table WHERE id = $id");
		return !empty($result['theme']) && $result['theme'] === $this->theme ?
			$result : false;
	}

/*---:[ ajax data handling methods ]:---*/

	public function backup() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-skin-manager');
		echo $motor->tools->ui->alert($this->add(stripslashes($_POST['note'])) === false ?
			'Backup failed.' :
			'Backup complete!', 'manager_saved', true);
#		if ($thesis->environment == 'ajax') die();
	}

/*
	— Called when the backup table is updated with a new entry
	— Echoes a new backup_table() based on the most recent (updated) data
*/
	public function update_backup() {
		global $motor;
		// Maybe skip this and just call backup_table() directly?
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-skin-manager');
		echo $this->backup_table();
#		if ($thesis->environment == 'ajax') die();
	}

/*
	— Wholesale replaces all Theme options
	— Any options present in the requested backup state will be restored
	— Any options not present will be deleted (and will revert to defaults, if applicable)
*/
	public function restore_backup() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-skin-manager');
		if (empty($_POST['id'])
		|| !is_int($_POST['id'])
		|| !is_array($result = $this->get_entry($_POST['id']))
		|| empty($result['theme'])
		|| $result['theme'] != $this->theme)
			return;
		// Remove data that is not needed for the restoration
		unset($result['id'], $result['time'], $result['theme'], $result['notes']);
		if (!empty($_POST['backup']) && $_POST['backup'] == 'true')
			$this->automatic_backup('Restore Theme data');
		$verified = array();
		foreach (array_filter($result) as $key => $check)
			if (in_array($key, $this->options) && ($value = maybe_unserialize($check)))
				$verified[$key] = $value;
		foreach ($this->options as $option) {
			if (!empty($verified[$option]))
				$motor->options->update("{$this->theme}_$option", $verified[$option]);
			else
				$motor->options->delete("{$this->theme}_$option");
		}
#		$thesis->skin->_write_css();
#		if ($thesis->environment == 'ajax') die();
	}

	public function delete_backup() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-skin-manager');
		echo $motor->tools->ui->alert($this->delete($_POST['id']) === false ?
			'Deletion failed.' :
			'Backup deleted!', 'manager_saved', true);
#		if ($thesis->environment == 'ajax') die();
	}

/*
	Export selected Theme data items
	— Generates a serialized PageMotor Theme import file (.txt) with selected options (even if they are empty)
*/
	public function export() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['_wpnonce-thesis-skin-export'], 'thesis-skin-export');
		if (!is_array($_POST['export']))
			$this->error('The export data was incomplete. Please revisit the Theme Data Manager and try again.');
		elseif (($options = array_filter($_POST['export'])) && (empty($options) || empty($options['id'])))
			$this->error('No backup state was specified for export. Revisit the Theme Data Manager and try again.');
		$id = (int) $options['id'];
		unset($options['id']);
		if (!($data = $this->get_entry($id)) || $data['theme'] !== $this->theme)
			$this->error('The requested export data does not match the current Theme. Please revisit the Theme Data Manager and try again.');
		unset($data['id']);
		unset($data['notes']);
		unset($data['time']);
		$new = array();
		foreach (array_intersect(array_keys($options), $this->options) as $option)
			if (isset($data[$option]))
				$new[$option] = maybe_unserialize($data[$option]);
		$new['theme'] = $data['theme'];
		if (empty($new) || !($serialized = serialize($new)))			// serialize the whole shebang
			$this->error('Export data serialization failed. Please revisit the Theme Data Manager and try again.');
		$md5 = md5($serialized);										// get hash of data
		$hash_added = array('data' => $new, 'checksum' => $md5);		// add hash
		if (!($out = serialize($hash_added)))							// serialize it all
			$this->error('Export data serialization (with hashing) failed. Please revisit the Theme Data Manager and try again.');
		header("Content-Type: text/plain; charset=$motor->charset");
		header('Content-Disposition: attachment; filename="'. str_replace('_', '-', $this->theme). '-'. @date('Y\-m\-d\-H\-i'). '.txt"');
		printf('%s', $out);
		exit;	// Is this necessary?
	}

/*
	Import a PageMotor Theme data file
	— Any included (and valid) options will be overwritten, even if empty.
*/
	public function import($file, $action) {
		global $motor;
#		$thesis->wp->check();
#		check_admin_referer($action, 'thesis_form_nonce');
		if (empty($_FILES[$file]))
			return 'The import file is not present!';
		elseif ($_FILES[$file]['error'] > 0)
		 	return 'The server encountered an error with the import file. No data will be imported.';
		elseif (!is_array($data = $this->verify_theme_data_file($_FILES[$file], $this->theme)))
			return empty($data) || !is_string($data) ?
				'The import file does not contain valid PageMotor Theme data.' :
				$data;
		unset($data['theme']);
		if (empty($data))
			return 'The import file does not contain any Theme data.';
		$this->automatic_backup('Import Theme data');
		foreach ($data as $option => $value)
			if (in_array($option, $this->options))
				if (!empty($value))
					$motor->options->update("{$this->theme}_$option", $value);
				else
					$motor->options->delete("{$this->theme}_$option");
#		$thesis->skin->_write_css();
		return true;
	}

	public function restore_default() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-skin-manager');
		$form = array();
		if (!empty($_POST['form']))
			parse_str(stripslashes($_POST['form']), $form);
		echo $response = $this->defaults(
			!empty($form['restore']) ? $form['restore'] : array(),												// options
			!empty($_POST['backup']) && $_POST['backup'] == 'true' ? 'Restore defaults' : false) === true ?
				'true' :
				$motor->tools->ui->alert($motor->text($response, 'inline-no-links'), 'default_not_saved', true);
	}

/*---:[ Data Manager action helper methods ]:---*/

	public function defaults($restore = array(), $backup = false) {
		global $motor;
		$restore = is_array($restore) ?
			array_filter(array_map('intval', $restore)) : ($restore == 'new' ?
			array_combine($this->options, array_fill(0, count($this->options), 1)) :
			array());
		if (empty($restore))
			return 'No Theme data was selected for restoration!';
		$dir = defined('PM_USER_THEMES') && file_exists(PM_USER_THEMES. "/$this->folder") ?
			PM_USER_THEMES. "/$this->folder" : false;
		if (!empty($dir) && file_exists("$dir/default.php")) {
			include_once("$dir/default.php");
			if (function_exists("{$this->theme}_defaults")) {
				if (!is_array($default_data = call_user_func("{$this->theme}_defaults")))
					return 'The default Theme data is not in valid array format!';
				if (!empty($backup))
					$this->automatic_backup($backup, $this->theme);
				if (isset($restore['css_custom'])) {
					unset($restore['css_custom']);
					$motor->options->delete("{$this->theme}_css_custom");
				}
				foreach (array_keys($restore) as $option)
					if (isset($default_data[$option]))
						$motor->options->update("{$this->theme}_$option", $default_data[$option]);
					else
						$motor->options->delete("{$this->theme}_$option");
			}
			else
				return 'This Theme does not have a valid default.php file!';
		}
		else
			return 'This Theme does not have a default.php file!';
		# Write CSS, or else the calling method needs to rewrite it
#		if ($skin['class'] == $thesis->skin->_class)
#			$thesis->skin->_write_css();
		return true;
	}

	public function automatic_backup($state = false) {
		if (apply_filters('automatic-backups', true))
			$this->add('[Automatic backup'. (!empty($state) ? ': '. $state : ''). ']');
	}

	public function error($error) {
		global $motor;
		// Needs to know the Admin URL of the current Theme for a proper URL construction
		echo
			'<p>', $motor->text($error, 'inline'), "</p>\n",
			'<p><a href="', $motor->url_escape(set_url_scheme(home_url('?thesis_editor=1'))), '">Return to the PageMotor Theme Editor</a></p>';
		// Necessary?
		exit;
	}

/*---:[ Theme Manager database table ]:---*/

/*		if ($exists && !(bool) $wpdb->query("SHOW COLUMNS FROM $this->table LIKE 'design'"))
			$return = (bool) $wpdb->query("ALTER TABLE $this->table ADD design longtext NOT NULL");
		if ($exists && !(bool) $wpdb->query("SHOW COLUMNS FROM $this->table LIKE 'display'"))
			$return = (bool) $wpdb->query("ALTER TABLE {$this->table} ADD display longtext NOT NULL");
		if ($exists && !(bool) $wpdb->query("SHOW COLUMNS FROM $this->table LIKE 'css_editor'"))
			$return = (bool) $wpdb->query("ALTER TABLE {$this->table} ADD css_editor longtext NOT NULL");*/
/*	private function table() {
		global $motor;
#		$exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table}'");
		$exists = $motor->db->query("SHOW TABLES LIKE $this->table");
		$return = true;
		if (!empty($exists))
			return $return && true;
		else {
			$query = $motor->db->query("CREATE TABLE $this->table (
				id bigint(20) unsigned NOT NULL auto_increment,
				time bigint(20) NOT NULL,
				class varchar(200) NOT NULL,
				boxes longtext NOT NULL,
				templates longtext NOT NULL,
				css longtext NOT NULL,
				css_editor longtext NOT NULL,
				css_custom longtext NOT NULL,
				css_vars longtext NOT NULL,
				design longtext NOT NULL,
				display longtext NOT NULL,
				notes longtext NOT NULL,
				PRIMARY KEY (id)
			) COLLATE {$motor->db->collate}");				// force proper collation to avoid latin1: destroyer of worlds
			return (bool) $query && $return;
		}
	}*/

/*---:[ data verification ]:---*/

	public function verify_class_name($class) {
		return preg_match('/\A[a-zA-Z_]\w*\Z/', $class) ? $class : false;
	}

	public function verify_theme_data_file($file, $theme) {
		$string = is_string($file);
		$array = is_array($file);
		$name = $string ? basename($file) : ($array ? $file['name'] : false);
		$location = $string ? $file : ($array ? $file['tmp_name'] : false);
		if (($array || $string) && !file_exists($location))
		 	return 'The import file does not exist. Please try again.';
		elseif (empty($theme))
			return 'A valid Theme class name was not specified. No data was imported.';
		elseif (empty($name))
		 	return 'The file name is inadequate. No data will be imported.';
		elseif (!preg_match('/^[a-z0-9-]+\.txt$/', strtolower($name)))
			return 'The import file name did not pass a basic legitimacy test. No data was imported.';
		elseif (!($serialized = file_get_contents($location)))
			return 'PageMotor could not read the specified import file.';
		elseif (!is_serialized($serialized))
			return 'The import file is not properly serialized. No data will be imported.';
		elseif (!($contents = unserialize($serialized)))
			return 'The import file could not be unserialized. No data will be imported.';
		elseif (empty($contents['checksum']))
		 	return 'The import file does not have a proper checksum value and cannot be trusted.';
		elseif (empty($contents['data']))
			return 'The import file does not contain any data.';
		elseif (!is_array($contents['data']))
			return 'The import file data is not formatted properly (it should be an array).';
		elseif ($contents['checksum'] !== md5(serialize($contents['data'])))
			return 'The import file checksum does not match the file data. No data will be imported.';
		elseif (empty($contents['data']['theme']))
			return 'The import file does not specify the Theme class to which it applies. No data will be imported.';
		elseif ($contents['data']['theme'] !== $theme)
			return 'The import file does not apply to this Theme.';
		return !empty($contents['data']) ?
			$contents['data'] :
			'The import file only included empty data, so nothing was imported.';
	}
}