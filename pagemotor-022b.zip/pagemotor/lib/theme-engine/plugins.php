<?php
/**
 * PageMotor Theme Plugin Activation Controller
 *
 * @package 	PageMotor Theme
 * @subpackage 	PageMotor Theme Plugins
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Theme_Plugins {
	public $instances = array();			// [array] all Plugin instance data for the current Theme
	public $theme_options = array();		// [array] Theme-specific options
	public $content_options = array();		// [array] content-specific options (independent of Theme)
	public $admin = false;					// [bool] true if the activating Theme is an Admin Theme
	public $active = array();				// [array] all active Plugin objects
	public $children = array();				// [array] instances with custodians
	public $dependents = array();			// [array] Plugins that require custodians
	public $add = array();					// [array] instance-based Plugins that can be added via Box forms
	public $plugin_class = 'PM_Plugin';		// [string] PageMotor Plugin base class

	public function __construct($instances, $theme_options, $admin = false) {
		global $motor;
		$this->instances = is_array($instances) ? $instances : $this->instances;
		$this->theme_options = is_array($theme_options) ? $theme_options : $this->theme_options;
		$this->admin = $admin;
		$this->activate($motor->plugins->active, $motor->plugins->all, $this->admin);
	}

	private function activate($classes, $info, $admin) {
		global $motor;
		foreach ($classes as $class)
			if ($admin || (!$admin && (empty($info[$class]['type']) || strtolower($info[$class]['type']) !== 'admin')))
				$this->create($class, $admin);
		$activate_children = array();
		foreach ($this->children as $parent_id => $child)
			foreach ($child as $class => $child_plugin)
				if (!empty($this->active[$parent_id])
				&& !empty($this->dependents[$this->active[$parent_id]->_class])
				&& !empty($this->dependents[$this->active[$parent_id]->_class][$child_plugin->_class]))
					$activate_children[$parent_id][$child_plugin->_class] = array(
						'plugin' => $child_plugin,
						'order' => $this->dependents[$this->active[$parent_id]->_class][$child_plugin->_class]);
		if (!empty($activate_children))
			foreach ($activate_children as $parent => $children) {
				$ordered = $motor->tools->sort_by($children, 'order', true);
				foreach ($ordered as $item)
					$this->assign_dependent($item['plugin']);
			}
		if (!empty($this->dependents))
			foreach ($this->active as $id => $plugin)
				if (!empty($this->dependents[$plugin->_class]))
					$this->add_dependents($plugin);
	}

	private function create($class, $admin) {
		if (!empty($this->instances[$class])) {
			foreach ($this->instances[$class] as $id => $options) {
				if (class_exists($class) && is_subclass_of($class, $this->plugin_class)) {
					$plugin = new $class(array(
						'id' => $id,
						'options' => $options,
						'admin_theme' => $admin),
						$this->theme_options);
					if (!$plugin->_parent && empty($plugin->custodians)) {
						if ($plugin->name)
							$this->add[$class] = $plugin;
						$this->assign($plugin);
					}
					else {
						$this->children[$plugin->_parent][$plugin->_class] = $plugin;
						foreach ($plugin->custodians as $custodian => $setup)
							if (empty($this->dependents[$custodian][$class]))
								$this->dependents[$custodian][$class] = empty($setup['order']) ? 100 : $setup['order'];
					}
				}
			}
		}
		elseif (class_exists($class) && is_subclass_of($class, $this->plugin_class)) {
			$plugin = new $class(array(
				'admin_theme' => $admin),
				$this->theme_options);
			if ($plugin->name)
				$this->add[$class] = $plugin;
			elseif (!empty($plugin->custodians)) {
				foreach ($plugin->custodians as $custodian => $setup)
					if (empty($this->dependents[$custodian][$class]))
						$this->dependents[$custodian][$class] = empty($setup['order']) ? 100 : $setup['order'];
			}
			else
				$this->assign($plugin);
		}
	}

	private function assign($plugin) {
		if (empty($this->active[$plugin->_id]))
			$this->active[$plugin->_id] = $plugin;
		if ($plugin->_parent) {
			$this->active[$plugin->_parent]->_dependents[$plugin->_class] = $plugin->_id;
			if (!empty($plugin->custodians)
			&& array_key_exists($this->active[$plugin->_parent]->_class, $plugin->custodians)
			&& !empty($plugin->custodians[$this->active[$plugin->_parent]->_class])
			&& !empty($plugin->custodians[$this->active[$plugin->_parent]->_class]['startup'])) {
				$this->active[$plugin->_parent]->_startup[] = $plugin->_id;
				if (empty($this->instances[$plugin->_class][$plugin->_id]))
					$this->instances[$plugin->_class][$plugin->_id] = array('_parent' => $plugin->_parent);
			}
		}
	}

	private function assign_dependent($plugin) {
		$plugin->_lineage = $plugin->_parent ?
			(($this->active[$plugin->_parent]->_lineage ?
				$this->active[$plugin->_parent]->_lineage : '').
			($this->active[$plugin->_parent]->name ?
				$this->active[$plugin->_parent]->name : $this->active[$plugin->_parent]->title). " &rarr; ") : false;
		$this->assign($plugin);
	}

	public function add($id) {
		if (empty($id))
			return;
		if (!empty($this->active[$id])) {
			$box = $this->active[$id];
			$this->add_dependents($box);
			return array(
				'box' => $box);
		}
		elseif (class_exists($id)) {
			$box = new $id(array('id' => "{$id}_". time()));
			$this->instances[$box->_class][$box->_id] = array();
			$this->assign($box);
			$this->add_dependents($box);
			return array(
				'box' => $box,
				'instances' => $this->instances);
		}
		else
			return;
	}

	private function add_dependents($box) {
		if (empty($this->dependents[$box->_class]))
			return;
		asort($this->dependents[$box->_class]);
		foreach($this->dependents[$box->_class] as $class => $order) {
			if (!empty($this->active["{$box->_id}_$class"]))
				$dependent = $this->active["{$box->_id}_$class"];
			else {
				$dependent = new $class(array(
					'options' => array(
						'_parent' => $box->_id),
					'admin_theme' => $this->admin),
					$this->theme_options);
				$this->assign_dependent($dependent);
			}
			$box->_add_boxes[$dependent->_id] = $dependent;
		}
	}

	public function delete($delete) {
		if (!empty($delete))
			foreach ($delete as $id)
				$this->delete_box($id);
	}

	private function delete_box($id) {
		if (!is_object($box = $this->active[$id]))
			return;
		if (!empty($box->_dependents))
			foreach ($box->_dependents as $dependent)
				$this->delete_box($dependent);
		unset($this->active[$id]);
		unset($this->instances[$box->_class][$id]);
	}

	public function save($form) {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['_wpnonce-thesis-update-boxes'], 'thesis-update-boxes');
		if (!empty($form) && is_array($form))
			foreach ($this->active as $id => $plugin)
				if (!empty($form[$plugin->_class][$plugin->_id]) && is_array($values = $form[$plugin->_class][$plugin->_id])) {
					$options = $motor->options->set(
						array_merge($plugin->_admin_options, $plugin->_html_options, $plugin->_box_options),
						array_merge($plugin->box_options, $values));
					if ($plugin->name)
						$options['_name'] = !empty($values['_name']) ? $values['_name'] : $plugin->name;
					if ($plugin->_parent)
						$options['_parent'] = $plugin->_parent;
					if (!empty($options['attributes']))
						$options['attributes'] = $motor->tools->sanitize_html_attributes($options['attributes']);
					if (empty($options))
						$this->delete_box($id);
					else
						$this->instances[$plugin->_class][$plugin->_id] = $options;
				}
		return $this->instances;
	}
}