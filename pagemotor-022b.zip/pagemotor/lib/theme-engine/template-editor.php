<?php
/**
 * PageMotor Theme Template Editor
 *
 * @package 	PageMotor Theme
 * @subpackage 	PageMotor Theme Template Editor
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Theme_Template_Editor {
	private $core_templates = array();	// [array] core templates for the current Theme
	private $templates = array();		// [array] saved template data for the current Theme
	private $custom = array();			// [array] 2-part array of 'templates' and associated 'ids'
	private $options = array();			// [array] box options for this set of templates
	private $template = array();		// [array] the current template displayed in the Editor
	public $form = false;				// [object] Box Form object

	public function __construct($core_templates = array(), $templates = array(), $options = array()) {
		global $motor;
		$this->core_templates = is_array($core_templates) ? $core_templates : $this->core_templates;
		$this->templates = is_array($templates) ? $templates : $this->templates;
		$this->custom = $this->get_custom();
		$this->options = is_array($options) ? $options : $this->options;
		$this->form = $motor->tools->box_form();
	}

	public function editor($data = array(), $depth = 0) {
		global $motor;
		if (!is_array($data) || !is_array($this->template = $data['template']) || !is_array($form = $data['form']))
			return;
		$tab = str_repeat("\t", $depth);
		$switch = !empty($this->options) || in_array($this->template['id'], $this->custom['ids']) ?
			$motor->tools->svg->icon('settings', $depth + 1, 'template-options', 'switch') : '';
		return
			"$tab<div id=\"template-controls\">\n".
			"$tab\t<button id=\"template-button\" title=\"open the Template Manager\">\n".
			$motor->tools->svg->icon('file', $depth + 2).
			"$tab\t\t<span id=\"template-button-title\">{$this->template['title']}</span>\n".
			"$tab\t</button>\n".
			$switch.
			"$tab</div>\n".
			$this->manager($depth).
			"$tab<form id=\"template-form\" method=\"post\" action=\"\" enctype=\"multipart/form-data\">\n".
			"$tab\t<input type=\"hidden\" id=\"template-current\" name=\"template\" value=\"{$this->template['id']}\" />\n".
			$this->options($depth + 1).
			$this->form->body(array_merge($form, array('depth' => $depth + 1))).
//			"$tab\t". wp_nonce_field('thesis-save-template', '_wpnonce-thesis-ajax', true, false). "\n".
			"$tab\t<button id=\"template-save\" class=\"save pm-ui-save\">\n".
			$motor->tools->svg->icon('check-circle', $depth + 2).
			"$tab\t\tSave Template\n".
			"$tab\t</button>\n".
			"$tab</form>\n".
			$motor->tools->ui->alert('Saving template&hellip;', 'saving-template', false, 'action', $depth);
	}

	private function manager($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$core = $custom = '';
		$hierarchy = array();
		foreach ($this->core_templates as $name => $template)
			if (!empty($template['parent'])) {
				if (!is_array($hierarchy[$template['parent']]))
					$hierarchy[$template['parent']] = array();
				$hierarchy[$template['parent']][] = $name;
			}
			else
				$hierarchy[$name] = false;
		foreach ($hierarchy as $name => $templates) {
			$class = $name == $this->template['id'] ? ' class="template-current"' : '';
			$data = " data-template=\"$name\"";
			$children = '';
			if (is_array($templates)) {
				$child_links = '';
				foreach ($templates as $child) {
					$child_class = $child == $this->template['id'] ? ' class="template-current"' : '';
					$child_data = " data-template=\"$child\"";
					$child_links .=
						"$tab\t\t\t\t\t<li$child_class$child_data>\n".
						$this->edit_template_options($child, $this->core_templates[$child]['title'], false, $depth + 6).
						"$tab\t\t\t\t\t</li>\n";
				}
				$children =
					"$tab\t\t\t\t<ul class=\"template-children\">\n".
					$child_links.
					"$tab\t\t\t\t</ul>\n";
			}
			$core .=
				"$tab\t\t\t<li$class$data>\n".
				$this->edit_template_options($name, $this->core_templates[$name]['title'], !empty($children) ? true : false, $depth + 4).
				(!empty($children) ? $children : '').
				"$tab\t\t\t</li>\n";
		}
		if (!empty($this->custom['templates'])) {
			$custom_links = '';
			foreach ((array) $this->custom['templates'] as $name => $template) {
				$current = $name == $this->template['id'] ? ' template-current' : '';
				$custom_links .=
					"$tab\t\t\t<li class=\"template-custom$current\" data-template=\"$name\">\n".
					$this->edit_template_options($name, $template['title'], false, $depth + 4).
					"$tab\t\t\t</li>\n";
			}
			$custom =
				"$tab\t\t<ul>\n".
				$custom_links.
				"$tab\t\t</ul>\n";
		}
		return
			"$tab<div id=\"template-manager\">\n".
			"$tab\t<div id=\"templates-core\" class=\"manager-col\">\n".
			"$tab\t\t<div class=\"template-manager-header\">\n".
			"$tab\t\t\t<h4 class=\"template-manager-heading\">Core Templates</h4>\n".
			"$tab\t\t</div>\n".
			"$tab\t\t<ul>\n".
			$core.
			"$tab\t\t</ul>\n".
			"$tab\t</div>\n".
			"$tab\t<div id=\"templates-custom\" class=\"manager-col\">\n".
			"$tab\t\t<div class=\"template-manager-header\">\n".
			"$tab\t\t\t<h4 class=\"template-manager-heading\">Custom Templates</h4>\n".
			"$tab\t\t\t<button id=\"template-add\"class=\"action\" title=\"add a new template\">\n".
			$motor->tools->svg->icon('file-plus-2', $depth + 4).
			"$tab\t\t\t\tAdd New\n".
			"$tab\t\t\t</button>\n".
			"$tab\t\t</div>\n".
			$custom.
			"$tab\t</div>\n".
			"$tab\t<div id=\"template-copy-from\" class=\"manager-col\">\n".
			"$tab\t\t<div class=\"template-manager-header\">\n".
			"$tab\t\t\t<h4 class=\"template-manager-heading\">Copy from Template</h4>\n".
			"$tab\t\t</div>\n".
			$this->copy_form($depth + 2).
			"$tab\t</div>\n".
			"$tab</div>\n".
			$this->add_form($depth);
	}

	private function edit_template_options($name = false, $title = false, $children = false, $depth = 0) {
		global $motor;
		if (empty($name) || empty($title))
			return;
		$tab = str_repeat("\t", $depth);
		return
			"$tab<div class=\"template-edit-options\" data-template=\"$name\">\n".
			($name == $this->template['id'] ?
			"$tab\t$title\n" :
			"$tab\t<span class=\"template-edit\" title=\"edit this template\">$title</span>\n").
			($children ?
			$motor->tools->svg->icon('plus-square', $depth + 1, false, 'toggle-children toggle-children-on').
			$motor->tools->svg->icon('minus-square', $depth + 1, false, 'toggle-children toggle-children-off') : '').
			($name != $this->template['id'] ?
			$motor->tools->svg->icon('x-square', $depth + 1, false, 'template-delete') : '').
			"$tab</div>\n";
	}

	private function add_form($depth = 1) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$fields = $motor->tools->form->fields(array(
			'title' => array(
				'type' => 'text',
				'width' => 'medium',
				'label' => 'New Template Name',
				'tooltip' => 'The name you specify here will be used to identify this template throughout the PageMotor interface.<br><br>To avoid confusion, always give your templates unique names.')), array(), 'template-add-', false, $depth + 4);
		return $motor->tools->ui->popup(array(
			'id' => 'template-new',
			'type' => 'new-template',
			'title' => 'Create New Template',
			'depth' => $depth,
			'body' =>
				"$tab\t\t\t<form method=\"post\" action=\"\">\n".
				$fields.
				"$tab\t\t\t\t<p>\n".
				"$tab\t\t\t\t\t<button type=\"submit\" id=\"template-create\" class=\"save\" name=\"add_template\">\n".
				$motor->tools->svg->icon('file-plus-2', $depth + 6).
				"$tab\t\t\t\t\t\tCreate Template\n".
				"$tab\t\t\t\t\t</button>\n".
				"$tab\t\t\t\t</p>\n".
				"$tab\t\t\t</form>\n"));
	}

	private function copy_form($depth = 2) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$options = array();
		$options[''] = 'Select a template:';
		foreach ($this->templates as $id => $template)
			if ($id != $this->template['id'] && (!empty($template['title']) || !empty($this->core_templates[$id]['title'])))
				$options[$id] = !empty($template['title']) ? $template['title'] : $this->core_templates[$id]['title'];
		$fields = $motor->tools->form->fields(array(
			'copy-from' => array(
				'type' => 'select',
				'options' => $options)), array(), false, false, $depth + 1);
	 	return
			"$tab<form method=\"post\" action=\"\">\n".
			$fields.
			"$tab\t<input type=\"hidden\" id=\"copy-to\" name=\"template\" value=\"{$this->template['id']}\" />\n".
			"$tab\t<button type=\"submit\" id=\"template-copy\" class=\"save\" name=\"copy_template\">\n".
			$motor->tools->svg->icon('copy', $depth + 2).
			"$tab\t\tCopy Template\n".
			"$tab\t</button>\n".
			"$tab</form>\n";
	}

	// Need to go over this method in detail and remove what is no longer needed...
	private function options($depth = 0) {
		global $motor;
		$menu = $panes = array();
		$custom = $name = false;
		$title = ": {$this->template['title']}";
		if ($custom = in_array($this->template['id'], $this->custom['ids'])) {
			$title = '';
			$name = array(
				'id' => 'template-title',
				'name' => 'title',
				'value' => $this->template['title']);
		}
		foreach ($this->options as $class => $options)
			if (is_array($options)) {
				$options['exclude'] = !empty($options['exclude']) && is_array($options['exclude']) ? $options['exclude'] : array();
				// what to exclude
				$exclude = array();
				if (!empty($this->template['id']))
					$exclude[] = $this->template['id'];
				if (!empty($this->core_templates[$this->template['id']]['parent']))
					$exclude[] = $this->core_templates[$this->template['id']]['parent'];
				if (!empty($custom))
					$exclude[] = 'custom';
				if ((!empty($options['exclude']) && !array_intersect($exclude, $options['exclude'])) || empty($options['exclude'])) {
					$menu[$class] = $options['title'];
					$panes[$class] = $motor->tools->form->fields($options['fields'], (!empty($this->template['options'][$class]) ? $this->template['options'][$class] : false), "template-{$class}_",  "options[$class]", $depth + 4);
				}
			}
		return $motor->tools->ui->popup(array(
			'id' => 'template-options',
			'type' => 'template',
			'title' => "Template$title",
			'name' => $name,
			'menu' => $menu,
			'panes' => $panes,
			'depth' => $depth));
	}

	private function get_custom() {
		global $motor;
		$templates = $core = $ids = array();
		$core = array_keys($this->core_templates);
		foreach ($this->templates as $id => $template)
			if (!in_array($id, $core) && !empty($template['title'])) {
				$templates[$id] = $template;
				$ids[] = $id;
			}
		return array(
			'templates' => $motor->tools->sort_by($templates, 'title', true),
			'ids' => $ids);
	}

	public function save($form = array()) {
		global $motor;
		if (empty($form) || !is_array($form) || empty($form['template']))
			return false;
		$save = $new = array();
		$id = $form['template'];
		$values = is_array($form['options']) ? $form['options'] : array();
		$title = !empty($form['title']) ? $form['title'] : false;
		if (!empty($title))
			$save['title'] = $title;
		elseif (!empty($this->templates[$id]['title']))
			$save['title'] = $this->templates[$id]['title'];
		foreach ($this->options as $class => $options)
			if (is_array($options) && $new[$class] = $motor->options->set($options['fields'], !empty($values[$class]) ? $values[$class] : false))
				$save['options'][$class] = $new[$class];
		if (is_array($boxes = $this->form->save($form))) {
			if (is_array($boxes['boxes']) && !empty($boxes['boxes']))
				$save['boxes'] = $boxes['boxes'];
			if (is_array($boxes['delete']))
				foreach ($boxes['delete'] as $box)
					$this->remove_box($box);
		}
		if (empty($save))
			unset($this->templates[$id]);
		else
			$this->templates[$id] = $save;
		return array(
			'templates' => $this->templates,
			'delete_boxes' => $boxes['delete']);
	}

	private function remove_box($id) {
		if (!is_array($this->templates))
			return;
		foreach ($this->templates as $name => $template)
			if (!empty($template['boxes']) && is_array($template['boxes']))
				foreach ($template['boxes'] as $container => $boxes)
					if ($container == $id)
						unset($this->templates[$name]['boxes'][$container]);
					elseif (is_array($boxes))
						foreach ($boxes as $position => $box)
							if ($box == $id)
								unset($this->templates[$name]['boxes'][$container][$position]);
	}
}