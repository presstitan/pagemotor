<?php
/**
 * PageMotor Theme Tools
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Theme
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Theme_Tools {
	public $color = false;		// [object] Color tools
	public $css = false;		// [object] CSS properties, options, and relevant methods
	public $grt = false;		// [object] Golden Ratio Typography (GRT) tools

	public function __construct() {
		if (!defined('PM_THEME_TOOLS'))
			define('PM_THEME_TOOLS', PM_THEME_ENGINE. '/tools');
		require_once(PM_THEME_TOOLS. '/color.php');
		require_once(PM_THEME_TOOLS. '/css.php');
		require_once(PM_THEME_TOOLS. '/grt.php');
		$this->color = new PM_Theme_Tools_Color;
		$this->css = new PM_Theme_Tools_CSS;
		$this->grt = new PM_Theme_Tools_GRT;
	}
}