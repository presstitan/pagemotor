<?php
/**
 * PageMotor Theme CSS Tools
 *
 * @package 	PageMotor Theme
 * @subpackage 	PageMotor Theme Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Theme_Tools_CSS {
	public $strings = array();		// [array] strings for use in CSS options
	public $properties = array();	// [array] properties for use in CSS options
	public $options = array();		// [array] pre-defined options for use in CSS forms

	public function __construct() {
		$this->strings = $this->strings();
		$this->properties = $this->properties();
		$this->options = $this->options();
	}

	private function strings() {
		return array(
			'font' => 'Font',
			'color' => 'Color',
			'background' => 'Background',
			'width' => 'Width',
			'height' => 'Height',
			'position' => 'Position',
			'margin' => 'Margin',
			'padding' => 'Padding',
			'top' => 'Top',
			'right' => 'Right',
			'bottom' => 'Bottom',
			'left' => 'Left',
			'links' => 'Links',
			'text' => 'Text',
			'border' => 'Border',
			'style' => 'Style',
			'default' => 'default',
			'normal' => 'normal',
			'none' => 'none');
	}

	private function properties() {
		global $motor;
		return array(
			'font-family' => array('' => 'Select a font:'),
			'font-weight' => array(
				'' => $this->strings['default'],
				'bold' => 'bold',
				'bolder' => 'bolder',
				'lighter' => 'lighter',
				100 => 100,
				200 => 200,
				300 => 300,
				400 => 400,
				500 => 500,
				600 => 600,
				700 => 700,
				800 => 800,
				900 => 900,
				'inherit' => 'inherit',
				'normal' => $this->strings['normal']),
			'font-style' => array(
				'' => $this->strings['default'],
				'italic' => 'italic',
				'oblique' => 'oblique',
				'normal' => $this->strings['normal']),
			'font-variant' => array(
				'' => $this->strings['default'],
				'small-caps' => 'small caps',
				'normal' => $this->strings['normal']),
			'text-transform' => array(
				'' => $this->strings['default'],
				'capitalize' => 'capitalize',
				'uppercase' => 'uppercase',
				'lowercase' => 'lowercase',
				'none' => $this->strings['none']),
			'text-align' => array(
				'' => $this->strings['default'],
				'left' => 'left',
				'center' => 'center',
				'right' => 'right',
				'justify' => 'justify'),
			'text-decoration' => array(
				'' => $this->strings['default'],
				'none' => $this->strings['none'],
				'underline' => 'underline',
				'overline' => 'overline',
				'line-through' => 'line through',
				'blink' => 'blink'),
			'background-repeat' => array(
				'' => sprintf('repeat (%s)', $this->strings['default']),
				'no-repeat' => 'no repeat',
				'repeat-x' => 'repeat-x',
				'repeat-y' => 'repeat-y'),
			'background-attachment' => array(
				'' => $this->strings['default'],
				'scroll' => 'scrolls with page',
				'fixed' => 'fixed&#8212;does not scroll'),
			'border-style' => array(
				'' => $this->strings['default'],
				'solid' => 'solid',
				'dotted' => 'dotted',
				'dashed' => 'dashed',
				'double' => 'double',
				'groove' => 'groove',
				'ridge' => 'ridge',
				'inset' => 'inset',
				'outset' => 'outset',
				'none' => $this->strings['none']),
			'position' => array(
				'' => $this->strings['default'],
				'absolute' => 'absolute',
				'relative' => 'relative',
				'fixed' => 'fixed'),
			'display' => array(
				'' => $this->strings['default'],
				'block' => 'block',
				'inline' => 'inline',
				'inline-block' => 'inline block',
				'table' => 'table',
				'inline-table' => 'inline table'),
			'float' => array(
				'' => $this->strings['default'],
				'left' => 'left',
				'right' => 'right'),
			'clear' => array(
				'' => $this->strings['default'],
				'left' => 'left',
				'right' => 'right',
				'both' => 'both',
				'none' => $this->strings['none']),
			'visibility' => array(
				'' => $this->strings['default'],
				'hidden' => 'hidden',
				'visible' => 'visible'),
			'overflow' => array(
				'' => $this->strings['default'],
				'visible' => 'visible',
				'hidden' => 'hidden',
				'scroll' => 'scroll',
				'auto' => 'auto'),
			'box-sizing' => array(
				'' => sprintf('content box (%s)', $this->strings['default']),
				'border-box' => 'border box'),
			'cursor' => array(
				'' => 'unspecified',
				'auto' => 'auto',
				'default' => $this->strings['default'],
				'pointer' => 'pointer',
				'crosshair' => 'crosshair',
				'help' => 'help',
				'move' => 'move',
				'text' => 'text'),
			'list-style-type' => array(
				'' => $this->strings['default'],
				'circle' => 'circle',
				'decimal' => 'decimal',
				'decimal-leading-zero' => 'decimal with leading zero',
				'disc' => 'disc',
				'lower-alpha' => 'lower alpha',
				'lower-roman' => 'lower Roman',
				'none' => $this->strings['none'],
				'square' => 'square',
				'upper-alpha' => 'upper alpha',
				'upper-roman' => 'upper Roman'));
	}

	private function options() {
		global $motor;
		$s = array(
			'text_color' => sprintf('%1$s %2$s', $this->strings['text'], $this->strings['color']),
			'text_decoration' => sprintf('%1$s Decoration', $this->strings['text']),
			'list' => 'List',
			'space' => 'space',
			'num_tooltip' => 'If you enter only a number, your output will be in pixels. If you want to use any other unit, please supply it here.');
		return array(
			'font' => array(
				'type' => 'group',
				'label' => sprintf('%s Settings', $this->strings['font']),
				'fields' => array(
					'font-family' => array(
						'type' => 'select',
						'label' => $this->strings['font'],
						'options' => $this->properties['font-family']),
					'font-size' => array(
						'type' => 'text',
						'width' => 'tiny',
						'label' => sprintf('%s Size', $this->strings['font']),
						'description' => 'px'),
					'line-height' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('Line %s', $this->strings['height']),
						'tooltip' => sprintf('You can specify a line height directly, or you can automatically generate line heights according to <a href="%s" target="_blank" rel="noopener">Golden Ratio Typography</a>.', 'https://grtcalculator.com/')),
					'font-weight' => array(
						'type' => 'select',
						'label' => sprintf('%s Weight (bold)', $this->strings['font']),
						'options' => $this->properties['font-weight']),
					'font-style' => array(
						'type' => 'select',
						'label' => sprintf('%1$s %2$s (italic)', $this->strings['font'], $this->strings['style']),
						'options' => $this->properties['font-style']),
					'font-variant' => array(
						'type' => 'select',
						'label' => sprintf('%s Variant', $this->strings['font']),
						'options' => $this->properties['font-variant']),
					'text-transform' => array(
						'type' => 'select',
						'label' => sprintf('%s Transform', $this->strings['text']),
						'options' => $this->properties['text-transform']),
					'text-align' => array(
						'type' => 'select',
						'label' => sprintf('%s Align', $this->strings['text']),
						'options' => $this->properties['text-align']),
					'letter-spacing' => array(
						'type' => 'text',
						'width' => 'tiny',
						'label' => 'Letter Spacing',
						'description' => 'px'))),
			'color' => array(
				'type' => 'color',
				'label' => $s['text_color']),
			'background' => array(
				'type' => 'group',
				'label' => $this->strings['background'],
				'fields' => array(
					'background-color' => array(
						'type' => 'color',
						'label' => sprintf('%1$s %2$s', $this->strings['background'], $this->strings['color'])),
					'background-image' => array(
						'type' => 'text',
						'width' => 'long',
						'code' => true,
						'label' => sprintf('%s Image', $this->strings['background']),
						'tooltip' => 'Enter a relative path or full URL to your image. For example, if you want to use an image from the Images tab called <code>myimage.png</code>, you would enter: <code>images/myimage.png</code>. Also: No quotes!'),
					'background-position' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['background'], $this->strings['position']),
						'tooltip' => 'This field requires input in the form of <code>X Y</code>. <strong>Note:</strong> You must specify a unit (px, em, %, etc) with your input!'),
					'background-attachment' => array(
						'type' => 'radio',
						'label' => sprintf('%s Attachment', $this->strings['background']),
						'options' => $this->properties['background-attachment']),
					'background-repeat' => array(
						'type' => 'radio',
						'label' => sprintf('%s Repeat', $this->strings['background']),
						'options' => $this->properties['background-repeat']))),
			'width' => array(
				'type' => 'text',
				'width' => 'short',
				'label' => $this->strings['width'],
				'tooltip' => $s['num_tooltip']),
			'box-sizing' => array(
				'type' => 'radio',
				'label' => 'Box Sizing',
				'options' => $this->properties['box-sizing']),
			'float' => array(
				'type' => 'select',
				'label' => 'Float',
				'options' => $this->properties['float']),
			'margin' => array(
				'type' => 'group',
				'label' => $this->strings['margin'],
				'fields' => array(
					'margin-top' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['top'], $this->strings['margin'])),
					'margin-right' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['right'], $this->strings['margin'])),
					'margin-bottom' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['bottom'], $this->strings['margin'])),
					'margin-left' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['left'], $this->strings['margin'])))),
			'padding' => array(
				'type' => 'group',
				'label' => $this->strings['padding'],
				'fields' => array(
					'padding-top' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['top'], $this->strings['padding'])),
					'padding-right' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['right'], $this->strings['padding'])),
					'padding-bottom' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['bottom'], $this->strings['padding'])),
					'padding-left' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['left'], $this->strings['padding'])))),
			'border' => array(
				'type' => 'group',
				'label' => $this->strings['border'],
				'fields' => array(
					'border-width' => array(
						'type' => 'text',
						'width' => 'short',
						'label' => sprintf('%1$s %2$s', $this->strings['border'], $this->strings['width']),
						'tooltip' => $s['num_tooltip']),
					'border-style' => array(
						'type' => 'select',
						'label' => sprintf('%1$s %2$s', $this->strings['border'], $this->strings['style']),
						'options' => $this->properties['border-style']),
					'border-color' => array(
						'type' => 'color',
						'label' => sprintf('%1$s %2$s', $this->strings['border'], $this->strings['color']),
						'tooltip' => 'If you&#8217;ve specified a border width, your border will be the color you input here.'))),
			'links' => array(
				'type' => 'group',
				'label' => $this->strings['links'],
				'fields' => array(
					'link' => array(
						'type' => 'color',
						'label' => $s['text_color']),
					'link-decoration' => array(
						'type' => 'select',
						'label' => $s['text_decoration'],
						'options' => $this->properties['text-decoration']))),
			'links-hovered' => array(
				'type' => 'group',
				'label' => sprintf('Hovered %s', $this->strings['links']),
				'fields' => array(
					'link-hover' => array(
						'type' => 'color',
						'label' => $s['text_color']),
					'link-hover-decoration' => array(
						'type' => 'select',
						'label' => $s['text_decoration'],
						'options' => $this->properties['text-decoration']))),
			'links-visited' => array(
				'type' => 'group',
				'label' => sprintf('Visited %s', $this->strings['links']),
				'fields' => array(
					'link-visited' => array(
						'type' => 'color',
						'label' => $s['text_color']),
					'link-visited-decoration' => array(
						'type' => 'select',
						'label' => $s['text_decoration'],
						'options' => $this->properties['text-decoration']))),
			'links-active' => array(
				'type' => 'group',
				'label' => sprintf('Active %s', $this->strings['links']),
				'fields' => array(
					'link-active' => array(
						'type' => 'color',
						'label' => $s['text_color']),
					'link-active-decoration' => array(
						'type' => 'select',
						'label' => $s['text_decoration'],
						'options' => $this->properties['text-decoration']))),
			'lists' => array(
				'type' => 'group',
				'label' => 'Lists',
				'fields' => array(
					'list-style-type' => array(
						'type' => 'select',
						'label' => sprintf('%1$s %2$s', $s['list'], $this->strings['style']),
						'options' => $this->properties['list-style-type']),
					'list-style-position' => array(
						'type' => 'select',
						'label' => sprintf('Bullet %s', $this->strings['position']),
						'options' => array(
							'' => 'outside (default)',
							'inside' => 'inside')),
					'list-indent' => array(
						'type' => 'checkbox',
						'options' => array(
							'on' => 'Indent list (add left margin)')),
					'list-item-margin' => array(
						'type' => 'radio',
						'label' => sprintf('%1$s Item %2$s %3$s', $s['list'], $this->strings['bottom'], $this->strings['margin']),
						'options' => array(
							'' => sprintf('no %s', strtolower($this->strings['margin'])),
							'half' => sprintf('half %s', $s['space']),
							'single' => sprintf('single %s', $s['space']))))),
			'typography' => array(
				'type' => 'text',
				'width' => 'tiny',
				'label' => 'Typography: Enter Width of Text Area',
				'tooltip' => 'For perfect typography, enter the exact width of your text area, and your typography will be calibrated to fit this context.<br /><br /><strong>Note:</strong> The value you enter here will not affect the width of your text area, but it <em>will</em> ensure that your typography is awesome!',
				'description' => 'px'));
	}

	public function font_size_color($name = false, $font = false, $size = false, $color = false) {
		$name = !empty($name) ? "-$name" : '';
		$font = is_array($font) ? $font : array();
		$size = is_array($size) ? $size : array();
		$color = is_array($color) ? $color : array();
		return array(
			"font-family$name" => array_merge($this->options['font']['fields']['font-family'], $font),
			"font-size$name" => array_merge($this->options['font']['fields']['font-size'], $size),
			"color$name" => array_merge($this->options['color'], $color));
	}

	public function trbl($type, $values) {
		if (!$type || !is_array($values)) return false;
		$dims = array('top', 'right', 'bottom', 'left');
		$props = array();
		if ($type == 'margin' || $type == 'padding')
			foreach ($dims as $dim)
				if (!empty($values["$type-$dim"]))
					$props[$dim] = "$type-$dim: ". $this->number($values["$type-$dim"]). ';';
		return is_array($props) ? implode(' ', $props) : false;
	}

	public function number($value, $default = false) {
		return !empty($value) ? (is_numeric($value) ? "{$value}px" : $value) : ($default ? $default : false);
	}

	public function write_from_array($css) {
		if (!is_array($css)) return;
		$s = array();
		foreach (array_filter($css) as $selector => $properties)
			if (is_array($properties)) {
				$p = array();
				foreach (array_filter($properties) as $property => $value)
					$p[] = "$property: $value;";
				if (!empty($p))
					$s[] = "$selector { ". implode(' ', $p). " }";
			}
		return !empty($s) ? implode("\n", $s) : '';
	}

	public function unit($value, $base = false, $unit = false) {
		if (empty($value)) return;
		$value = is_array($value) ? $value : array($value);
		foreach ($value as $dim => $val)
			if (!empty($val)) {
				$units['px'][$dim] = $val == 0 ? '0' : "{$val}px";
				$units['pct'][$dim] = $val == 0 ? '0' : "$val%";
				if (!empty($base)) {
					$units['em'][$dim] = $val == 0 ? '0' : round($val / $base, 6). "em";
					$units['rem'][$dim] = $val == 0 ? '0' : round($val / $base, 6). "rem";
				}
			}
			else
				$units['px'][$dim] = $val;
		return !empty($base) || (!empty($unit) && !empty($units[$unit])) ? $units[$unit] : $units['px'];
	}

	public function prefix($property, $value) {
		if (!$property || !$value) return false;
		$css = array();
		$vendors = array('-webkit', '-moz');
		foreach ($vendors as $vendor)
			$css[] = "$vendor-$property: $value;";
		return !empty($css) ? implode(' ', $css). " $property: $value;" : false;
	}
}