<?php
/**
 * PageMotor Theme Golden Ratio Typography (GRT) Tools
 *
 * @package 	PageMotor Theme
 * @subpackage 	PageMotor Theme Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Theme_Tools_GRT {
	public $phi = false;			// [float] Golden Ratio value
	public $factor = 34;			// [float] Width factor, hold constant for use in font tuning
	public $fonts = array(); 		// [array] array of available fonts in PageMotor Font Array Format

	public function __construct() {
		global $motor;
		$this->phi = (1 + sqrt(5)) / 2;
		$this->fonts = $motor->fonts->all();
//		$this->factor = !empty($factor) && is_numeric($factor) ? $factor : $this->factor;
//		add_action('init', array($this, 'get_fonts'), 12);	// Timing ensures fonts are fully-loaded
	}

	public function fonts($fonts) {
		$this->fonts = !empty($fonts) && is_array($fonts) ? $fonts : $this->fonts;
	}

/*
	Use your primary font size to determine a typographical scale for your design
	Note: In the return array, index f5 is your primary font size.
*/
	public function scale($size) {
		return empty($size) || !is_numeric($size) ? false : array(
			'f1' => round($size * pow($this->phi, 2)),
			'f2' => round($size * pow($this->phi, 1.5)),
			'f3' => round($size * $this->phi),
			'f4' => round($size * sqrt($this->phi)),
			'f5' => $size,
			'f6' => round($size * (1 / sqrt($this->phi))));
	}

/*
	Determine the appropriate line height for a given font size and associated context
	– $size: font size that will serve as the basis for the line height calculation
	– $width: (optional) for precise line height tuning, supply a content width here (use the same units as your font size)
	– $font: (optional) for maximum precision, indicate the font being used
*/
	public function height($size = false, $width = false, $font = false) {
		$x = !empty($font) && !empty($this->fonts[$font]) && !empty($this->fonts[$font]['x']) && is_numeric($this->fonts[$font]['x']) ?
			($this->fonts[$font]['x'] - $this->phi + 1) / $this->phi : 0;
		return !empty($size) && is_numeric($size) ?
			$size * ((3 - $this->phi) + (2 * $this->phi - 3) * (!empty($width) && is_numeric($width) ? $width / ($size * $this->factor) : 1) + $x) :
			false;
	}

/*
	Determine layout spacing values based on a primary spacing unit.
	NOTE: The line height of the primary text is the preferred primary spacing unit.
*/
	public function spacing($unit) {
		return empty($unit) || !is_numeric($unit) ? array() : array(
			'x1' => round($unit * $this->phi),
			'x2' => $unit,
			'x3' => $x2 = round($unit / $this->phi),
			'x4' => $x3 = round($x2 / $this->phi),
			'x5' => $x5 = round($x3 / $this->phi),
			'x6' => round($x5 / $this->phi));
	}
}