<?php
/**
 * PageMotor Theme Model
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Theme
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Theme {
	// Critical properties set by the Theme model
	public $_seed = false;				// [object] Theme seed object, if available
	public $_class = false; 			// [string] Theme class name
	public $_info = array();			// [array] basic Theme properties
	public $_name = false;				// [string] PageMotor will auto-set this to your Theme name
	public $_docs = false;				// [string] if a doc URL is provided in Theme headers, it will be available here
	public $_display_options = array();	// [array] Display Options
	public $_design_options = array();	// [array] Design Options
	public $_display = array();			// [array] saved Theme Display Options (raw)
	public $_design = array();			// [array] saved Theme Design Options (raw)
	public $_instances = array();		// [array] data for all active Plugin instances
	public $_options = array();			// [array] data for active Plugins with Theme Options
	public $_plugins = false;			// [object] Plugin activation and assignment controller
	public $_templates = array();		// [array] active Theme templates
	public $_core_templates = array();	// [array] core Theme templates
	public $_template = array();		// [array] current template data
	public $_prefetch = array();		// [array] URLs to prefetch in the document <head>
	public $_preconnect = array();		// [array] URLs to preconnect to in the document <head>
	public $_preload = array();			// [array] URLs to preload in the document <head>
	public $_font_js = array();			// [array] font JS files to include in the document <head> before CSS files
	public $_add_css = array();			// [array] CSS files to add before the Theme CSS file
	public $_mixins = array();			// [array] SCSS mixin files to include before the CSS
	public $_includes = array();		// [array] SCSS files to append to the Theme CSS file in the specified order
	public $_includes_editor = array();	// [array] SCSS files to append to the Theme Editor CSS file in the specified order
	public $_js = array();				// [array] JS files to include in Theme output
	public $_template_editor = false;	// [object] Template Editor controller
	public $_css = false;				// [object] CSS Editor controller
	public $_manager = false;			// [object] Data Manager controller
	public $_content_types = array();	// [array] content types to add to PageMotor environments (Theme, Admin)
	public $_register_js = array();		// [array] JS files registered by Theme Extensions
	// Critical properties to be changed by Admin Theme extensions
	public $_seed_data = 'data_seed';		// [string] Option to indicate if Theme data has been seeded
	public $_seed_content = 'content_seed';	// [string] Option to indicate if Theme content has been seeded
	public $_admin_theme = false;			// [bool] Set to true if Admin Theme
	public $_admin_slug = 'theme';			// [string] URL slug for Theme UI in the admin
	// Reserved properties for use in all Theme extensions
	public $tools = false;					// [object] Theme Tools
	public $display = array();				// [array] saved Theme display options (massaged)
	public $design = array();				// [array] saved Theme design options (massaged)
	// Documentation links and functional overrides for Theme extensions
	public $docs = array(					// [array] Additional links to Theme documentation (if provided)
		'custom-css',
		'design',
		'display');
	public $functionality = array();		// [array] Theme-defined functionality overrides

	public function __construct($info) {
		global $motor;
		// Paths
		if (!defined('PM_THEME_ENGINE'))
			define('PM_THEME_ENGINE', PM_LIB. '/theme-engine');
		// Includes
		require_once(PM_THEME_ENGINE. '/css-editor.php');
		require_once(PM_THEME_ENGINE. '/data-manager.php');
		require_once(PM_THEME_ENGINE. '/tools.php');
		require_once(PM_THEME_ENGINE. '/image-uploader.php');
		require_once(PM_THEME_ENGINE. '/plugins.php');
		require_once(PM_THEME_ENGINE. '/template-editor.php');
		// Set up basic Theme properties
		$this->_class = get_class($this);
		$this->_info = !empty($info) ? $info : $this->_info;
		$this->_name = !empty($this->_info['name']) ? $this->_info['name'] : $this->_name;
		$this->_docs = !empty($this->_info['docs']) ? $this->_info['docs'] : $this->_docs;
		// Seed Theme data
		$this->_seed();
		// Register content types
		$motor->content->add_types(array_merge($this->_content_types, $this->content_types()));
		// Add Fonts
		$motor->fonts->add($this->fonts(), $this->google_fonts());
		// Gather Plugin options for Plugin activation
		$this->_instances = $motor->options->option("{$this->_class}_instances", $this->_instances);
		$this->_options = $motor->options->option("{$this->_class}_options", $this->_options);
		// Activate Plugins
		$this->_plugins = new PM_Theme_Plugins($this->_instances, $this->_options, $this->_admin_theme);
		// Design and Display Options
		$this->tools = new PM_Theme_Tools;
		$this->_display_options = $this->display();
		$this->_design_options = $this->design();
		$this->_display = $motor->options->option("{$this->_class}_display", $this->display);
		$this->_design = $motor->options->option("{$this->_class}_design", $this->design);
		$this->display = $motor->options->get($this->_display_options, $this->_display);
		$this->design = $motor->options->get($this->_design_options, $this->_design);
		// Set up Templates
		$this->_templates = $motor->options->option("{$this->_class}_templates", $this->_templates);
		$this->_core_templates = $this->_core_templates();
		// Set up Theme-specific Content Options
		$this->_content_options();
		// Pseudo-constructor for Theme extensions
		$this->construct();
	}

	protected function construct() {
		// Constructor for Theme extensions
	}

	protected function content_types() {
		return array();
	}

	protected function fonts() {
		return array();
	}

	protected function google_fonts() {
		return array();
	}

	protected function display() {
		return array();
	}

	protected function design() {
		return array();
	}

	protected function scss_mixins() {
		return array();
	}

	protected function scss_includes() {
		return array();
	}

	protected function scss_includes_editor() {
		return array();
	}

	protected function content_options() {
		return array();
	}

	protected function register_js() {
		return array();
	}

	protected function font_js() {
		return array();
	}

	protected function css() {
		return array();
	}

	protected function js() {
		return array();
	}

	protected function css_vars() {
		return array();
	}

	public function body_classes() {
		return array();
	}

	public function body_classes_editor() {
		return array();
	}

/*
	Automatically construct core templates based on registered content types and the current environment
*/
	protected function _core_templates() {
		global $motor;
		$templates = array();
		$environment = $this->_admin_theme ? 'admin' : 'theme';
		foreach ($motor->content->types as $id => $type)
			if (!empty($type['name']) && !empty($type['environment'])
			&& is_array($type['environment']) && in_array($environment, $type['environment']) && !empty($type['url'])) {
				$templates[$id] = array('title' => $type['name']);
				if (!empty($type['sub-types']) && is_array($type['sub-types']))
					foreach ($type['sub-types'] as $sub_id => $sub_type)
						if (!empty($sub_type['name']))
							$templates["$id-$sub_id"] = array('title' => "{$type['name']}: {$sub_type['name']}", 'parent' => $id);
			}
		$templates['search'] = array('title' => 'Search');
		$error = $templates['error'];
		unset($templates['error']);
		$templates['error'] = $error;
		return $templates;
	}

	protected function _content_options() {
		global $motor;
		$core = array_keys($this->_core_templates);
		$custom_templates = array();
		foreach ($this->_templates as $id => $template)
			if (!in_array($id, $core) && !empty($template['title']))
				$custom_templates[$id] = $motor->text($template['title'], 'no-html');
		if (!$this->_admin_theme)
			$motor->content->options[$this->_class] = array_merge(array(
				'title' => "$this->_name Theme Custom Template",
				'types' => array('page'), 		// This needs to reference $motor->content for greater flexibility
				'order' => 1,
				'fields' => array(
					'template' => array(
						'type' => 'select',
						'label' => 'Custom Template',
						'tooltip' => '<strong>NOTE:</strong> Any Custom Template you select here only applies to the current Theme!',
						'options' => array_merge(array('' => 'No Custom Template'), $custom_templates)))), $this->content_options());
	}

	public function __run() {
		global $motor;
		$this->_init();
		// Need to work in a way for the Front End Theme to run ajax methods as well...
		if ($motor->page->is_ajax) {
			if (((!empty($_POST['admin_ui']) && $this->_admin_theme) || (!empty($_POST['theme']) && $_POST['theme'] === $this->_class))
			&& !empty($_POST['method']) && method_exists($this, $_POST['method'])) {
				$this->{$_POST['method']}();
				die();
			}
			// Need to account for specific Plugin IDs?
			elseif (!empty($_POST['theme']) && $_POST['theme'] === $this->_class
			&& !empty($_POST['plugin']) && !empty($_POST['method']) && !empty($this->_plugins->active[$_POST['plugin']])
			&& method_exists($this->_plugins->active[$_POST['plugin']], $_POST['method'])) {
				$this->_plugins->active[$_POST['plugin']]->{$_POST['method']}();
				die();
			}
			else
				return;
		}
		elseif (!$this->_run())
			return;
		$this->_template = $this->_get_template(
			!empty($motor->page->options)
			&& !empty($motor->page->options[$this->_class])
			&& !empty($motor->page->options[$this->_class]['template']) ?
				$motor->page->options[$this->_class]['template'] : false);
		$this->_template();
	}

	protected function _init() {
		global $motor;
		// Register JS
		$this->_registered_js = array_merge(array(
			'ajax' => array(
				'script' =>
					"<script>\n".
					"var pm_ajax_url = '". str_replace('/', '\/', $motor->page->url). "';\n".
					"</script>")), $this->_registered_js);
		foreach (array_merge($this->_register_js, $this->register_js()) as $name => $script)
			if (!array_key_exists($name, $this->_registered_js))
				$this->_registered_js[$name] = $script;
		// Add Font JS, CSS, and JS to appear on all templates
		$this->_font_js = $this->font_js();
		$this->_add_css = $this->css();
		$this->_js = $this->js();
		// Set Plugin options and register assets
		foreach ($this->_plugins->active as $id => $plugin) {
			// Set Content Options
			if (!empty($plugin->_content_options) && !empty($motor->page->options[$plugin->_class]))
				$plugin->content_options = $motor->page->options[$plugin->_class];
			// Register JS
			foreach ($plugin->register_js() as $name => $script)
				if (!array_key_exists($name, $this->_registered_js))
					$this->_registered_js[$name] = $script;
			// Add Font JS that will appear on all templates
			$this->_font_js = array_merge($this->_font_js, $plugin->font_js());
		}
		// Get Google Fonts from the current design and add them to CSS queues
		$this->_add_css = array_merge($this->_add_css, $motor->fonts->google->get($this->design));
	}

	protected function _run() {
		global $motor;
		if ($motor->page->is_theme && !$this->_admin_theme)
			return true;
		elseif ($motor->page->is_admin && $this->_admin_theme)
			return true;
		else
			return false;
	}

	private function _get_template($name = false) {
		global $motor;
		if (!empty($name) && (!empty($this->_templates[$name]) || !empty($this->_core_templates[$name])))
			$id = $name;
		elseif (!empty($motor->page->content['type']))
			$id = $motor->page->content['type']. (!empty($motor->page->content['sub_type']) ? "-{$motor->page->content['sub_type']}" : '');
		elseif ($motor->page->is_search)
			$id = 'search';
		elseif ($motor->page->error)
			$id = 'error';
		else
			$id = false;
		return empty($id) ?
			array(
				'id' => false,
				'type' => false,
				'title' => false,
				'options' => array(),
				'boxes' => array()) :
			array(
				'id' => $id,
				'type' => !empty($this->_core_templates[$id]) ? (!empty($this->_core_templates[$id]['parent']) ?
					$this->_core_templates[$id]['parent'] : $id) : false,
				'title' => !empty($this->_templates[$id]['title']) ?
					$this->_templates[$id]['title'] : (!empty($this->_core_templates[$id]['title']) ?
					$this->_core_templates[$id]['title'] : false),
				'options' => !empty($this->_templates[$id]['options']) ?
					$this->_templates[$id]['options'] : array(),
				'boxes' => !empty($this->_templates[$id]['boxes']) ?
					$this->_templates[$id]['boxes'] : (!empty($this->_core_templates[$id]['parent']) && !empty($this->_templates[$this->_core_templates[$id]['parent']]['boxes']) ?
					$this->_templates[$this->_core_templates[$id]['parent']]['boxes'] : array()));
	}

	protected function _template() {
		$this->_preload_plugins();
		$this->_preload_assets();
		$this->template();
	}

	protected function _preload_plugins() {
		global $motor;
		// Load assets from Plugins included in the current template
		foreach ($this->_unique_template_boxes($this->_template['boxes']) as $id)
			if (!empty($this->_plugins->active[$id])) {
				// Set Template Options
				if (!empty($this->_template['options']) && array_key_exists($this->_plugins->active[$id]->_class, $this->_template['options']))
					$this->_plugins->active[$id]->template_options = $this->_template['options'][$this->_plugins->active[$id]->_class];
				// Run Plugin preload()
				$this->_plugins->active[$id]->preload();
				// Add Plugin CSS + JS
				$this->_add_css = array_merge($this->_add_css, $this->_plugins->active[$id]->css());
				$this->_js = array_merge($this->_js, $this->_plugins->active[$id]->js());
			}
		// Load conditional assets from Plugins
		if ($motor->page->is_admin && !empty($motor->page->content['type'])) {
			if (!empty($_POST['plugin']) && !empty($this->_plugins->active[$_POST['plugin']])) {
				if ($motor->page->content['type'] === 'admin-plugins') {		// Site Options
					$this->_add_css = array_merge($this->_add_css, $this->_plugins->active[$_POST['plugin']]->site_options_css());
					$this->_js = array_merge($this->_js, $this->_plugins->active[$_POST['plugin']]->site_options_js());
				}
				elseif ($motor->page->content['type'] === 'admin-theme') {
					if ($motor->page->content['sub_type'] === 'options')		// Theme Options
						$this->_js = array_merge($this->_js, $this->_plugins->active[$_POST['plugin']]->theme_options_js());
					elseif ($motor->page->content['sub_type'] === 'elements')	// Box Options
						$this->_js = array_merge($this->_js, $this->_plugins->active[$_POST['plugin']]->box_options_js());
				}
			}
			elseif ($motor->page->content['type'] === 'admin-content')			// Content Options
				foreach ($this->_plugins->active as $id => $plugin)
					$this->_js = array_merge($this->_js, $plugin->content_options_js());
			elseif ($motor->page->content['type'] === 'admin-theme' && $motor->page->content['sub_type'] === 'editor')	// Template Options
				foreach ($this->_plugins->active as $id => $plugin)
					$this->_js = array_merge($this->_js, $plugin->template_options_js());
		}
	}

	protected function _unique_template_boxes($containers = array()) {
		$boxes = array();
		foreach ($containers as $name => $container) {
			if (!in_array($name, $boxes))
				$boxes[] = $name;
			if (!empty($container))
				foreach ($container as $box)
					if (!in_array($box, $boxes))
						$boxes[] = $box;
		}
		return $boxes;
	}

	protected function _preload_assets() {
		$js = $required = array();
		foreach ($this->_js as $script)
			if (!array_key_exists($script, $this->_registered_js)) //empty($this->_regsitered_js[$name]))
				unset($this->_js[array_search($script, $this->_js)]);
//			if (!empty($this->_registered_js[$name]['requires']))
//				foreach ($this->_registered_js[$name]['requires'] as $script) {
//					if (!in_array($script, $this->_js) && array_key_exists($script, $this->_registered_js))
//						$this->_js[] = $script;
//					else
//						unset(array_search($name, $this->_js), $this->_js);
//					if (!in_array($script, $required) && in_array($script, $this->_js))
//						$required[] = $script;
//				}
//		echo "Required scripts:\n"; print_r($required);
//		$this->_js = array_merge($this->_required_js($required), $this->_js);
		// Prepare Font JS and Additional CSS, and then perform associated prefetch, preconnect, and preload optimizations
		foreach ($this->_js as $script)
			$js[$script] = $this->_registered_js[$script];
		$this->_preload_sources($this->_font_js);
		$this->_preload_sources($this->_add_css);
		$this->_preload_sources($js);
	}

	protected function _required_js($required, $ordered = array()) {
		if (empty($required))
			return $ordered;
		foreach ($required as $key => $script)
			if (empty($this->_registered_js[$script]['required'])) {
				$ordered[] = $script;
				unset($required[$key]);
				unset($this->_js[array_search($script, $this->_js)]);
			}
			else {
				foreach ($this->_registered_js[$script]['required'] as $req)
					if (!in_array($req, $ordered))
						$ordered[] = $req;
			}
		return $ordered;
	}

	protected function _preload_sources($sources) {
		foreach ($sources as $item => $info) {
			if (!empty($info['prefetch']))
				foreach ($info['prefetch'] as $name => $source)
					if (!array_key_exists($name, $this->_prefetch))
						$this->_prefetch[$name] = $source;
			if (!empty($info['preconnect']))
				foreach ($info['preconnect'] as $name => $source)
					if (!array_key_exists($name, $this->_preconnect))
						$this->_preconnect[$name] = $source;
			if (!empty($info['preload']))
				foreach ($info['preload'] as $name => $preload)
					if (!array_key_exists($name, $this->_preload))
						$this->_preload[$name] = $preload;
		}
	}

	protected function html_document() {
		return array(
			'HTML_Head',
			'HTML_Body');
	}

	protected function template() {
		global $motor;
		$direction = !empty($motor->options->option('direction')) ? $motor->options->option('direction') : 'ltr';
		$language = !empty($motor->options->option('language')) ? $motor->options->option('language') : 'en-US';
		echo
			"<!DOCTYPE html>\n".
			"<html dir=\"$direction\" lang=\"$language\" template=\"{$this->_template['id']}\">\n";
		$this->html($this->html_document());
		echo
			"</html>";
	}

	protected function html($boxes, $depth = -1) {
		if (empty($boxes))
			return;
		foreach ($boxes as $id)
			if (!empty($this->_plugins->active[$id])
			&& is_object($this->_plugins->active[$id])
			&& !empty($this->_plugins->active[$id]->type)
			&& $this->_plugins->active[$id]->_display()) {
				if (array_key_exists($id, $this->_template['boxes'])) {	// container
					$this->_plugins->active[$id]->container_open($depth);
					$this->html($this->_template['boxes'][$id], $depth + 1);
					$this->_plugins->active[$id]->container_close($depth);
				}
				else 	// box
					$this->_plugins->active[$id]->html($depth);
			}
	}

	public function _body_classes() {
		global $motor;
		$classes = array();
		$template = !empty($this->_template['title']) ? $this->_template['title'] : $this->_template['id'];
		$classes[] = 'template-'. str_replace(' ', '-', strtolower(preg_replace('/[^A-Za-z0-9 ]/', '', $template)));
		return array_merge($classes, $this->body_classes());
	}

	protected function _body_classes_editor() {
		global $motor;
		return is_array($classes = $this->body_classes_editor()) ?
			$motor->text(implode(' ', array_map('trim', $classes))) : false;
	}

	public function _admin($depth = 0) {
		return
			$this->admin($depth);
	}

	protected function admin($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$items = false;
		$uis = array(
			'design' => array(
				'name' => 'Design Options',
				'description' => 'Change the way your design looks and works in seconds!',
				'button-title' => 'Edit Design Options'),
			'display' => array(
				'name' => 'Display Options',
				'description' => 'Turn certain items on or off within your templates.',
				'button-title' => 'Edit Display Options'),
			'elements' => array(
				'name' => 'Editable Elements',
				'description' => 'Some elements of your Theme are editable; change them here.',
				'button-title' => 'Modify Editable Elements'),
			'options' => array(
				'name' => 'Plugin Options',
				'description' => 'Some Plugins have options that integrate with this Theme.',
				'button-title' => 'Edit Plugin Options'),
			'css' => array(
				'name' => 'Custom CSS',
				'description' => 'Achieve any design tweak you want with Custom CSS.',
				'button-title' => 'Edit Custom CSS',
				'button-icon' => 'edit',
				'button-text' => 'Edit Custom CSS'),
			'editor' => array(
				'name' => 'Theme Editor',
				'description' => 'Edit Templates and base CSS, and even backup/restore your Theme!',
				'button-title' => 'Launch Theme Editor',
				'button-icon' => 'sliders',
				'button-text' => 'Edit Theme'));
		// See if any Plugins are actually serving Theme Options; if not, remove 'options'
		foreach ($uis as $type => $ui)
			$items .=
				"$tab\t<form class=\"pm-ui-form pm-ui-flex-item\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}$type/\" enctype=\"multipart/form-data\">\n".
				"$tab\t\t<h4>". $motor->text($ui['name'], 'inline-no-links'). "</h4>\n".
				"$tab\t\t<p class=\"small\">". $motor->text($ui['description'], 'inline'). "</p>\n".
				"$tab\t\t<button class=\"pm-ui-button action\" title=\"". $motor->text($ui['button-title'], 'inline-no-links'). "\">\n".
				$motor->tools->svg->icon(!empty($ui['button-icon']) ? $ui['button-icon'] : 'settings', $depth + 3).
				"$tab\t\t\t". (!empty($ui['button-text']) ? $motor->text($ui['button-text'], 'inline-no-links') : 'Settings'). "\n".
				"$tab\t\t</button>\n".
				"$tab\t</form>\n";
		return
			"$tab<div class=\"pm-ui-title-controls\">\n".
			"$tab\t<h2>". $motor->text($this->_name, 'inline-no-links'). " Theme Options</h2>\n".
			"$tab</div>\n".
			"$tab<div class=\"pm-theme-ui pm-ui-flex pm-ui-flex-3\">\n".
			$items.
			"$tab</div>\n";
	}

	public function _admin_elements($depth = 0) {
		if (empty($_POST) || empty($_POST['instance']))
			return
				$this->admin_elements($depth);
		else
			return
				$this->_instance_admin($_POST['instance'], $depth);
	}

	protected function admin_elements($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$instances = array();
		$list = '';
		foreach ($this->_plugins->active as $id => $plugin)
			if ($plugin->_display() && !$plugin->head && !empty($plugin->_box_options))
				$instances[$id] =
					"$tab\t<li>\n".
					"$tab\t\t<form class=\"admin-instance-edit\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}\" enctype=\"multipart/form-data\">\n".
					"$tab\t\t\t<input type=\"hidden\" name=\"plugin\" value=\"$plugin->_class\">\n".
					"$tab\t\t\t<input type=\"hidden\" name=\"instance\" value=\"$id\">\n".
					"$tab\t\t\t<button type=\"submit\" class=\"instance-submit\">". $motor->text((!empty($plugin->_lineage) ? $plugin->_lineage : ''). (!empty($plugin->name) ? $plugin->name : $plugin->title), 'inline-no-links'). "</button>\n".
					"$tab\t\t</form>\n".
					"$tab\t</li>\n";
		ksort($instances);
		foreach ($instances as $name => $li)
			$list .= $li;
		return
			"$tab<h2>$this->_name Theme Elements</h2>\n".
			"$tab<p class=\"caption\">Customize elements in your design by clicking on the links below</p>\n".
			"$tab<ul class=\"select-vert\">\n".
			$list.
			"$tab</ul>\n";
	}

	public function _instance_admin($instance = false, $depth = 0) {
		global $motor;
		if (empty($instance) || empty($this->_plugins->active[$instance]))
			return;
		$tab = str_repeat("\t", $depth);
		$options = $this->_plugins->active[$instance]->_box_options($depth + 1);
		return
			$motor->tools->ui->admin_options_form(array(
				'title' => "{$options['name']} Options",
				'name' => 'Options',
				'docs' => $options['docs'],
				'form' => $options['html'],
				'hidden' => array(
					'theme' => $this->_class,
					'instance' => $instance),
				'class' => 'admin-instance',
				'ajax' => true,
				'type' => 'instance',
				'depth' => $depth,
				'save_icon' => 'check-circle'));
	}

	public function _admin_css($depth = 0) {
		$this->_css = new PM_Theme_CSS_Editor($this->_get_css());
		return
			$this->admin_css($depth);
	}

	protected function _get_css() {
		global $motor;
		$scss = array(
			'scss_mixins' => '_mixins',
			'scss_includes' => '_includes',
			'scss_includes_editor' => '_includes_editor');
		foreach ($scss as $method => $property)
			if (is_array($items = $this->$method())) {
				foreach ($items as $id => $item) {
					if (is_array($item) && !empty($item['path']))
						$items[$id]['source'] = "$this->_name Theme";
					else
						unset($items[$id]);
				}
				$this->$property = array_merge($this->$property, $items);
			}
		foreach ($this->_plugins->active as $id => $plugin)
			foreach ($scss as $method => $property)
				if (is_array($items = $plugin->$method())) {
					foreach ($items as $id => $item) {
						if (is_array($item) && !empty($item['path'])
						&& (!$this->_admin_theme || ($this->_admin_theme && (!isset($item['admin']) || !empty($item['admin'])))))
							$items[$id]['source'] = "$plugin->title Plugin";
						else
							unset($items[$id]);
					}
					$this->$property = array_merge($this->$property, $items);
				}
		return array(
			'theme' => $motor->options->option("{$this->_class}_css"),
			'editor' => $motor->options->option("{$this->_class}_css_editor"),
			'custom' => $motor->options->option("{$this->_class}_css_custom"),
			'vars' => $motor->options->option("{$this->_class}_css_vars", array()),
			'mixins' => $this->_mixins,
			'includes' => $this->_includes,
			'includes_active' => $motor->options->option("{$this->_class}_css_includes", array()),
			'includes_editor' => $this->_includes_editor,
			'includes_editor_active' => $motor->options->option("{$this->_class}_css_includes_editor", array()));
	}

	protected function admin_css($depth = 0) {
		global $motor;
		return
			$this->_css->custom($this->_class, !empty($this->docs) && !empty($this->docs['custom_css']) ? $this->docs['custom_css'] : false, $depth);
	}

	public function _admin_design($depth = 0) {
		return
			$this->admin_design($depth);
	}

	protected function admin_design($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$options = $motor->tools->form->fields($this->_design_options, $this->_design, "{$this->_class}_", $this->_class, $depth + 1);
		$name = $motor->text($this->_name, 'inline-no-links');
		$form = array(
			'title' => "$name Theme Design Options",
			'name' => 'Design Options',
			'docs' => !empty($this->docs) && !empty($this->docs['design']) ? $this->docs['design'] : false,
			'form' => $options,
			'id' => 'theme-design',
			'class' => 'pm-theme-options',
			'hidden' => array(
				'theme' => $this->_class),
			'ajax' => true,
			'depth' => $depth,
			'save_icon' => 'check-circle');
		if (empty($options)) {
			unset($form['form']);
			$form['empty'] = "<p>The $name Theme does not have any design options.</p>";
		}
		return
			$motor->tools->ui->admin_options_form($form);
	}

	protected function _save_design() {
		global $motor;
		// Need something like stripslashes_deep for the $_POST data?
		parse_str(stripslashes($_POST['form']), $form);
		if (empty($form[$this->_class]))
			echo $motor->tools->ui->alert('Design Options NOT saved!', 'design-saved', true);
		else {
			$this->design = $motor->options->set($this->_design_options, $form[$this->_class]);
			$motor->options->update("{$this->_class}_design", $this->design);
			$this->_write_css();
			echo $motor->tools->ui->alert('Design Options saved!', 'design-saved', true);
		}
	}

	public function _admin_display($depth = 0) {
		return
			$this->admin_display($depth);
	}

	protected function admin_display($depth = 0) {
		global $motor;
		$options = $motor->tools->form->fields($this->_display_options, $this->_display, "{$this->_class}_", $this->_class, $depth + 1);
		$name = $motor->text($this->_name, 'inline-no-links');
		$form = array(
			'title' => "$name Theme Display Options",
			'name' => 'Display Options',
			'docs' => !empty($this->docs) && !empty($this->docs['display']) ? $this->docs['display'] : false,
			'description' => 'Use these options to control what displays in your Theme',
			'form' => $options,
			'id' => 'theme-display',
			'class' => 'pm-theme-options',
			'hidden' => array(
				'theme' => $this->_class),
			'ajax' => true,
			'depth' => $depth,
			'save_icon' => 'check-circle');
		if (empty($options)) {
			unset($form['form']);
			$form['empty'] = "<p>The $name Theme does not have any display options.</p>";
		}
		return
			$motor->tools->ui->admin_options_form($form);
	}

/*	protected function _save_admin_display() {
		global $motor;
		if (empty($_POST[$this->_class]))
			return false;
		// Need something like stripslashes_deep
		// But maybe a regular stripslashes() will work for JSON-encoded data
		$save = $motor->options->set($this->display(), $_POST[$this->_class]);
		if (empty($save))
			$motor->options->delete("{$this->_class}_display");
		else
			$motor->options->update("{$this->_class}_display", $save);
		// write new CSS
		return true;
	}*/

	public function _admin_options($depth = 0) {
		global $motor;
		if (!empty($_POST) && !empty($_POST['plugin']))
			return $this->_admin_options_plugin($_POST['plugin'], $depth);
		$plugins = false;
		$theme_options = array();
		foreach ($this->_plugins->active as $id => $plugin)
			if (!empty($plugin->_theme_options) && empty($theme_options[$id])) {
				$theme_options[$id] = array(
					'title' => $plugin->title,
					'class' => $plugin->_class);
			}
		asort($theme_options);
		$tab = str_repeat("\t", $depth);
		foreach ($theme_options as $plugin_id => $data)
			$plugins .=
				"$tab\t<form class=\"pm-ui-form pm-ui-flex-item\" method=\"post\" action=\"{$_SERVER['REQUEST_URI']}\" enctype=\"multipart/form-data\">\n".
				"$tab\t\t<input type=\"hidden\" name=\"plugin\" value=\"$plugin_id\">\n".
				"$tab\t\t<h4>". (!empty($data['title']) ? $motor->text($data['title'], 'inline-no-links') : $data['class']). "</h4>\n".
				"$tab\t\t<button class=\"plugin-settings-button action\" title=\"Plugin Settings\">\n".
				$motor->tools->svg->icon('settings', $depth + 3).
				"$tab\t\t\tSettings\n".
				"$tab\t\t</button>\n".
				"$tab\t</form>\n";
		return
			"$tab<div class=\"pm-ui-title-controls\">\n".
			"$tab\t<h2>". $motor->text($this->_name, 'inline-no-links'). " Theme Plugin Options</h2>\n".
			"$tab</div>\n".
			"$tab<p>The following Plugins have options that integrate with this Theme.</p>\n".
			"$tab<div class=\"pm-theme-ui pm-ui-flex pm-ui-flex-3\">\n".
			$plugins.
			"$tab</div>\n";
	}

	public function _admin_options_plugin($id, $depth = 0) {
		global $motor;
		if (empty($id))
			return "No Plugin ID was specified!\n";
		elseif (empty($this->_plugins->active[$id]))
			return "The Plugin ($id) was not found in the active list for this Theme!\n";
		elseif (empty($this->_plugins->active[$id]->_theme_options))
			return "The specified Plugin ($id) does not have Theme Options!\n";
		$options = $this->_plugins->active[$id]->_theme_options($depth + 1);
		return
			$motor->tools->ui->admin_options_form(array(
				'title' => "{$options['name']} Theme Options",
				'name' => 'Options',
				'docs' => $options['docs'],
				'form' => $options['html'],
				'hidden' => array(
					'theme' => $this->_class,
					'plugin' => $id),
				'class' => 'plugin-theme-options',
				'ajax' => true,
				'type' => 'options',
				'depth' => $depth,
				'save_icon' => 'check-circle'));
	}

	public function _save_options() {
		global $motor;
		parse_str(stripslashes($_POST['form']), $form);
		if (!empty($form['plugin']) && !empty($this->_plugins->active[$form['plugin']])
		&& !empty($this->_plugins->active[$form['plugin']]->_theme_options)
		&& !empty($form[$this->_plugins->active[$form['plugin']]->_class])) {
			$options = $motor->options->set(
				$this->_plugins->active[$form['plugin']]->_theme_options,
				$form[$this->_plugins->active[$form['plugin']]->_class]);
			if (empty($options)) {
				if (!empty($this->_options[$this->_plugins->active[$form['plugin']]->_class]))
					unset($this->_options[$this->_plugins->active[$form['plugin']]->_class]);
			}
			else
				$this->_options[$this->_plugins->active[$form['plugin']]->_class] = $options;
			if (empty($this->_options))
				$motor->options->delete("{$this->_class}_options");
			else
				$motor->options->update("{$this->_class}_options", $this->_options);
			echo $motor->tools->ui->alert('Options saved!', 'options-saved', true);
		}
		else
			echo $motor->tools->ui->alert('Options NOT saved!', 'options-saved', true);
	}

	public function _save_site_options() {
		global $motor;
		$not_saved = $motor->tools->ui->alert('Options NOT saved!', 'options-saved', true);
		$options = array();
		parse_str(stripslashes($_POST['form']), $form);
		if (empty($form['plugin']) || empty($form[$form['plugin']])) {
			echo $not_saved;
			return;
		}
		elseif (!empty($this->_plugins->active[$form['plugin']]) && !empty($this->_plugins->active[$form['plugin']]->_site_options))
			$options = $this->_plugins->active[$form['plugin']]->_site_options;
		else {
			foreach ($this->_plugins->active as $active_class => $active_plugin)
				if ($active_plugin->_class === $form['plugin'] && !empty($active_plugin->_site_options)) {
					$options = $active_plugin->_site_options;
					break;
				}
		}
		if (empty($options)) {
			echo $not_saved;
			return;
		}
		$options = $motor->options->set($options, $form[$form['plugin']]);
		if (empty($options))
			$motor->options->delete($form['plugin']);
		else
			$motor->options->update($form['plugin'], $options);
		echo $motor->tools->ui->alert('Options saved!', 'options-saved', true);
	}

	public function _admin_editor($depth = 0) {
		// templates, CSS
		$this->_template_editor();
		$this->_css = new PM_Theme_CSS_Editor($this->_get_css());
		$this->_manager = new PM_Theme_Data_Manager(array(
			'theme' => $this->_class,
			'name' => $this->_name,
			'folder' => $this->_info['folder']));
		return
			$this->admin_editor($depth);
	}

	protected function admin_editor($depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		return
			"$tab<div id=\"theme-html\" class=\"theme-pane\" data-style=\"box\">\n".
			$this->_template_editor->editor($this->_edit_template_data(), $depth + 1).
			"$tab</div>\n".
			"$tab<div id=\"theme-css\" class=\"theme-pane\" data-style=\"box\">\n".
			$this->_css->editor($depth + 1).
			"$tab</div>\n".
			"$tab<div id=\"theme-images\" class=\"theme-pane\" data-style=\"box\">\n".
			$motor->tools->ui->uploader('theme-images', $depth + 1).
			"$tab</div>\n".
			"$tab<div id=\"theme-data\" class=\"theme-pane\" data-style=\"box\">\n".
			$this->_manager->ui($depth + 1).
			"$tab</div>\n".
			"$tab<input type=\"hidden\" id=\"pm-theme\" value=\"$this->_class\">\n";
	}

	protected function _template_editor() {
		$this->_template_editor = new PM_Theme_Template_Editor(
			$this->_core_templates,
			$this->_templates,
			$this->_template_options());
	}

	private function _template_options() {
		$options = array();
		foreach ($this->_plugins->active as $id => $plugin)
			if (!empty($plugin->_template_options) && empty($options[$plugin->_class]))
				$options[$plugin->_class] = $plugin->_template_options;
		return $options;
	}

	protected function _edit_template_data() {
		$template = $this->_get_template(!empty($_POST['template']) ? $_POST['template'] : 'home');
		return array(
			'template' => $template,
			'form' => $this->_box_form_data($template['boxes']));
	}

	protected function _box_form_data($boxes) {
		$form = array(
			'boxes' => array(),
			'active' => array(),
			'add' => array(),
			'roots' => $this->html_document());
		foreach ($this->_plugins->active as $id => $box)
			if (!empty($box->type))
				$form['boxes'][$id] = $box;
		if (is_array($this->_plugins->add))
			foreach ($this->_plugins->add as $class => $box)
				$form['add'][$class] = $box;
		if (is_array($boxes))
			foreach ($boxes as $id => $container) {
				if (!in_array($id, $form['active']))
					$form['active'][] = $id;
				if (is_array($container)) {
					if (isset($form['boxes'][$id]))
						$form['boxes'][$id]->_boxes = $container;
					foreach ($container as $box_id)
						if (!in_array($box_id, $form['active']))
							$form['active'][] = $box_id;
				}
			}
		return $form;
	}

	protected function _change_template() {
		global $motor;
//		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-template');
		$this->_template_editor();
		echo $this->_template_editor->editor($this->_edit_template_data(), 5);
	}

	protected function _create_template() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-template');
		if (empty($_POST['title']))
			return;
		$id = 'custom-'. time();
		$template[$id] = array('title' => $motor->text($_POST['title'], 'escape-html'));
		$this->_templates = array_merge($this->_templates, $template);
		$motor->options->update("{$this->_class}_templates", $this->_templates);
		echo $id;
	}

	protected function _delete_template() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-template');
		if (empty($_POST['template']) || empty($this->_templates[$_POST['template']])) {
			echo $motor->tools->ui->alert('Template not deleted.', 'template-deleted', true);
			return;
		}
		else {
			unset($this->_templates[$_POST['template']]);
			$motor->options->update("{$this->_class}_templates", $this->_templates);
			echo $motor->tools->ui->alert('Template deleted!', 'template-deleted', true);
		}
	}

	protected function _copy_template() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-template');
		if (empty($_POST['to']) || empty($_POST['from']) || empty($this->_templates[$_POST['from']])) {
			echo json_encode(array(
				'status' => 'fail',
				'message' => $motor->tools->ui->alert('Template not copied.', 'template-copied', true)));
			return;
		}
		foreach (array('options', 'boxes') as $data)
			$this->_templates[$_POST['to']][$data] = !empty($this->_templates[$_POST['from']][$data]) ?
				$this->_templates[$_POST['from']][$data] : array();
		$motor->options->update("{$this->_class}_templates", $this->_templates);
		echo json_encode(array(
			'status' => 'ok',
			'message' => 'Template copied!'));
	}

	protected function _save_template() {
		global $motor;
		$this->_template_editor();
		parse_str(stripslashes($_POST['form']), $form);
//		$thesis->wp->nonce($form['_wpnonce-thesis-ajax'], 'thesis-save-template');
		if (!is_array($result = $this->_template_editor->save($form))) {
			echo $motor->tools->ui->alert('Template not saved.', 'template-saved', true);
			return;
		}
		else {
			$motor->options->update("{$this->_class}_templates", $result['templates']);
			$this->_plugins->delete($result['delete_boxes']);
			$this->_save_instances($form);
			echo $motor->tools->ui->alert('Template saved!', 'template-saved', true);
		}
	}

	protected function _save_instance() {
		global $motor;
		parse_str(stripslashes($_POST['form']), $form);
		$this->_save_instances($form);
		echo $motor->tools->ui->alert('Options saved!', 'options-saved', true);
	}

	protected function _save_instances($form) {
		global $motor;
		$instances = $this->_plugins->save($form);
		$motor->options->update("{$this->_class}_instances", $instances);
	}

	protected function _add_box() {
		global $motor;
//		$thesis->wp->nonce($_POST['nonce'], 'thesis-add-box');
		if (!is_array($result = $this->_plugins->add($_POST['id'])) || empty($result['box']))
			return;
		$this->_template_editor();
		echo $this->_template_editor->form->box($result['box'], 10);
		if (!empty($result['instances']))
			$motor->options->update("{$this->_class}_instances", $result['instances']);
	}

	protected function _save_css_variable() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-css-variable');
		$this->_css = new PM_Theme_CSS_Editor($this->_get_css());
		if (is_array($save = $this->_css->vars->save($_POST['var']))) {
			$motor->options->update("{$this->_class}_css_vars", $save['vars']);
			echo json_encode(array(
				'saved' => $motor->tools->ui->alert('Variable saved!', 'css-var-saved', true),
				'var' => $save['var']));
		}
		else
			echo json_encode(array(
				'saved' => $motor->tools->ui->alert('Variable not saved.', 'css-var-saved', true)));
	}

	protected function _edit_css_variable() {
		global $motor;
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-css');
		if (empty($_POST['var']))
			return;
		$this->_css = new PM_Theme_CSS_Editor($this->_get_css());
		$this->_css->vars->edit($_POST['var']);
	}

	protected function _delete_css_variable() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-css-variable');
		$this->_css = new PM_Theme_CSS_Editor($this->_get_css());
		if (is_array($vars = $this->_css->vars->delete($_POST['var']))) {
			$motor->options->update("{$this->_class}_css_vars", $vars);
			echo $motor->tools->ui->alert('Variable deleted!', 'css-var-deleted', true);
		}
		else
			echo $motor->tools->ui->alert('Variable not deleted.', 'css-var-deleted', true);
	}

	protected function _save_css() {
		global $motor;
#		$thesis->wp->check();
#		$thesis->wp->nonce($_POST['nonce'], 'thesis-save-css');
		if (isset($_POST['editors']) && is_array($_POST['editors']))
			foreach ($_POST['editors'] as $type => $editor_css) {
				$type = $type === 'editor' ? "_$type" : '';
				$motor->options->update("{$this->_class}_css$type", trim(stripslashes($editor_css)));
			}
		elseif (isset($_POST['css_custom']))
			$motor->options->update("{$this->_class}_css_custom", trim(stripslashes($_POST['css_custom'])));
		if (!empty($_POST['includes'])) {
			$inactive = $inactive_editor = array();
			parse_str(stripslashes($_POST['includes']), $includes);
			foreach (array('includes', 'includes_editor') as $include)
				$motor->options->update("{$this->_class}_css_$include", $includes[$include]);
		}
		$this->_write_css();
		echo $motor->tools->ui->alert((isset($_POST['css_custom']) ? 'Custom ' : ''). 'CSS saved!', 'css-saved', true);
	}

	public function _write_css() {
		global $motor;
		$this->_css = new PM_Theme_CSS_Editor($css = $this->_get_css());
		if (is_array($map = $this->css_vars()) && is_array($vars = $this->_css->vars->update($map)))
			$motor->options->update("{$this->_class}_css_vars", $vars);
		$theme = strip_tags($this->_css->compile($css['theme'], $css['custom']));
		$editor = strip_tags($this->_css->compile($css['editor'], $css['custom'], true));
		$motor->tools->write(($this->_admin_theme ? PM_ADMIN_THEME : PM_THEME). '/css.css', $theme);
		$motor->tools->write(($this->_admin_theme ? PM_ADMIN_THEME : PM_THEME). '/css-editor.css', $editor);
	}

	protected function _seed() {
		$this->_seed_content();
		if (file_exists(($this->_admin_theme ? PM_ADMIN_THEME : PM_THEME). '/seed.php')) {
			include_once(($this->_admin_theme ? PM_ADMIN_THEME : PM_THEME). '/seed.php');
			$seed = $this->_class. '_seed';
			$this->_seed = new $seed;
			$this->_seed_data();
		}
	}

	protected function _seed_content() {
		global $motor;
		if ($motor->options->option($this->_seed_content))
			return;
		// Home: Add content to DB and then set admin_home option to the ID that was just inserted
		$home = $motor->content->get_where(array('type' => 'home'));
		if (empty($home)) {
			$motor->content->update(array_merge($motor->seed->content['home'], array('date_gmt' => gmdate($motor->db->date_format))));
			$motor->options->update($motor->page->home, $motor->db->connection->insert_id);
		}
		$error = $motor->content->get_where(array('type' => 'error'));
		if (empty($error))
			$motor->content->update(array_merge($motor->seed->content['error'], array('date_gmt' => gmdate($motor->db->date_format))));
		// Set the seed option to true once content is seeded
		$motor->options->update($this->_seed_content, 1);
	}

	protected function _seed_data() {
		global $motor;
		if ($motor->options->option("{$this->_class}_$this->_seed_data") || empty($this->_seed))
			return;
		// Templates, instances, CSS vars, CSS, CSS editor, design, display
		if (!$motor->options->exists("{$this->_class}_templates") && method_exists($this->_seed, 'templates'))
			$motor->options->update("{$this->_class}_templates", $this->_seed->templates());
		if (!$motor->options->exists("{$this->_class}_instances") && method_exists($this->_seed, 'instances'))
			$motor->options->update("{$this->_class}_instances", $this->_seed->instances());
		if (!$motor->options->exists("{$this->_class}_css_vars") && method_exists($this->_seed, 'css_vars'))
			$motor->options->update("{$this->_class}_css_vars", $this->_seed->css_vars());
		if (!$motor->options->exists("{$this->_class}_css") && method_exists($this->_seed, 'css'))
			$motor->options->update("{$this->_class}_css", $this->_seed->css());
		if (!$motor->options->exists("{$this->_class}_css_editor") && method_exists($this->_seed, 'css_editor'))
			$motor->options->update("{$this->_class}_css_editor", $this->_seed->css_editor());
		if (!$motor->options->exists("{$this->_class}_design") && method_exists($this->_seed, 'design'))
			$motor->options->update("{$this->_class}_design", $this->_seed->design());
		if (!$motor->options->exists("{$this->_class}_display") && method_exists($this->_seed, 'display'))
			$motor->options->update("{$this->_class}_display", $this->_seed->display());
		$motor->options->update("{$this->_class}_$this->_seed_data", 1);
	}

	public function _generate_seed() {
		global $motor;
		$seed =
			"<?php\n".
			"class {$this->_class}_seed {\n".
			"\tpublic function templates() {\n".
			"\t\treturn ". var_export($motor->options->option("{$this->_class}_templates", array()), true). ";\n".
			"\t}\n\n".
			"\tpublic function instances() {\n".
			"\t\treturn ". var_export($motor->options->option("{$this->_class}_instances", array()), true). ";\n".
			"\t}\n\n".
			"\tpublic function css_vars() {\n".
			"\t\treturn ". var_export($motor->options->option("{$this->_class}_css_vars", array()), true). ";\n".
			"\t}\n\n".
			"\tpublic function css() {\n".
			"\t\treturn ". var_export($motor->options->option("{$this->_class}_css"), true). ";\n".
			"\t}\n\n".
			"\tpublic function css_editor() {\n".
			"\t\treturn ". var_export($motor->options->option("{$this->_class}_css_editor"), true). ";\n".
			"\t}\n\n".
			"\tpublic function design() {\n".
			"\t\treturn ". var_export($motor->options->option("{$this->_class}_design", array()), true). ";\n".
			"\t}\n\n".
			"\tpublic function display() {\n".
			"\t\treturn ". var_export($motor->options->option("{$this->_class}_display", array()), true). ";\n".
			"\t}\n".
			"}\n";
		$motor->tools->write(($this->_admin_theme ? PM_ADMIN_THEME : PM_THEME). '/seed.php', $seed);
	}

/*
	Core PageMotor JS files available for deployment
*/
	public $_registered_js = array(
		'jquery' => array(
			'url' => 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js',
			'preconnect' => array(
				'cdnjs' => 'https://cdnjs.cloudflare.com')),
		'jquery-ui' => array(
			'url' => 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.14.1/jquery-ui.min.js',
			'requires' => array('jquery')),
		// jQuery 3.1.1 required for optimal template editor performance
		'jquery-3-1-1' => array(
			'url' => 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js',
			'preconnect' => array(
				'cdnjs' => 'https://cdnjs.cloudflare.com')),
		// jQuery UI 1.12.1 required for optimal template editor performance
		'jquery-ui-1-12-1' => array(
			'url' => 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js',
			'requires' => array('jquery-3-1-1')),
		'pm-login' => array(
			'url' => PM_JS_URL. '/pm-login.js'),
		'pm-options' => array(
			'url' => PM_JS_URL. '/pm-options.js'),
		'pm-options-save' => array(
			'url' => PM_JS_URL. '/pm-options-save.js'),
		'pm-components' => array(
			'url' => PM_JS_URL. '/pm-components.js'),
		'tinymce' => array(
			'url' => PM_RTE_URL. '/tinymce.min.js'),
		'content-manager' => array(
			'url' => PM_JS_URL. '/content-manager.js'),
		'content-editor' => array(
			'url' => PM_JS_URL. '/content-editor.js'),
		'codemirror' => array(
			'url' => PM_JS_URL. '/codemirror.js'),
		'js-color' => array(
			'url' => PM_JS_URL. '/jscolor/jscolor.js'),
		'theme-editor' => array(
			'url' => PM_JS_URL. '/theme-editor.js'),
		'template-ui' => array(
			'url' => PM_JS_URL. '/template-ui.js',
			'requires' => array('jquery-ui-1-12-1')),
		'theme-templates' => array(
			'url' => PM_JS_URL. '/theme-templates.js',
			'requires' => array('template-ui')),
		'theme-css' => array(
			'url' => PM_JS_URL. '/theme-css.js',
			'requires' => array('jquery-ui-1-12-1')),
		'theme-data' => array(
			'url' => PM_JS_URL. '/theme-data.js'),
			'requires' => array('theme-editor', 'template-ui'));
}