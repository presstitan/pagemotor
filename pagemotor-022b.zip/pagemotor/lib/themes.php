<?php
/**
 * PageMotor Theme Manager
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Themes
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Themes {
	public $installed = array();					// [array] installed Themes
	public $theme = 'theme';						// [string] front end Theme option reference
	public $theme_preview = 'theme_preview';		// [string] Theme preview option reference
	public $is_preview = false;						// [bool] Theme Preview?
	public $theme_folder = 'attention';				// [string] default Theme folder name
	public $theme_class = 'PM_Attention';			// [string] Theme class name
	public $admin = 'admin_theme';					// [string] admin Theme option reference
	public $admin_preview = 'admin_theme_preview';	// [string] admin Theme preview option reference
	public $is_admin_preview = false;				// [bool] Admin Theme Preview?
	public $admin_folder = 'admin-architect';		// [string] default admin Theme folder name
	public $admin_class = 'PM_Admin_Architect';		// [string] admin Theme class name
	public $master = 'master';						// [string] master control file name
	public $custom = 'custom';						// [string] custom Theme control file name
	public $pm_theme_class = 'PM_Theme';			// [string] Master PageMotor Theme class
	public $pm_admin_class = 'PM_Admin';			// [string] Master PageMotor Admin class
	public $updates = array();						// [array] Theme update notifications

	public function __construct() {
		global $motor;
		// Dirs
		define('PM_CORE_THEMES', PM_LIB. '/themes');
		define('PM_USER_THEMES', PM_USER_CONTENT. '/themes');
		// URLs
		define('PM_USER_THEMES_URL', PM_USER_CONTENT_URL. '/themes');
		// Include master.php file
		if (file_exists(PM_USER_CONTENT. "/$this->master.php"))
			include_once(PM_USER_CONTENT. "/$this->master.php");
		$this->install_default($this->admin_folder);
		$this->install_default($this->theme_folder);
		$this->installed = $motor->tools->files->info(PM_USER_THEMES);
	}

	public function theme() {
		global $motor;
		// Front End Theme must be loaded on every request
		// Is this a Preview Theme, and does it exist on the server?
		if (($theme_preview = $motor->options->option($this->theme_preview))
		&& !empty($this->installed[$theme_preview])
		&& !empty($this->installed[$theme_preview]['folder'])
		&& file_exists($theme_file = PM_USER_THEMES. "/{$this->installed[$theme_preview]['folder']}/theme.php")) {
			$this->theme_class = $theme_preview;
			$this->is_preview = true;
		}
		// Is this a regular Theme, and does it exist on the server?
		elseif (($theme = $motor->options->option($this->theme))
			&& !empty($this->installed[$theme])
			&& !empty($this->installed[$theme]['folder'])
			&& file_exists($theme_file = PM_USER_THEMES. "/{$this->installed[$theme]['folder']}/theme.php"))
				$this->theme_class = $theme;
		// If the above conditions fail, use the default Theme instead
		elseif (!empty($this->installed[$this->theme_class])
			&& !empty($this->installed[$this->theme_class]['folder'])
			&& file_exists($theme_file = PM_USER_THEMES. "/{$this->installed[$this->theme_class]['folder']}/theme.php"))
				$motor->options->update($this->theme, $this->theme_class);
		// If everything above failed, PageMotor was not able to install its Themes correctly
		else
			new PM_Error('PageMotor Theme is not installed properly!');
		// Dirs
		define('PM_THEME', PM_USER_THEMES. "/{$this->installed[$this->theme_class]['folder']}");
		define('PM_THEME_IMAGES', PM_THEME. '/images');
		// URLs
		define('PM_THEME_URL', PM_USER_THEMES_URL. "/{$this->installed[$this->theme_class]['folder']}");
		define('PM_THEME_IMAGES_URL', PM_USER_THEMES_URL. "/{$this->installed[$this->theme_class]['folder']}/images");
		require_once($theme_file);
		if (file_exists(PM_THEME. "/$this->custom.php"))
			include_once(PM_THEME. "/$this->custom.php");
		if (!class_exists($this->theme_class))
			new PM_Error("The selected PageMotor Theme class ($this->theme_class) does not exist!");
		elseif (!is_subclass_of($this->theme_class, $this->pm_theme_class))
			new PM_Error("The selected PageMotor Theme is not an extension of the main PageMotor Theme class ($this->pm_theme_class)!");
		else
			return new $this->theme_class($this->installed[$this->theme_class]);
	}

	public function admin_theme() {
		global $motor;
		// Is this a Preview Theme, and does it exist on the server?
		if (($admin_preview = $motor->options->option($this->admin_preview))
		&& !empty($this->installed[$admin_preview])
		&& !empty($this->installed[$admin_preview]['folder'])
		&& file_exists($admin_file = PM_USER_THEMES. "/{$this->installed[$admin_preview]['folder']}/theme.php")) {
			// need user_is_admin() provision
			$this->admin_class = $admin_preview;
			$this->is_admin_preview = true;
		}
		// Is this a regular Theme, and does it exist on the server?
		elseif (($admin_theme = $motor->options->option($this->admin))
			&& !empty($this->installed[$admin_theme])
			&& !empty($this->installed[$admin_theme]['folder'])
			&& file_exists(($admin_file = PM_USER_THEMES. "/{$this->installed[$admin_theme]['folder']}/theme.php")))
				$this->admin_class = $admin_theme;
		// If the above conditions fail, use the default Theme instead
		elseif (!empty($this->installed[$this->admin_class])
			&& !empty($this->installed[$this->admin_class]['folder'])
			&& file_exists($admin_file = PM_USER_THEMES. "/{$this->installed[$this->admin_class]['folder']}/theme.php"))
				$motor->options->update($this->admin, $this->admin_class);
		// If everything above failed, PageMotor was not able to install its Themes correctly
		else
			new PM_Error('PageMotor Admin Theme is not installed properly!');
		// Dirs
		define('PM_ADMIN_THEME', PM_USER_THEMES. "/{$this->installed[$this->admin_class]['folder']}");
		define('PM_ADMIN_THEME_IMAGES', PM_ADMIN_THEME. '/images');
		// URLs
		define('PM_ADMIN_THEME_URL', PM_USER_THEMES_URL. "/{$this->installed[$this->admin_class]['folder']}");
		define('PM_ADMIN_THEME_IMAGES_URL', PM_USER_THEMES_URL. "/{$this->installed[$this->admin_class]['folder']}/images");
		require_once($admin_file);
		if (file_exists(PM_ADMIN_THEME. "/$this->custom.php"))
			include_once(PM_ADMIN_THEME. "/$this->custom.php");
		if (!class_exists($this->admin_class))
			new PM_Error("The selected PageMotor Admin Theme class ($this->admin_class) does not exist!");
		elseif (!is_subclass_of($this->admin_class, $this->pm_theme_class))
			new PM_Error("The selected PageMotor Admin Theme is not an extension of the main PageMotor Theme class ($this->pm_theme_class)!");
		else
			return new $this->admin_class($this->installed[$this->admin_class]);
	}

	private function install_default($folder) {
		global $motor;
		if (!is_dir(PM_USER_THEMES. "/$folder") || !@file_exists(PM_USER_THEMES. "/$folder/theme.php"))
			if (is_dir(PM_CORE_THEMES. "/$folder") && !$motor->tools->files->copy_dir(PM_CORE_THEMES. "/$folder", PM_USER_THEMES. "/$folder"))
				new PM_Error("PageMotor could not install the default $folder Theme properly.");
	}

	public function admin($admin = false, $depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$active = $admin ? $this->admin_class : $this->theme_class;
		$current = $preview = $installed = $current_updates = $installed_updates = '';
		if (is_array($this->installed) && !empty($this->installed))
			foreach ($this->installed as $class => $theme)
				if ((($admin && $this->is_admin_preview) || (!$admin && $this->is_preview)) && $class == $active)
					$preview = $this->theme_info($theme, false, true, $this->updates, $depth + 1);
				elseif ($class == $active)
					$current = $this->theme_info($theme, true, false, $this->updates, $depth + 1);
				elseif ((!$admin && (empty($theme['type']) || strtolower($theme['type']) !== 'admin'))
				|| ($admin && !empty($theme['type']) && strtolower($theme['type']) == 'admin'))
					$installed .= $this->theme_info($theme, false, false, $this->updates, $depth);
		if (isset($this->updates[$active])) {
			$current_updates = ' <span class="pm-updates" title="An update is available for your current'. ($admin ? ' Admin' : ''). ' Theme">1</span>';
			unset($this->updates[$active]);
		}
		if (!empty($this->updates))
			$installed_updates = ' <span class="pm-updates" title="Updates are available for your installed'. ($admin ? ' Admin' : ''). ' Themes">'. count($this->updates). '</span>';
		$upload =
			"$tab\t\t<button id=\"theme-upload\" class=\"action\">\n".
			$motor->tools->svg->icon('upload', $depth + 3).
			"$tab\t\t\tUpload a New". ($admin ? ' Admin' : ''). " Theme\n".
			"$tab\t\t</button>\n";
		return // Begin status messaging system
/*			(!empty($_GET['changed']) && $_GET['changed'] == 'true' ?
			$thesis->api->alert('Success! You just changed your Theme.', false, false, $depth) :
			(!empty($_GET['preview']) && $_GET['preview'] == 'true' ?
			$thesis->api->alert('You are now previewing a Theme in development mode. As an administrator, you can edit the Preview Theme, but visitors to your site will continue to see the Current Theme.', false, false, $depth) :
			(!empty($_GET['stopped']) && $_GET['stopped'] == 'true' ?
			$thesis->api->alert('You are no longer previewing a Theme in development mode.', false, false, $depth) :
			!empty($_GET['deleted']) && ($_GET['deleted'] == 'true' ?
			$thesis->api->alert('Theme deleted.', false, false, $depth) :
			(!empty($preview) ?
			$thesis->api->alert('You are currently previewing a Theme in development mode. Visitors to your site will still see the Current Theme shown below, and you can develop the Preview Theme without fear of messing up your site for existing visitors!', 'warning', false, $depth) : ''))))).*/
			// Begin the actual Theme management UI
			(!empty($preview) ?
			"$tab<div class=\"active-theme preview-theme\">\n".
			"$tab\t<div class=\"pm-ui-title-controls\">\n".
			"$tab\t\t<h2 id=\"preview-theme\">Preview". ($admin ? ' Admin' : ''). " Theme</h2>\n".
			$upload.
			"$tab\t</div>\n".
			$preview.
			"$tab</div>\n" : '').
			"$tab<div class=\"active-theme\">\n".
			"$tab\t<div class=\"pm-ui-title-controls\">\n".
			"$tab\t\t<h2 id=\"current-theme\">Current". ($admin ? ' Admin' : ''). " Theme$current_updates</h2>\n".
			(empty($preview) ?
			$upload : '').
			"$tab\t</div>\n".
			$current.
			"$tab</div>\n".
			"$tab<h2 id=\"installed-themes\">Inactive". ($admin ? ' Admin' : ''). " Themes$installed_updates</h2>\n".
			$installed.
			$motor->tools->ui->popup(array(
				'id' => 'theme-uploader',
				'title' => 'Upload'. ($admin ? ' an Admin' : ' a'). ' Theme',
				'body' => $motor->tools->ui->uploader('theme-uploader', $depth + 3),
				'depth' => $depth));
	}

	public static function theme_info($theme, $active = false, $preview = false, $updates = array(), $depth = 0) {
		global $motor;
		if (empty($theme) || !is_array($theme))
			return;
		$tab = str_repeat("\t", $depth);
		$name = $motor->text(!empty($theme['name']) ? $theme['name'] : 'Unidentified Theme (no name)', 'no-html');
		$screenshot =
			file_exists(PM_USER_THEMES. "/{$theme['folder']}/screenshot.png") ?
				PM_USER_THEMES_URL. "/{$theme['folder']}/screenshot.png" :
			(file_exists(PM_USER_THEMES. "/{$theme['folder']}/screenshot.jpg") ?
				PM_USER_THEMES_URL. "/{$theme['folder']}/screenshot.jpg" : false);
		$zip = ($active || $preview) && apply_filters('pm-theme-create-zip', false) ?
			"<a data-style=\"button action\" href=\"". $motor->admin_url("update.php?action=thesis_generate_skin&skin=". $motor->text($theme['class'])). "\"><span data-style=\"dashicon\">&#xf316;</span> Create Zip File</a>" : false;
		$update = !empty($updates) && !empty($updates[$class]) && !empty($updates[$class]['version']) && !empty($theme['version'])
		&& version_compare($updates[$class]['version'], $theme['version'], '>') ?
			"$tab\t\t<p><a onclick=\"if(!pm_update_themes()) return false;\" class=\"button update\" href=\"". $motor->admin_url('update.php?action=thesis_update_objects&type=skin&class='. $motor->text($theme['class']). '&folder='. $motor->text($theme['folder']). '&version='. $motor->text($updates[$class]['version']). '&name='. urlencode($name)). "\">\n".
			$motor->tools->svg->icon('refresh-cw', $depth + 3).
			"$tab\t\t\tUpdate $name\n".
			"$tab\t\t</a></p>\n" : '';
		$version = '<span class="theme-version">'. (!empty($theme['version']) ? 'v '. (!empty($theme['changelog']) ?
			'<a href="'. $motor->url_escape($theme['changelog']). '" target="_blank" rel="noopener">'. $motor->text($theme['version'], 'inline-no-links'). '</a>' :
			$motor->text($theme['version'], 'inline-no-links')) : 'Theme needs a version number!'). '</span>';
		return
			"$tab<div id=\"theme-". $motor->text($theme['class']). "\" class=\"theme-info\">\n".
			"$tab\t<form method=\"post\" action=\"". $_SERVER['REQUEST_URI']. "\">\n".
			(!empty($screenshot) ?
			"$tab\t\t<img class=\"theme-screenshot\" src=\"$screenshot\" alt=\"$name screenshot\" width=\"300\" height=\"225\" />\n" : '').
			"$tab\t\t<h3>$name {$theme['version']}\n".
			"$tab\t\t\t<span class=\"theme-by\">by</span> <span class=\"theme-author\">". $motor->text($theme['author'], 'no-html'). "</span>\n".
			(!empty($theme['docs']) ?
			"$tab\t\t\t<a href=\"". $motor->url_escape($theme['docs']). "\" title=\"See Theme Documentation\" target=\"_blank\" rel=\"noopener\">\n".
			$motor->tools->svg->icon('info', $depth + 4).
			"$tab\t\t\t</a>\n" : '').
			"$tab\t\t</h3>\n".
			(!empty($update) ?
			$update : '').
			(!empty($theme['description']) ?
			"$tab\t\t<p>". $motor->text($theme['description'], 'inline'). "</p>\n" : '').
			(($preview || !($active || $preview)) ?
			"$tab\t\t<p>\n". (!($active || $preview) ?
			"$tab\t\t\t<button class=\"action\" name=\"preview_theme\" value=\"1\">\n".
			$motor->tools->svg->icon('eye', $depth + 4).
			"$tab\t\t\t\tPreview Theme\n".
			"$tab\t\t\t</button>\n" : ($preview ?
			"$tab\t\t\t<button class=\"action\" name=\"stop_preview\" value=\"1\">\n".
			$motor->tools->svg->icon('slash', $depth + 4).
			"$tab\t\t\t\tStop Previewing Theme\n".
			"$tab\t\t\t</button>\n" : '')).
			"$tab\t\t</p>\n" : '').
			(!$active ?
			"$tab\t\t<p>\n".
			"$tab\t\t\t<input type=\"hidden\" name=\"theme\" value=\"". $motor->text($theme['class']). "\" />\n".
			(!$preview ?
			"$tab\t\t\t<button class=\"delete\" class=\"theme-delete\" data-class=\"". $motor->text($theme['class']). "\" data-name=\"$name\">\n".
			$motor->tools->svg->icon('delete', $depth + 4).
			"$tab\t\t\t\tDelete Theme\n".
			"$tab\t\t\t</button>\n" : '').
			"$tab\t\t\t<button class=\"save\" name=\"activate_theme\" value=\"1\">\n".
			$motor->tools->svg->icon('check', $depth + 4).
			"$tab\t\t\t\tActivate Theme\n".
			"$tab\t\t\t</button>\n".
			"$tab\t\t</p>\n" : '').
			(!empty($zip) ?
			"$tab\t\t<p>$zip</p>\n" : '').
#			"$tab\t\t". wp_nonce_field('thesis-skins', '_wpnonce-thesis-skins', true, false). "\n".
			"$tab\t</form>\n".
			"$tab</div>\n";
	}
}