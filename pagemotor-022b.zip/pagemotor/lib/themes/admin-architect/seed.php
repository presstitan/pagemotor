<?php
class PM_Admin_Architect_seed {
	public function templates() {
		return array (
  'home' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Home',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'page' => 
  array (
    'options' => 
    array (
      'HTML_Body' => 
      array (
        'class' => 'focus',
      ),
    ),
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Page_Container_1739730012',
      ),
      'Page_Container_1739730012' => 
      array (
        0 => 'HTML_Container_1739730303',
        1 => 'Page_Container_1739730012_Page_Content',
      ),
      'HTML_Container_1739730303' => 
      array (
        0 => 'Page_Container_1739730012_Page_Title',
        1 => 'HTML_Container_1739730358',
      ),
      'HTML_Container_1739730358' => 
      array (
        0 => 'Page_Container_1739730012_Page_Author',
        1 => 'Page_Container_1739730012_Page_Date',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-content' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Content_Editor',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-plugins' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Components',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-themes' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Components',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-theme' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Theme',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-theme-editor' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729400',
        2 => 'HTML_Container_1739729450',
        3 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729400' => 
      array (
        0 => 'HTML_Container_1739729756',
      ),
      'HTML_Container_1739729756' => 
      array (
        0 => 'Admin_UI_Theme_Editor_Tabs',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Theme_Editor',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-theme-css' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Theme_Custom_CSS',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-theme-elements' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Theme_Elements',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-theme-design' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Theme_Design',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'error' => 
  array (
    'options' => 
    array (
      'HTML_Body' => 
      array (
        'class' => 'focus',
      ),
    ),
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Page_Container_1739730012',
      ),
      'Page_Container_1739730012' => 
      array (
        0 => 'HTML_Container_1739730303',
        1 => 'Page_Container_1739730012_Page_Content',
      ),
      'HTML_Container_1739730303' => 
      array (
        0 => 'Page_Container_1739730012_Page_Title',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
  'admin-settings' => 
  array (
    'boxes' => 
    array (
      'HTML_Head' => 
      array (
        0 => 'HTML_Head_Stylesheets',
        1 => 'HTML_Head_Favicon',
        2 => 'HTML_Head_Canonical_URL',
        3 => 'HTML_Head_Meta_Robots',
        4 => 'HTML_Head_Title_Tag',
        5 => 'HTML_Head_Meta_Description',
      ),
      'HTML_Body' => 
      array (
        0 => 'HTML_Container_1739729317',
        1 => 'HTML_Container_1739729450',
        2 => 'HTML_Container_1739729454',
      ),
      'HTML_Container_1739729317' => 
      array (
        0 => 'HTML_Container_1739729583',
      ),
      'HTML_Container_1739729583' => 
      array (
        0 => 'HTML_Container_1748105658',
      ),
      'HTML_Container_1748105658' => 
      array (
        0 => 'Admin_Breadcrumbs',
        1 => 'Admin_View_Site',
      ),
      'HTML_Container_1739729450' => 
      array (
        0 => 'HTML_Container_1739729835',
      ),
      'HTML_Container_1739729835' => 
      array (
        0 => 'HTML_Container_1739729929',
      ),
      'HTML_Container_1739729929' => 
      array (
        0 => 'Admin_UI_Settings',
      ),
      'HTML_Container_1739729454' => 
      array (
        0 => 'HTML_Container_1739730162',
      ),
      'HTML_Container_1739730162' => 
      array (
        0 => 'Admin_Footer',
      ),
    ),
  ),
);
	}

	public function instances() {
		return array (
  'Stylesheets' => 
  array (
    'HTML_Head_Stylesheets' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'Title_Tag' => 
  array (
    'HTML_Head_Title_Tag' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'Meta_Description' => 
  array (
    'HTML_Head_Meta_Description' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'Meta_Robots' => 
  array (
    'HTML_Head_Meta_Robots' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'Link_Canonical' => 
  array (
    'HTML_Head_Canonical_URL' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'Favicon' => 
  array (
    'HTML_Head_Favicon' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'HTML_Container' => 
  array (
    'HTML_Container_1739729317' => 
    array (
      '_id' => 'section_header',
      'tag' => 'div',
      'id' => 'header',
      '_name' => 'Section: Header',
    ),
    'HTML_Container_1739729400' => 
    array (
      '_id' => 'section_nav',
      'tag' => 'div',
      'id' => 'nav',
      '_name' => 'Section: Nav',
    ),
    'HTML_Container_1739729450' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      '_id' => 'section_content',
      'tag' => 'div',
      'id' => 'content',
      '_name' => 'Section: Content',
    ),
    'HTML_Container_1739729454' => 
    array (
      '_id' => 'section_footer',
      'tag' => 'div',
      'id' => 'footer',
      '_name' => 'Section: Footer',
    ),
    'HTML_Container_1739729583' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      '_id' => 'header',
      'tag' => 'div',
      'class' => 'container',
      '_name' => 'Container: Header',
    ),
    'HTML_Container_1739729756' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      '_id' => 'nav',
      'tag' => 'div',
      'class' => 'container',
      '_name' => 'Container: Nav',
    ),
    'HTML_Container_1739729835' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      '_id' => 'columns',
      'tag' => 'div',
      'class' => 'container',
      '_name' => 'Container: Columns',
    ),
    'HTML_Container_1739729929' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      '_id' => 'content',
      'tag' => 'div',
      'class' => 'content grt',
      '_name' => 'Content',
    ),
    'HTML_Container_1739730303' => 
    array (
      '_id' => 'headline_area',
      'tag' => 'div',
      'class' => 'headline_area',
      '_name' => 'Headline Area',
    ),
    'HTML_Container_1739730358' => 
    array (
      '_id' => 'byline_page',
      'tag' => 'div',
      'class' => 'byline',
      '_name' => 'Byline: Page',
    ),
    'HTML_Container_1739730162' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      '_id' => 'footer',
      'tag' => 'div',
      'class' => 'container',
      '_name' => 'Container: Footer',
    ),
    'HTML_Container_1748105658' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      'tag' => 'div',
      'class' => 'pm-ui-flex pm-ui-flex-lr',
      '_name' => 'Flex: Left/Right',
    ),
  ),
  'Text_Box' => 
  array (
  ),
  'Page_Container' => 
  array (
    'Page_Container_1739730012' => 
    array (
      '_admin' => 
      array (
        'open' => true,
      ),
      '_id' => 'page',
      'tag' => 'div',
      'class' => 'text',
      '_name' => 'Page Container: Page',
    ),
  ),
  'Page_Title' => 
  array (
    'Page_Container_1739730012_Page_Title' => 
    array (
      '_id' => 'page',
      'tag' => 'h1',
      '_parent' => 'Page_Container_1739730012',
    ),
  ),
  'Page_Content' => 
  array (
    'Page_Container_1739730012_Page_Content' => 
    array (
      '_id' => 'page',
      '_parent' => 'Page_Container_1739730012',
    ),
  ),
  'Page_Author' => 
  array (
    'Page_Container_1739730012_Page_Author' => 
    array (
      '_id' => 'page',
      'intro' => 'Author:',
      '_parent' => 'Page_Container_1739730012',
    ),
  ),
  'Page_Date' => 
  array (
    'Page_Container_1739730012_Page_Date' => 
    array (
      '_id' => 'page',
      'format' => 'F j, Y',
      'intro' => 'Published:',
      'modified' => 'Updated:',
      '_parent' => 'Page_Container_1739730012',
    ),
  ),
  'PG_Google_Analytics' => 
  array (
    'HTML_Head_PG_Google_Analytics' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'PM_Google_Analytics' => 
  array (
    'HTML_Head_PM_Google_Analytics' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
  'Canonical_URL' => 
  array (
    'HTML_Head_Canonical_URL' => 
    array (
      '_parent' => 'HTML_Head',
    ),
  ),
);
	}

	public function css_vars() {
		return array (
  'var-1362696253' => 
  array (
    'name' => 'Width: Content',
    'ref' => 'w-content',
    'css' => '644px',
  ),
  'var-1362697011' => 
  array (
    'name' => 'Width: Total',
    'ref' => 'w-total',
    'css' => '1040px',
  ),
  'var-1515536162' => 
  array (
    'name' => 'Font Size 1',
    'ref' => 'f1',
    'css' => '47px',
  ),
  'var-1515536178' => 
  array (
    'name' => 'Font Size 2',
    'ref' => 'f2',
    'css' => '37px',
  ),
  'var-1515536186' => 
  array (
    'name' => 'Font Size 3',
    'ref' => 'f3',
    'css' => '29px',
  ),
  'var-1515536193' => 
  array (
    'name' => 'Font Size 4',
    'ref' => 'f4',
    'css' => '23px',
  ),
  'var-1515536200' => 
  array (
    'name' => 'Font Size 5',
    'ref' => 'f5',
    'css' => '18px',
  ),
  'var-1515536208' => 
  array (
    'name' => 'Font Size 6',
    'ref' => 'f6',
    'css' => '14px',
  ),
  'var-1515536227' => 
  array (
    'name' => 'Line Height 1',
    'ref' => 'g1',
    'css' => '73px',
  ),
  'var-1515536236' => 
  array (
    'name' => 'Line Height 2',
    'ref' => 'g2',
    'css' => '58px',
  ),
  'var-1515536242' => 
  array (
    'name' => 'Line Height 3',
    'ref' => 'g3',
    'css' => '47px',
  ),
  'var-1515536248' => 
  array (
    'name' => 'Line Height 4',
    'ref' => 'g4',
    'css' => '38px',
  ),
  'var-1515536253' => 
  array (
    'name' => 'Line Height 5',
    'ref' => 'g5',
    'css' => '31px',
  ),
  'var-1515536258' => 
  array (
    'name' => 'Line Height 6',
    'ref' => 'g6',
    'css' => '25px',
  ),
  'var-1516396754' => 
  array (
    'name' => 'Text Color: Links',
    'ref' => 'ca',
    'css' => '#DE0404',
  ),
  'var-1516396804' => 
  array (
    'name' => 'Font 1',
    'ref' => 'font1',
    'css' => '"IBM Plex Sans", sans-serif',
  ),
  'var-1516396813' => 
  array (
    'name' => 'Font 2',
    'ref' => 'font2',
    'css' => '"IBM Plex Serif", serif',
  ),
  'var-1516402312' => 
  array (
    'name' => 'Color: Site Title',
    'ref' => '_c-title',
    'css' => false,
  ),
  'var-1516402326' => 
  array (
    'name' => 'Color: H1',
    'ref' => '_c-h1',
    'css' => '$ct1',
  ),
  'var-1516402356' => 
  array (
    'name' => 'Color: Blockquote',
    'ref' => '_c-blockquote',
    'css' => false,
  ),
  'var-1516402366' => 
  array (
    'name' => 'Color: Code',
    'ref' => '_c-code',
    'css' => false,
  ),
  'var-1516402450' => 
  array (
    'name' => 'Font: Nav Menu',
    'ref' => '_font-menu',
    'css' => false,
  ),
  'var-1516402459' => 
  array (
    'name' => 'Font: Site Title',
    'ref' => '_font-title',
    'css' => false,
  ),
  'var-1516402487' => 
  array (
    'name' => 'Font: Heading',
    'ref' => '_font-heading',
    'css' => false,
  ),
  'var-1516402499' => 
  array (
    'name' => 'Font: Headline',
    'ref' => '_font-headline',
    'css' => false,
  ),
  'var-1516403672' => 
  array (
    'name' => 'Font: Blockquote',
    'ref' => '_font-blockquote',
    'css' => false,
  ),
  'var-1516403803' => 
  array (
    'name' => 'Font: Code',
    'ref' => 'font-code',
    'css' => '"IBM Plex Mono", serif',
  ),
  'var-1516461409' => 
  array (
    'name' => 'Background Color: Pre',
    'ref' => '_bg-pre',
    'css' => '#EDF1FF',
  ),
  'var-1516465121' => 
  array (
    'name' => 'Background Color: Header',
    'ref' => '_bg-header',
    'css' => false,
  ),
  'var-1516465136' => 
  array (
    'name' => 'Background Color: Content Section',
    'ref' => '_bg-content',
    'css' => false,
  ),
  'var-1516465147' => 
  array (
    'name' => 'Background Color: Footer',
    'ref' => '_bg-footer',
    'css' => false,
  ),
  'var-1516740437' => 
  array (
    'name' => 'Font Size: Nav Menu',
    'ref' => '_f-menu',
    'css' => false,
  ),
  'var-1516740495' => 
  array (
    'name' => 'Line Height: Nav Menu',
    'ref' => '_g-menu',
    'css' => false,
  ),
  'var-1535672413' => 
  array (
    'name' => 'Spacing Size 1',
    'ref' => 'x1',
    'css' => '50px',
  ),
  'var-1535672439' => 
  array (
    'name' => 'Spacing Size 2',
    'ref' => 'x2',
    'css' => '31px',
  ),
  'var-1535672448' => 
  array (
    'name' => 'Spacing Size 3',
    'ref' => 'x3',
    'css' => '19px',
  ),
  'var-1535672471' => 
  array (
    'name' => 'Spacing Size 4',
    'ref' => 'x4',
    'css' => '12px',
  ),
  'var-1535672478' => 
  array (
    'name' => 'Spacing Size 5',
    'ref' => 'x5',
    'css' => '7px',
  ),
  'var-1535672485' => 
  array (
    'name' => 'Spacing Size 6',
    'ref' => 'x6',
    'css' => '4px',
  ),
  'var-1535730145' => 
  array (
    'name' => 'Background Color: Note Callout',
    'ref' => '_bg-callout-note',
    'css' => '#CCF1FF',
  ),
  'var-1535730153' => 
  array (
    'name' => 'Background Color: Alert Callout',
    'ref' => '_bg-callout-alert',
    'css' => '#FFE91F',
  ),
  'var-1535730161' => 
  array (
    'name' => 'Background Color: Callout',
    'ref' => '_bg-callout',
    'css' => '#CCE8CC',
  ),
  'var-1535752739' => 
  array (
    'name' => 'Background Color: Button',
    'ref' => '_bg-button',
    'css' => '#EBDCC8',
  ),
  'var-1535752757' => 
  array (
    'name' => 'Background Color: Button (Save)',
    'ref' => '_bg-button-save',
    'css' => '#509B26',
  ),
  'var-1535752950' => 
  array (
    'name' => 'Background Color: Button (Delete)',
    'ref' => '_bg-button-delete',
    'css' => '#D50B0B',
  ),
  'var-1535752963' => 
  array (
    'name' => 'Background Color: Button (Action)',
    'ref' => '_bg-button-action',
    'css' => '#12A7FF',
  ),
  'var-1535752977' => 
  array (
    'name' => 'Background Color: Button (Update)',
    'ref' => '_bg-button-update',
    'css' => '#FCFC0D',
  ),
  'var-1535813410' => 
  array (
    'name' => 'Color: Button',
    'ref' => '_c-button',
    'css' => '#111111',
  ),
  'var-1535813434' => 
  array (
    'name' => 'Color: Button (Save)',
    'ref' => '_c-button-save',
    'css' => '#FFFFFF',
  ),
  'var-1535813450' => 
  array (
    'name' => 'Color: Button (Delete)',
    'ref' => '_c-button-delete',
    'css' => '#FFFFFF',
  ),
  'var-1535813461' => 
  array (
    'name' => 'Color: Button (Action)',
    'ref' => '_c-button-action',
    'css' => '#FFFFFF',
  ),
  'var-1535813470' => 
  array (
    'name' => 'Color: Button (Update)',
    'ref' => '_c-button-update',
    'css' => '#111111',
  ),
  'var-1536157664' => 
  array (
    'name' => 'Padding: Pre',
    'ref' => '_p-pre',
    'css' => '$x3',
  ),
  'var-1536172254' => 
  array (
    'name' => 'Font Size: Title',
    'ref' => '_f-title',
    'css' => false,
  ),
  'var-1536256424' => 
  array (
    'name' => 'Gutter: Mobile',
    'ref' => 'gutter-mobile',
    'css' => '$x3',
  ),
  'var-1536256437' => 
  array (
    'name' => 'Gutter: Full',
    'ref' => 'gutter-full',
    'css' => '$x2',
  ),
  'var-1536265199' => 
  array (
    'name' => 'Responsive Breakpoint 1',
    'ref' => 'b1',
    'css' => '421px',
  ),
  'var-1536265209' => 
  array (
    'name' => 'Responsive Breakpoint 2',
    'ref' => 'b2',
    'css' => '682px',
  ),
  'var-1536265219' => 
  array (
    'name' => 'Responsive Breakpoint 3',
    'ref' => 'b3',
    'css' => '706px',
  ),
  'var-1536265230' => 
  array (
    'name' => 'Responsive Breakpoint 4',
    'ref' => 'b4',
    'css' => '1040px',
  ),
  'var-1536265493' => 
  array (
    'name' => 'Responsive Breakpoint 5',
    'ref' => 'b5',
    'css' => '1102px',
  ),
  'var-1536336721' => 
  array (
    'name' => 'Line Height: Title',
    'ref' => '_g-title',
    'css' => false,
  ),
  'var-1536510302' => 
  array (
    'name' => 'Style: Title',
    'ref' => '_style-title',
    'css' => false,
  ),
  'var-1536510321' => 
  array (
    'name' => 'Style: Heading',
    'ref' => '_style-heading',
    'css' => 'font-weight: bold;',
  ),
  'var-1536510333' => 
  array (
    'name' => 'Style: Headline',
    'ref' => '_style-headline',
    'css' => false,
  ),
  'var-1536510338' => 
  array (
    'name' => 'Style: Impact Text',
    'ref' => '_style-impact',
    'css' => false,
  ),
  'var-1536510349' => 
  array (
    'name' => 'Style: Blockquote',
    'ref' => '_style-blockquote',
    'css' => false,
  ),
  'var-1536683888' => 
  array (
    'name' => 'Color: Image Caption',
    'ref' => '_c-caption',
    'css' => '$c2',
  ),
  'var-1536686808' => 
  array (
    'name' => 'Color: Pre',
    'ref' => '_c-pre',
    'css' => false,
  ),
  'var-1538163002' => 
  array (
    'name' => 'List Style',
    'ref' => '_list-style',
    'css' => false,
  ),
  'var-1538163014' => 
  array (
    'name' => 'List Margin (Left Indentation)',
    'ref' => '_list-margin',
    'css' => '$x2',
  ),
  'var-1538163027' => 
  array (
    'name' => 'List Item Margin',
    'ref' => '_list-item-margin',
    'css' => '$x4',
  ),
  'var-1538603666' => 
  array (
    'name' => 'Padding: Inputs',
    'ref' => '_p-input',
    'css' => '$x5',
  ),
  'var-1538604381' => 
  array (
    'name' => 'Padding: Buttons X',
    'ref' => '_p-button-x',
    'css' => '$x4',
  ),
  'var-1540762721' => 
  array (
    'name' => 'Color: Header',
    'ref' => '_c-header',
    'css' => false,
  ),
  'var-1540762734' => 
  array (
    'name' => 'Color: Content',
    'ref' => '_c-content',
    'css' => false,
  ),
  'var-1540762744' => 
  array (
    'name' => 'Color: Footer',
    'ref' => '_c-footer',
    'css' => '$c2',
  ),
  'var-1540826693' => 
  array (
    'name' => 'Text Color 1',
    'ref' => 'c1',
    'css' => '#111111',
  ),
  'var-1540826701' => 
  array (
    'name' => 'Text Color 2',
    'ref' => 'c2',
    'css' => 'rgba(0,0,0,0.55)',
  ),
  'var-1541174685' => 
  array (
    'name' => 'Golden Ratio',
    'ref' => 'phi',
    'css' => '1.6180339887',
  ),
  'var-1541433432' => 
  array (
    'name' => 'Font Size: Code (Small)',
    'ref' => '_f6c',
    'css' => '13px',
  ),
  'var-1541433490' => 
  array (
    'name' => 'Font Size 7',
    'ref' => '_f7',
    'css' => '11px',
  ),
  'var-1541629991' => 
  array (
    'name' => 'Border: Below Header',
    'ref' => '_b-header',
    'css' => '$border1',
  ),
  'var-1541630002' => 
  array (
    'name' => 'Border: Above Footer',
    'ref' => '_b-footer',
    'css' => '$border1',
  ),
  'var-1541631408' => 
  array (
    'name' => 'Border: Callouts',
    'ref' => '_b-callout',
    'css' => false,
  ),
  'var-1541631418' => 
  array (
    'name' => 'Padding: Callouts',
    'ref' => '_p-callout',
    'css' => '$x3',
  ),
  'var-1541631728' => 
  array (
    'name' => 'Border Style 1',
    'ref' => 'border1',
    'css' => '1px solid rgba(0,0,0,0.1)',
  ),
  'var-1541631739' => 
  array (
    'name' => 'Border Style 2',
    'ref' => 'border2',
    'css' => '1px solid rgba(0,0,0,0.12)',
  ),
  'var-1541802307' => 
  array (
    'name' => 'Font: Bylines',
    'ref' => '_font-byline',
    'css' => '$font-code',
  ),
  'var-1541802322' => 
  array (
    'name' => 'Font Size: Bylines',
    'ref' => '_f-byline',
    'css' => '$f6',
  ),
  'var-1541802334' => 
  array (
    'name' => 'Color: Bylines',
    'ref' => '_c-byline',
    'css' => false,
  ),
  'var-1541802356' => 
  array (
    'name' => 'Line Height: Byline',
    'ref' => '_g-byline',
    'css' => '25px',
  ),
  'var-1541866452' => 
  array (
    'name' => 'Font Size: Code',
    'ref' => '_f5c',
    'css' => '16px',
  ),
  'var-1542038133' => 
  array (
    'name' => 'Padding: Textarea',
    'ref' => '_p-textarea',
    'css' => '$x5',
  ),
  'var-1542045034' => 
  array (
    'name' => 'Font: Labels',
    'ref' => '_font-label',
    'css' => false,
  ),
  'var-1542045043' => 
  array (
    'name' => 'Font Style: Labels',
    'ref' => '_style-label',
    'css' => 'font-weight: bold;',
  ),
  'var-1542047173' => 
  array (
    'name' => 'Border: Inputs',
    'ref' => '_b-input',
    'css' => '$border2',
  ),
  'var-1542047182' => 
  array (
    'name' => 'Border: Textarea',
    'ref' => '_b-textarea',
    'css' => '$border2',
  ),
  'var-1542054463' => 
  array (
    'name' => 'Border: Select',
    'ref' => '_b-select',
    'css' => '$border2',
  ),
  'var-1542054471' => 
  array (
    'name' => 'Height: Select',
    'ref' => '_h-select',
    'css' => '$x2',
  ),
  'var-1543501584' => 
  array (
    'name' => 'CSS Feature: Sidebar',
    'ref' => '__sidebar',
    'css' => false,
  ),
  'var-1543684316' => 
  array (
    'name' => 'Border: Sidebar',
    'ref' => '_b-sidebar',
    'css' => '$border1',
  ),
  'var-1543684338' => 
  array (
    'name' => 'Background Color: Sidebar',
    'ref' => '_bg-sidebar',
    'css' => '$bg2',
  ),
  'var-1543684348' => 
  array (
    'name' => 'Font: Sidebar',
    'ref' => '_font-sidebar',
    'css' => false,
  ),
  'var-1543684375' => 
  array (
    'name' => 'Color: Sidebar',
    'ref' => '_c-sidebar',
    'css' => false,
  ),
  'var-1543773875' => 
  array (
    'name' => 'Padding: Header Top',
    'ref' => '_p-header-top',
    'css' => '$x4',
  ),
  'var-1543774491' => 
  array (
    'name' => 'Padding: Header Bottom',
    'ref' => '_p-header-bottom',
    'css' => '$x4',
  ),
  'var-1543774505' => 
  array (
    'name' => 'Padding: Content Top',
    'ref' => '_p-content-top',
    'css' => '$x2',
  ),
  'var-1543774525' => 
  array (
    'name' => 'Padding: Content Bottom',
    'ref' => '_p-content-bottom',
    'css' => '$x2',
  ),
  'var-1543774566' => 
  array (
    'name' => 'Padding: Footer Top',
    'ref' => '_p-footer-top',
    'css' => '$x3',
  ),
  'var-1543774579' => 
  array (
    'name' => 'Padding: Footer Bottom',
    'ref' => '_p-footer-bottom',
    'css' => '$x3',
  ),
  'var-1543934200' => 
  array (
    'name' => 'Padding: Buttons Y',
    'ref' => '_p-button-y',
    'css' => '$x4',
  ),
  'var-1543962762' => 
  array (
    'name' => 'Bar Width',
    'ref' => '_bar',
    'css' => '167px',
  ),
  'var-1544390930' => 
  array (
    'name' => 'Background Color: Nav Section',
    'ref' => '_bg-nav',
    'css' => false,
  ),
  'var-1544390957' => 
  array (
    'name' => 'Color: Nav Menu',
    'ref' => '_c-menu',
    'css' => '$ca',
  ),
  'var-1544393150' => 
  array (
    'name' => 'Border: Nav Menu',
    'ref' => '_b-nav',
    'css' => false,
  ),
  'var-1544461850' => 
  array (
    'name' => 'Text Transform: Nav Menu',
    'ref' => '_text-menu',
    'css' => false,
  ),
  'var-1544481808' => 
  array (
    'name' => 'CSS Feature: Header Image',
    'ref' => '__header-image',
    'css' => false,
  ),
  'var-1544481819' => 
  array (
    'name' => 'CSS Feature: Logo',
    'ref' => '__logo',
    'css' => false,
  ),
  'var-1546355762' => 
  array (
    'name' => 'Background Color: Highlights',
    'ref' => '_bg-highlight',
    'css' => '#FFFB7A',
  ),
  'var-1550844928' => 
  array (
    'name' => 'Font Size: Footer',
    'ref' => '_f-footer',
    'css' => '$f6',
  ),
  'var-1550844940' => 
  array (
    'name' => 'Font: Footer',
    'ref' => '_font-footer',
    'css' => '$font-code',
  ),
  'var-1550845018' => 
  array (
    'name' => 'Line Height: Footer',
    'ref' => '_g-footer',
    'css' => '25px',
  ),
  'var-1560374234' => 
  array (
    'name' => 'CSS Feature: Header Image Link',
    'ref' => '__header-image-link',
    'css' => false,
  ),
  'var-1560439739' => 
  array (
    'name' => 'CSS Feature: Bar',
    'ref' => '__bar',
    'css' => true,
  ),
  'var-1560527215' => 
  array (
    'name' => 'CSS Feature: Nav Section',
    'ref' => '__nav-section',
    'css' => true,
  ),
  'var-1561398950' => 
  array (
    'name' => 'Background Color: Secondary Nav',
    'ref' => '_bg-nav-2',
    'css' => false,
  ),
  'var-1561398967' => 
  array (
    'name' => 'Border: Nav Menu 2',
    'ref' => '_b-nav-2',
    'css' => '$border1',
  ),
  'var-1561399035' => 
  array (
    'name' => 'CSS Feature: Secondary Nav Section',
    'ref' => '__nav-section-2',
    'css' => false,
  ),
  'var-1561470853' => 
  array (
    'name' => 'Border Style 3',
    'ref' => 'border3',
    'css' => '1px solid rgba(0,0,0,0.18)',
  ),
  'var-1561473926' => 
  array (
    'name' => 'Padding: Nav Top',
    'ref' => '_p-menu-top',
    'css' => '$x4',
  ),
  'var-1561473937' => 
  array (
    'name' => 'Padding: Nav Bottom',
    'ref' => '_p-menu-bottom',
    'css' => '$x4',
  ),
  'var-1561473949' => 
  array (
    'name' => 'Margin: Nav Right',
    'ref' => '_m-menu-spacing',
    'css' => '$x2',
  ),
  'var-1575824999' => 
  array (
    'name' => 'Font Size: Blockquote',
    'ref' => '_f-blockquote',
    'css' => false,
  ),
  'var-1575825011' => 
  array (
    'name' => 'Line Height: Blockquote',
    'ref' => '_g-blockquote',
    'css' => false,
  ),
  'var-1576876633' => 
  array (
    'name' => 'Color: Required',
    'ref' => '_c-required',
    'css' => '#DD0000',
  ),
  'var-1607355428' => 
  array (
    'name' => 'CSS Feature: Bleeds',
    'ref' => '__bleed',
    'css' => true,
  ),
  'var-1607362832' => 
  array (
    'name' => 'Padding: Bleed Top',
    'ref' => '_p-bleed-top',
    'css' => '$x2',
  ),
  'var-1607362843' => 
  array (
    'name' => 'Padding: Bleed Bottom',
    'ref' => '_p-bleed-bottom',
    'css' => '$x2',
  ),
  'var-1607637118' => 
  array (
    'name' => 'CSS Feature: Full-width Featured Images',
    'ref' => '__featured-full',
    'css' => false,
  ),
  'var-1607788210' => 
  array (
    'name' => 'CSS Feature: Focus Mode Layout Centering',
    'ref' => '__center-layout',
    'css' => false,
  ),
  'var-1607791228' => 
  array (
    'name' => 'CSS Feature: Focus Content Centering',
    'ref' => '__center-content',
    'css' => true,
  ),
  'var-1610747877' => 
  array (
    'name' => 'Fill Device Width',
    'ref' => '_fill-device-width',
    'css' => 'position: relative;
		width: 100vw;
		max-width: 100vw;
		left: 50%;
		right: 50%;
		margin-left: -50vw;
		margin-right: -50vw;',
  ),
  'var-1610748223' => 
  array (
    'name' => 'CSS Feature: Full-width Header Image',
    'ref' => '__header-image-full',
    'css' => false,
  ),
  'var-1610904052' => 
  array (
    'name' => 'CSS Feature: Rounded Avatars',
    'ref' => '__avatar-round',
    'css' => false,
  ),
  'var-1610905697' => 
  array (
    'name' => 'Margin: Bleed Top',
    'ref' => '_m-bleed-top',
    'css' => '$x1',
  ),
  'var-1610905709' => 
  array (
    'name' => 'Margin: Bleed Bottom',
    'ref' => '_m-bleed-bottom',
    'css' => '$x1',
  ),
  'var-1630689497' => 
  array (
    'name' => 'Nested List Margin',
    'ref' => '_list-nested-margin',
    'css' => '$x3',
  ),
  'var-1666885468' => 
  array (
    'name' => 'Font: Impact Text',
    'ref' => '_font-impact',
    'css' => false,
  ),
  'var-1666885481' => 
  array (
    'name' => 'Color: Impact Text',
    'ref' => '_c-impact',
    'css' => false,
  ),
  'var-1674664614' => 
  array (
    'name' => 'Line Height: Impact Text F3',
    'ref' => '_g-impact-f3',
    'css' => '46px',
  ),
  'var-1674664631' => 
  array (
    'name' => 'Line Height: Impact Text F4',
    'ref' => '_g-impact-f4',
    'css' => '38px',
  ),
  'var-1674667851' => 
  array (
    'name' => 'CSS Feature: Focus Mode',
    'ref' => '__focus',
    'css' => false,
  ),
  'var-1684954994' => 
  array (
    'name' => 'Margin (Top): Caption',
    'ref' => '_m-caption',
    'css' => '-26px',
  ),
  'var-1684955021' => 
  array (
    'name' => 'Margin (Top): H2 + Caption (mobile)',
    'ref' => '_m-caption-h2-m',
    'css' => '-27.5px',
  ),
  'var-1684955071' => 
  array (
    'name' => 'Margin (Top): H3 + Caption',
    'ref' => '_m-caption-h3',
    'css' => '-16px',
  ),
  'var-1712334756' => 
  array (
    'name' => 'Margin (Top): H3 + Caption (mobile)',
    'ref' => '_m-caption-h3-m',
    'css' => '-17.5px',
  ),
  'css-var-1748120476' => 
  array (
    'name' => 'Background Color 1: Body',
    'ref' => 'bg1',
    'css' => '#FFFFFF',
  ),
  'css-var-1748120505' => 
  array (
    'name' => 'Background Color 2: Alternate',
    'ref' => 'bg2',
    'css' => '#E6F9FF',
  ),
  'css-var-1748120733' => 
  array (
    'name' => 'Background Color: Blockquote',
    'ref' => '_bg-blockquote',
    'css' => '#F7EDD4',
  ),
  'css-var-1748120876' => 
  array (
    'name' => 'Text Color: Callout',
    'ref' => '_c-callout',
    'css' => '#111111',
  ),
  'css-var-1748120889' => 
  array (
    'name' => 'Text Color: Note Callout',
    'ref' => '_c-callout-note',
    'css' => '#111111',
  ),
  'css-var-1748120914' => 
  array (
    'name' => 'Text Color: Alert Callout',
    'ref' => '_c-callout-alert',
    'css' => '#111111',
  ),
  'css-var-1748120958' => 
  array (
    'name' => 'Text Color: Drop Cap',
    'ref' => '_c-drop-cap',
    'css' => false,
  ),
  'css-var-1748121118' => 
  array (
    'name' => 'Font: Caption',
    'ref' => '_font-caption',
    'css' => '$font-code',
  ),
  'css-var-1748121135' => 
  array (
    'name' => 'Font: Drop Cap',
    'ref' => '_font-drop-cap',
    'css' => false,
  ),
  'css-var-1748124241' => 
  array (
    'name' => 'Google Fonts (Editor)',
    'ref' => '_google-fonts',
    'css' => '@import url(\'https://fonts.googleapis.com/css?family=IBM+Plex+Sans:400,400i,700\');
@import url(\'https://fonts.googleapis.com/css?family=IBM+Plex+Serif:400,400i,700\');
@import url(\'https://fonts.googleapis.com/css?family=IBM+Plex+Mono:400,400i,700\');',
  ),
  'css-var-1750872406' => 
  array (
    'name' => 'Background Color: Button (UI)',
    'ref' => '_bg-button-ui',
    'css' => '#D6F5ED',
  ),
  'css-var-1750872428' => 
  array (
    'name' => 'Background Color: Button (UI Alt)',
    'ref' => '_bg-button-ui-alt',
    'css' => '#FFD1FC',
  ),
  'css-var-1750872462' => 
  array (
    'name' => 'Text Color: Button (UI)',
    'ref' => '_c-button-ui',
    'css' => '#111111',
  ),
  'css-var-1750872477' => 
  array (
    'name' => 'Text Color: Button (UI Alt)',
    'ref' => '_c-button-ui-alt',
    'css' => '#111111',
  ),
  'css-var-1750876425' => 
  array (
    'name' => 'Padding: Nav Section Top',
    'ref' => '_p-nav-top',
    'css' => '$x4',
  ),
  'css-var-1750876458' => 
  array (
    'name' => 'Padding: Nav Section Bottom',
    'ref' => '_p-nav-bottom',
    'css' => false,
  ),
  'css-var-1750876478' => 
  array (
    'name' => 'Padding: Secondary Nav Top',
    'ref' => '_p-nav-2-top',
    'css' => '',
  ),
  'css-var-1750876498' => 
  array (
    'name' => 'Padding: Secondary Nav Bottom',
    'ref' => '_p-nav-2-bottom',
    'css' => '',
  ),
);
	}

	public function css() {
		return false;
	}

	public function css_editor() {
		return false;
	}

	public function design() {
		return array (
  'font1' => 'IBM Plex Sans',
  'font2' => 'IBM Plex Serif',
  'font-code' => 'IBM Plex Mono',
  'font-size' => '18',
  'bg1' => 'FFFFFF',
  'bg2' => 'E6F9FF',
  'c1' => '111111',
  'c2' => 'rgba(0,0,0,0.55)',
  'ca' => 'DE0404',
  'border1' => '1px solid rgba(0,0,0,0.1)',
  'border2' => '1px solid rgba(0,0,0,0.12)',
  'border3' => '1px solid rgba(0,0,0,0.18)',
  'w-content' => '644',
  'w-total' => '1040',
  'gutter-full' => 'x2',
  'gutter-mobile' => 'x3',
  'bg-header-custom' => 'FFFFFF',
  'c-header-custom' => 'FFFFFF',
  'padding-header-top' => 'x4',
  'padding-header-bottom' => 'x4',
  'border-header' => 'border1',
  'bg-nav-custom' => 'FFFFFF',
  'padding-nav-top' => 'x4',
  'bg-content-custom' => 'FFFFFF',
  'c-content-custom' => 'FFFFFF',
  'padding-content-top' => 'x2',
  'padding-content-bottom' => 'x2',
  'bg-nav-2-custom' => 'FFFFFF',
  'border-nav-2' => 'border1',
  'bg-footer-custom' => 'FFFFFF',
  'c-footer' => 'c2',
  'c-footer-custom' => 'FFFFFF',
  'padding-footer-top' => 'x3',
  'padding-footer-bottom' => 'x3',
  'border-footer' => 'border1',
  'font-footer' => 'font-code',
  'f-footer' => 'f6',
  'bg-button' => 'EBDCC8',
  'bg-button-save' => '509B26',
  'bg-button-delete' => 'D50B0B',
  'bg-button-action' => '12A7FF',
  'bg-button-update' => 'FCFC0D',
  'bg-button-ui' => 'D6F5ED',
  'bg-button-ui-alt' => 'FFD1FC',
  'padding-button-x' => 'x4',
  'padding-button-y' => 'x4',
  'style-label' => 'bold',
  'padding-input' => 'x5',
  'border-input' => 'border2',
  'c-required' => 'DD0000',
  'padding-textarea' => 'x5',
  'border-textarea' => 'border2',
  'border-select' => 'border2',
  'font-byline' => 'font-code',
  'f-byline' => 'f6',
  'c-byline-custom' => 'FFFFFF',
  'style-heading' => 'bold',
  'style-drop-cap' => 'bold',
  'c-drop-cap-custom' => 'FFFFFF',
  'font-caption' => 'font-code',
  'c-caption' => 'c2',
  'c-caption-custom' => 'FFFFFF',
  'list-margin' => 'x2',
  'list-nested-margin' => 'x3',
  'list-item-margin' => 'x4',
  'c-impact-custom' => 'FFFFFF',
  'bg-blockquote' => 'custom',
  'bg-blockquote-custom' => 'F7EDD4',
  'c-blockquote-custom' => 'FFFFFF',
  'bg-highlight' => 'FFFB7A',
  'bg-callout' => 'CCE8CC',
  'bg-callout-alert' => 'FFE91F',
  'bg-callout-note' => 'CCF1FF',
  'padding-callout' => 'x3',
  'padding-bleed-top' => 'x2',
  'padding-bleed-bottom' => 'x2',
  'margin-bleed-top' => 'x1',
  'margin-bleed-bottom' => 'x1',
  'bg-pre' => 'custom',
  'bg-pre-custom' => 'EDF1FF',
  'c-pre-custom' => 'FFFFFF',
  'c-title-custom' => 'FFFFFF',
  'c-menu' => 'ca',
  'c-menu-custom' => 'FFFFFF',
  'padding-menu-top' => 'x4',
  'padding-menu-bottom' => 'x4',
  'margin-menu-spacing' => 'x2',
  'bg-sidebar' => 'bg2',
  'bg-sidebar-custom' => 'FFFFFF',
  'c-sidebar-custom' => 'FFFFFF',
  'border-sidebar' => 'border1',
);
	}

	public function display() {
		return array (
);
	}
}
