<?php
/*
Name: Attention
Author: Pearsonified
Description: Default Front End Theme for PageMotor
Version: 0.1
Requires: 0.1
Class: PM_Attention
Docs: https://pagemotor.com/themes/attention/
License: MIT2

See the PageMotor license.txt file for more information.
*/
/**
 * PageMotor Attention Theme
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Theme
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Attention extends PM_Theme {
	public $mode = 'focus';

	public function body_classes() {
		$classes = array();
		if (!empty($this->mode))
			$classes[] = $this->mode;
		return $classes;
	}

	public function body_classes_editor() {
		$classes = array();
		if (!empty($this->mode))
			$classes[] = $this->mode;
		return $classes;
	}

	protected function design() {
		global $motor;
		$mono = $base = $sections = $content = $sitewide = $forms = array();
		foreach ($motor->fonts->all() as $name => $font)
			if (!empty($font['monospace']))
				$mono[$name] = !empty($font['name']) ? $font['name'] : ucfirst($name);
		$heading = array(
			'type' => 'custom',
			'class' => 'group-heading');
		$heading_options = array(
			'type' => 'custom',
			'class' => 'options-heading');
		$fonts = $motor->fonts->select();
		$font_options = array(
			'' => 'Primary Font',
			'font2' => 'Secondary Font',
			'font-code' => 'Code Font');
		$select_mono = array(
			'type' => 'select',
			'label' => 'Font',
			'options' => array_merge(array('' => 'Select a font:'), $mono));
		$spacing = array(
			'' => '0',
			'x1' => 'x1',
			'x2' => 'x2 *',
			'x3' => 'x3',
			'x4' => 'x4',
			'x5' => 'x5',
			'x6' => 'x6');
		$font_size = array(
			'' => 'Select Size:',
			'f1' => 'Size 1 (f1)',
			'f2' => 'Size 2 (f2)',
			'f3' => 'Size 3 (f3)',
			'f4' => 'Size 4 (f4)',
			'f5' => 'Size 5 (f5) *',
			'f6' => 'Size 6 (f6)');
		$select_font = array(
			'type' => 'select',
			'item-class' => 'inline-select',
			'description' => 'Font',
			'options' => $font_options);
		$select_font_size = array(
			'type' => 'select',
			'item-class' => 'inline-select',
			'description' => 'Font Size',
			'options' => $font_size);
		$input_px = array(
			'type' => 'text',
			'width' => 'tiny',
			'description' => 'px');
		$input_color = array(
			'type' => 'color',
			'width' => 'short',
			'description' => 'Text Color');
		$custom_color = array_merge($input_color, array(
			'item-class' => 'nested-custom',
			'description' => false));
		$select_color = array(
			'type' => 'select',
			'item-class' => 'inline-select',
			'description' => 'Text Color',
			'options' => array(
				'' => 'Select Color',
				'c1' => 'Primary',
				'c2' => 'Accent',
				'ca' => 'Link',
				'custom' => 'Custom'),
			'dependents' => array(
				'custom'));
		$select_bg = array(
			'type' => 'select',
			'item-class' => 'inline-select',
			'description' => 'Background',
			'options' => array(
				'' => 'Select Color',
				'bg1' => 'Body',
				'bg2' => 'Alt',
				'custom' => 'Custom'),
			'dependents' => array(
				'custom'));
		$select_spacing = array(
			'type' => 'select',
			'item-class' => 'inline-select',
			'options' => $spacing);
		$border_options = array(
			'' => 'No border',
			'border1' => 'Border Style 1',
			'border2' => 'Border Style 2',
			'border3' => 'Border Style 3',
			'custom' => 'Custom Border');
		$input_border = array(
			'type' => 'text',
			'code' => true,
			'width' => 'full');
		$custom_border = array_merge($input_border, array(
			'item-class' => 'nested-custom'));
		$select_border = array(
			'type' => 'select',
			'item-class' => 'inline-select',
			'options' => $border_options,
			'dependents' => array(
				'custom'));
		$select_style = array(
			'type' => 'select',
			'item-class' => 'inline-select',
			'description' => 'Font Style',
			'options' => array(
				'' => 'normal',
				'bold' => 'bold',
				'italic' => 'italic'));
		$base['a'] = array(
			'base-a' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'font1' => array(
						'type' => 'select',
						'label' => 'Primary Font',
						'item-class' => 'series',
						'options' => array_merge(array('' => 'Select a font:'), $fonts)),
					'font2' => array(
						'type' => 'select',
						'label' => 'Secondary Font',
						'item-class' => 'series',
						'options' => array_merge(array('' => 'Same as Primary Font'), $fonts)),
					'font-code' => array(
						'type' => 'select',
						'label' => 'Code Font',
						'item-class' => 'series',
						'options' => array_merge(array('' => 'Select a font:'), $mono)),
					'font-size' => array_merge($input_px, array(
						'label' => 'Font Size')),
					'heading-backgrounds' => array_merge($heading, array(
						'html' => "Background Colors\n")),
					'bg1' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Body Background')),
					'bg2' => array_merge($input_color, array(
						'description' => 'Alt Background')))));
		$base['b'] = array(
			'base-b' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-colors' => array_merge($heading, array(
						'html' => "Text and Link Colors\n")),
					'c1' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Primary')),
					'c2' => array(
						'type' => 'text',
						'code' => true,
						'width' => 'medium',
						'item-class' => 'inline-text series',
						'description' => 'Accent'),
					'ca' => array_merge($input_color, array(
						'description' => 'Links')),
					'heading-borders' => array_merge($heading, array(
						'html' => "Borders\n")),
					'border1' => array_merge($input_border, array(
						'item-class' => 'series-tight',
						'description' => 'Border Style 1',
						'tooltip' => false)),
					'border2' => array_merge($input_border, array(
						'item-class' => 'series-tight',
						'description' => 'Border Style 2',
						'tooltip' => false)),
					'border3' => array_merge($input_border, array(
						'description' => 'Border Style 3',
						'tooltip' => false)))));
		$base['c'] = array(
			'base-c' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'w-content' => array_merge($input_px, array(
						'item-class' => 'series',
						'label' => 'Content Width',
						'tooltip' => 'This value represents the width of your primary column of text.')),
					'w-total' => array_merge($input_px, array(
						'item-class' => 'series',
						'label' => 'Total Layout Width',
						'tooltip' => 'This value represents the total <em>usable</em> width of your design. Leave blank for 100%')),
					'heading-gutter' => array_merge($heading, array(
						'html' => "Layout Gutters\n")),
					'gutter-full' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Desktop Gutter')),
					'gutter-mobile' => array_merge($select_spacing, array(
						'description' => 'Mobile Gutter')))));
		$content['a'] = array(
			'content-a' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-headline' => array_merge($heading, array(
						'html' => "Page Headlines\n")),
					'font-headline' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'style-headline' => $select_style,
					'heading-byline' => array_merge($heading, array(
						'html' => "Page Bylines\n")),
					'font-byline' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'f-byline' => array_merge($select_font_size, array(
						'item-class' => 'inline-select series')),
					'c-byline' => $select_color,
					'c-byline-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-byline' => 'custom'))),
					'heading-heading' => array_merge($heading, array(
						'html' => "Headings (H1–H4)\n")),
					'font-heading' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'style-heading' => array_merge($select_style, array(
						'item-class' => 'inline-select')),
					'heading-drop-cap' => array_merge($heading, array(
						'html' => "Drop Caps\n")),
					'font-drop-cap' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'style-drop-cap' => array_merge($select_style, array(
						'item-class' => 'inline-select series')),
					'c-drop-cap' => $select_color,
					'c-drop-cap-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-drop-cap' => 'custom'))),
					'heading-caption' => array_merge($heading, array(
						'html' => "Captions & Small Text\n")),
					'font-caption' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'c-caption' => array_merge($select_color, array(
						'item-class' => 'inline-select last-select')),
					'c-caption-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-caption' => 'custom'))))));
		$content['b'] = array(
			'content-b' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-list' => array_merge($heading, array(
						'html' => "Lists\n")),
					'list-style' => array(
						'type' => 'select',
						'item-class' => 'inline-select series',
						'description' => 'List Style',
						'options' => array(
							'' => 'disc',
							'circle' => 'circle',
							'square' => 'square',
							'none' => 'none')),
					'list-margin' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Item Indent')),
					'list-nested-margin' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Nested Indent')),
					'list-item-margin' => array_merge($select_spacing, array(
						'description' => 'Item Bottom Margin')),
					'heading-impact' => array_merge($heading, array(
						'html' => "Impact Text\n")),
					'font-impact' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'style-impact' => array_merge($select_style, array(
						'item-class' => 'inline-select series')),
					'c-impact' => $select_color,
					'c-impact-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-impact' => 'custom'))),
					'heading-blockquote' => array_merge($heading, array(
						'html' => "Blockquotes\n")),
					'font-blockquote' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'bg-blockquote' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-blockquote-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-blockquote' => 'custom'))),
					'c-blockquote' => $select_color,
					'c-blockquote-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-blockquote' => 'custom'))),
					'heading-highlight' => array_merge($heading, array(
						'html' => "Inline Highlights\n")),
					'bg-highlight' => array_merge($input_color, array(
						'description' => 'Background')))));
		$content['c'] = array(
			'content-c' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-callout' => array_merge($heading, array(
						'html' => "Callouts\n")),
					'bg-callout' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Basic Background')),
					'bg-callout-alert' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Alert Background')),
					'bg-callout-note' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Note Background')),
					'padding-callout' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding')),
					'border-callout' => $select_border,
					'border-callout-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-callout' => 'custom'))),
					'heading-bleed' => array_merge($heading, array(
						'html' => "Bleeds\n")),
					'padding-bleed-top' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Top Padding')),
					'padding-bleed-bottom' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Bottom Padding')),
					'margin-bleed-top' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Top Margin')),
					'margin-bleed-bottom' => array_merge($select_spacing, array(
						'description' => 'Bottom Margin')),
					'heading-pre' => array_merge($heading, array(
						'html' => "Preformatted Code\n")),
					'bg-pre' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-pre-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-pre' => 'custom'))),
					'c-pre' => array_merge($select_color, array(
						'item-class' => 'inline-select last-select')),
					'c-pre-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-pre' => 'custom'))))));
		$sections['a'] = array(
			'sections-a' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-header' => array_merge($heading, array(
						'html' => "Header\n")),
					'bg-header' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-header-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-header' => 'custom'))),
					'c-header' => array_merge($select_color, array(
						'item-class' => 'inline-select series')),
					'c-header-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-header' => 'custom'))),
					'padding-header-top' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding Top')),
					'padding-header-bottom' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding Bottom')),
					'border-header' => array_merge($select_border, array(
						'description' => 'Bottom Border')),
					'border-header-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-header' => 'custom'))),
					'heading-nav' => array_merge($heading, array(
						'html' => "Nav\n")),
					'bg-nav' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-nav-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-nav' => 'custom'))),
					'border-nav' => array_merge($select_border, array(
						'item-class' => 'inline-select last-select',
						'description' => 'Bottom Border')),
					'border-nav-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-nav' => 'custom'))))));
		$sections['b'] = array(
			'sections-b' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-content' => array_merge($heading, array(
						'html' => "Content\n")),
					'bg-content' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-content-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-content' => 'custom'))),
					'c-content' => array_merge($select_color, array(
						'item-class' => 'inline-select series')),
					'c-content-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-content' => 'custom'))),
					'padding-content-top' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding Top')),
					'padding-content-bottom' => array_merge($select_spacing, array(
						'description' => 'Padding Bottom')),
					'heading-nav-2' => array_merge($heading, array(
						'html' => "Secondary Nav\n")),
					'bg-nav-2' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-nav-2-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-nav-2' => 'custom'))),
					'border-nav-2' => array_merge($select_border, array(
						'item-class' => 'inline-select last-select',
						'description' => 'Bottom Border')),
					'border-nav-2-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-nav-2' => 'custom'))))));
		$sections['c'] = array(
			'sections-c' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-footer' => array_merge($heading, array(
						'html' => "Footer\n")),
					'bg-footer' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-footer-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-footer' => 'custom'))),
					'c-footer' => array_merge($select_color, array(
						'item-class' => 'inline-select series')),
					'c-footer-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-footer' => 'custom'))),
					'padding-footer-top' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding Top')),
					'padding-footer-bottom' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding Bottom')),
					'border-footer' => array_merge($select_border, array(
						'item-class' => 'inline-select series',
						'description' => 'Top Border')),
					'border-footer-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-footer' => 'custom'))),
					'font-footer' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'f-footer' => array_merge($select_font_size, array(
						'item-class' => 'inline-select last-select')))));
		$sitewide['a'] = array(
			'sitewide-a' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-title' => array_merge($heading, array(
						'html' => "Site Title\n")),
					'font-title' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'f-title' => array_merge($select_font_size, array(
						'item-class' => 'inline-select series')),
					'style-title' => array_merge($select_style, array(
						'item-class' => 'inline-select series')),
					'c-title' => array_merge($select_color, array(
						'item-class' => 'inline-select last-select')),
					'c-title-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-title' => 'custom'))))));
		$sitewide['b'] = array(
			'sitewide-b' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-menu' => array_merge($heading, array(
						'html' => "Nav Menus\n")),
					'font-menu' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'f-menu' => array_merge($select_font_size, array(
						'item-class' => 'inline-select series')),
					'c-menu' => array_merge($select_color, array(
						'item-class' => 'inline-select series',
						'description' => 'Link Color')),
					'c-menu-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-nav' => 'custom'))),
					'text-menu' => array(
						'type' => 'select',
						'item-class' => 'inline-select series',
						'description' => 'Text Transform',
						'options' => array(
							'' => 'None',
							'uppercase' => 'Uppercase',
							'lowercase' => 'Lowercase')),
					'padding-menu-top' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Link Top Padding')),
					'padding-menu-bottom' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Link Bottom Padding')),
					'margin-menu-spacing' => array_merge($select_spacing, array(
						'description' => 'Space Between Items')))));
		$sitewide['c'] = array(
			'sitewide-c' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-sidebar' => array_merge($heading, array(
						'html' => "Sidebar\n")),
					'bg-sidebar' => array_merge($select_bg, array(
						'item-class' => 'inline-select series')),
					'bg-sidebar-custom' => array_merge($custom_color, array(
						'parent' => array(
							'bg-sidebar' => 'custom'))),
					'c-sidebar' => array_merge($select_color, array(
						'item-class' => 'inline-select series')),
					'c-sidebar-custom' => array_merge($custom_color, array(
						'parent' => array(
							'c-sidebar' => 'custom'))),
					'font-sidebar' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'border-sidebar' => array_merge($select_border, array(
						'item-class' => 'inline-select series',
						'description' => 'Top Border')),
					'border-sidebar-custom' => array_merge($custom_border, array(
						'item-class' => 'series nested-custom',
						'parent' => array(
							'border-sidebar' => 'custom'))),
					'border-sidebar-note' => array(
						'type' => 'custom',
						'html' => "<p class=\"small\"><strong>Note:</strong> This border displays in <strong>responsive views</strong> to separate the Sidebar from the Content.</p>\n"))));
		$forms['a'] = array(
			'forms-a' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-label' => array_merge($heading, array(
						'html' => "Labels\n")),
					'font-label' => array_merge($select_font, array(
						'item-class' => 'inline-select series')),
					'style-label' => $select_style,
					'heading-input' => array_merge($heading, array(
						'html' => "Text Inputs\n")),
					'padding-input' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding')),
					'border-input' => $select_border,
					'border-input-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-input' => 'custom'))),
					'heading-required' => array_merge($heading, array(
						'html' => "Required Indicator\n")),
					'c-required' => $input_color)));
		$forms['b'] = array(
			'forms-b' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-textarea' => array_merge($heading, array(
						'html' => "Textarea\n")),
					'padding-textarea' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Padding')),
					'border-textarea' => $select_border,
					'border-textarea-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-textarea' => 'custom'))),
					'heading-select' => array_merge($heading, array(
						'html' => "Select\n")),
					'height-select' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Height',
						'options' => array_merge(array(
							'' => 'Select Height:'), $spacing))),
					'border-select' => array_merge($select_border, array(
						'item-class' => 'inline-select last-select')),
					'border-select-custom' => array_merge($custom_border, array(
						'parent' => array(
							'border-select' => 'custom'))))));
		$forms['c'] = array(
			'forms-c' => array(
				'type' => 'group',
				'class' => 'flex-group',
				'fields' => array(
					'heading-button' => array_merge($heading, array(
						'html' => "Buttons\n")),
					'bg-button' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Basic')),
					'bg-button-save' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Save')),
					'bg-button-delete' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Delete')),
					'bg-button-action' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Action')),
					'bg-button-update' => array_merge($input_color, array(
						'item-class' => 'series',
						'description' => 'Update')),
					'padding-button-x' => array_merge($select_spacing, array(
						'item-class' => 'inline-select series',
						'description' => 'Horizontal (X) Padding')),
					'padding-button-y' => array_merge($select_spacing, array(
						'description' => 'Vertical (Y) Padding')))));
		return array(
			'options-heading-base' => array_merge($heading_options, array(
				'html' => "<h3>Base Fonts, Colors, and Layout</h3>\n")),
			'group-base' => array(
				'type' => 'group',
				'class' => 'flex-groups',
				'fields' => array_merge(
					$base['a'],
					$base['b'],
					$base['c'])),
			'options-heading-content' => array_merge($heading_options, array(
				'html' => "<h3>Content Element Fonts, Colors, and More</h3>\n")),
			'group-content' => array(
				'type' => 'group',
				'class' => 'flex-groups',
				'fields' => array_merge(
					$content['a'],
					$content['b'],
					$content['c'])),
			'options-heading-sections' => array_merge($heading_options, array(
				'html' => "<h3>Layout Section Design Details</h3>\n")),
			'group-sections' => array(
				'type' => 'group',
				'class' => 'flex-groups',
				'fields' => array_merge(
					$sections['a'],
					$sections['b'],
					$sections['c'])),
			'options-heading-sitewide' => array_merge($heading_options, array(
				'html' => "<h3>Sitewide Design Elements</h3>\n")),
			'group-sitewide' => array(
				'type' => 'group',
				'class' => 'flex-groups',
				'fields' => array_merge(
					$sitewide['a'],
					$sitewide['b'],
					$sitewide['c'])),
			'options-heading-forms' => array_merge($heading_options, array(
				'html' => "<h3>Form Elements</h3>\n")),
			'group-forms' => array(
				'type' => 'group',
				'class' => 'flex-groups groups-last',
				'fields' => array_merge(
					$forms['a'],
					$forms['b'],
					$forms['c'])));
	}

	protected function css_vars() {
		global $motor;
		$px = $vars = $fonts = $g = $gs = $selected_fonts = array();
		// Layout Settings
		$px['w-total'] = abs($this->design['w-total']);
		$px['w-content'] = abs($this->design['w-content']);
		// Base Fonts
		$vars['font1'] = $motor->fonts->family($fonts['font1'] = !empty($this->design['font1']) ? $this->design['font1'] : 'system');
		$vars['font2'] = $motor->fonts->family($fonts['font2'] = !empty($this->design['font2']) ? $this->design['font2'] : false);
		$vars['font-code'] = $motor->fonts->family($fonts['font_code'] = !empty($this->design['font-code']) ? $this->design['font-code'] : false);
		$font_size = !empty($this->design['font-size']) ? $this->design['font-size'] : 18;
		foreach (array('font1', 'font2', 'font-code') as $font) {
			$scales[$font] = $this->tools->grt->scale(abs($font_size));
			foreach ($scales[$font] as $scale => $size)
				if ($font === 'font1')
					$px['g'. trim($scale, 'f')] = $g[$scale] = $gs[$font][$scale] = round($this->tools->grt->height(
						($px[$scale] = $size),
						$px['w-content'],
						$fonts['font1']));
				else
					$gs[$font][$scale] = round($this->tools->grt->height(
						$size,
						$px['w-content'],
						!empty($fonts[$font]) ? $fonts[$font] : $fonts['font1']));
		}
		// Size corrections for <code> elements
		$px['_f5c'] = $px['f6'] + round(($px['f5'] - $px['f6']) / 2);
		$px['_f7'] = round($px['f5'] / $this->tools->grt->phi);
		$px['_f6c'] = $px['_f7'] + round(($px['f6'] - $px['_f7']) / 2);
		// Spacing
		if ($spacing = $this->tools->grt->spacing($px['g5']))
			$px = array_merge($px, $spacing);
		// Horizontal Gutters
		$vars['gutter-full'] = ($gutter_full = $this->design['gutter-full']) && !empty($gutter_full) ?
			"\$$gutter_full" : false;
		$vars['gutter-mobile'] = ($gutter_mobile = $this->design['gutter-mobile']) && !empty($gutter_mobile) ?
			"\$$gutter_mobile" : false;
		// Responsive Breakpoints
		$px['b1'] = !empty($px['w-content']) && !empty($gutter_mobile) && !empty($px[$gutter_mobile]) ?
			round(($px['w-content'] + (2 * $px[$gutter_mobile])) / $this->tools->grt->phi) : false;
		$px['b2'] = !empty($px['w-content']) && !empty($gutter_mobile) && !empty($px[$gutter_mobile]) ?
			$px['w-content'] + (2 * $px[$gutter_mobile]) : false;
		$px['b3'] = !empty($px['w-content']) && !empty($gutter_full) && !empty($px[$gutter_full]) ?
			$px['w-content'] + (2 * $px[$gutter_full]) : false;
		$px['b4'] = !empty($px['w-total']) ?
			$px['w-total'] : false;
		$px['b5'] = !empty($px['w-total']) && !empty($gutter_full) && !empty($px[$gutter_full]) ?
			$px['w-total'] + (2 * $px[$gutter_full]) : false;
		// Bar Width (Focus pages)
		$px['_bar'] = round(($px['w-total'] - $px['w-content'] - (2 * $px['x2'])) / 2);
		// Base Borders
		foreach (array('border1', 'border2', 'border3') as $border)
			$vars[$border] = !empty($this->design[$border]) ? $this->design[$border] : false;
		// Selected Fonts (if empty = font1)
		foreach (array('headline', 'byline', 'heading', 'drop-cap', 'blockquote', 'impact', 'caption', 'footer', 'title', 'menu', 'sidebar', 'label') as $f) {
			$selected_fonts[$f] = !empty($this->design["font-$f"]) ? $this->design["font-$f"] : false;
			$vars["_font-$f"] = !empty($selected_fonts[$f]) ? "\${$selected_fonts[$f]}" : false;
		}
		// Font Size Selections + Associated Line Heights for specific elements
		foreach (array('byline', 'footer', 'title', 'menu') as $fs) {
			$vars["_f-$fs"] = !empty($this->design["f-$fs"]) ? "\${$this->design["f-$fs"]}" : false;
			$vars["_g-$fs"] = !empty($this->design["f-$fs"]) ? (!empty($selected_fonts[$fs]) ?
				$gs[$selected_fonts[$fs]][$this->design["f-$fs"]]. 'px' :
				"\$g". ltrim($this->design["f-$fs"], 'f')) : false;
		}
		// Impact Text Line Heights
//		$px['_g-impact-f3'] = round($skin->grt->height($px['f3'], $px['w-content'], !empty($fonts['impact']) ? $fonts['impact'] : $font1));
//		$px['_g-impact-f4'] = round($skin->grt->height($px['f4'], $px['w-content'], !empty($fonts['impact']) ? $fonts['impact'] : $font1));
		// Direct-input Base Colors (includes direct-input via text input [not a color field])
		foreach (array('bg1', 'bg2', 'c1', 'c2', 'ca') as $color)
			$vars[$color] = $this->tools->color->css(!empty($this->design[$color]) ? $this->design[$color] : false);
		// Direct-input underscored colors
		foreach (array('bg-highlight', 'bg-callout', 'bg-callout-alert', 'bg-callout-note', 'c-required', 'bg-button', 'bg-button-save', 'bg-button-delete', 'bg-button-action', 'bg-button-update') as $c)
			$vars["_$c"] = $this->tools->color->css($this->design[$c]);
		// Selected + Custom Colors
		foreach (array('c-byline', 'c-drop-cap', 'bg-blockquote', 'c-blockquote', 'c-impact', 'c-caption', 'bg-pre', 'c-pre', 'bg-header', 'c-header', 'bg-nav', 'bg-nav-2', 'bg-content', 'c-content', 'bg-footer', 'c-footer', 'c-title', 'c-menu', 'bg-sidebar', 'c-sidebar') as $cs)
			$vars["_$cs"] = !empty($this->design[$cs]) ? ($this->design[$cs] === 'custom' ?
				$this->tools->color->css($this->design["$cs-custom"]) : "\${$this->design[$cs]}") : false;
		// Set overlay text colors for direct-input background colors
		foreach (array('callout', 'callout-alert', 'callout-note', 'button', 'button-save', 'button-delete', 'button-action', 'button-update') as $item) {
			$gray = $this->tools->color->gray(!empty($this->design["bg-$item"]) ? $this->design["bg-$item"] : false);
			if (!empty($gray))
				$vars["_c-$item"] = hexdec($gray['hex']) >= hexdec('858585') ? '#111111' : '#FFFFFF';
		}
		// Text Transforms
		foreach (array('menu') as $tt)
			$vars["_text-$tt"] = !empty($this->design["text-$tt"]) ? $this->design["text-$tt"] : false;
		// Font Styles
		foreach (array('headline', 'heading', 'drop-cap', 'impact', 'title', 'label') as $style)
			$vars["_style-$style"] = !empty($this->design["style-$style"]) ? ($this->design["style-$style"] === 'bold' ?
				'font-weight: bold;' : ($this->design["style-$style"] === 'italic' ?
				'font-style: italic;' : false)) : false;
		// Selected Borders
		foreach (array('callout', 'header', 'nav', 'nav-2', 'footer', 'sidebar', 'input', 'textarea', 'select') as $border)
			$vars["_b-$border"] = !empty($this->design["border-$border"]) ? ($this->design["border-$border"] === 'custom' ?
				$this->tools->color->css($this->design["border-$border-custom"]) : "\${$this->design["border-$border"]}") : false;
		// Heights
		foreach (array('select') as $h)
			$vars["_h-$h"] = !empty($this->design["height-$h"]) ? "\${$this->design["height-$h"]}" : false;
		// Lists
		$vars['_list-style'] = !empty($this->design['list-style']) ? $this->design['list-style'] : false;
		foreach (array('list-margin', 'list-item-margin', 'list-nested-margin') as $list)
			$vars["_$list"] = !empty($this->design[$list]) ? "\${$this->design[$list]}" : false;
		// Padding
		foreach (array('callout', 'bleed-top', 'bleed-bottom', 'header-top', 'header-bottom', 'content-top', 'content-bottom', 'footer-top', 'footer-bottom', 'menu-top', 'menu-bottom', 'input', 'textarea', 'button-x', 'button-y') as $padding)
			$vars["_p-$padding"] = !empty($this->design["padding-$padding"]) ? "\${$this->design["padding-$padding"]}" : false;
		// Margins
		foreach (array('bleed-top', 'bleed-bottom', 'menu-spacing') as $margin)
			$vars["_m-$margin"] = !empty($this->design["margin-$margin"]) ? "\${$this->design["margin-$margin"]}" : false;
		$px['_m-caption'] = round((($px['x3'] - $px['x2']) / $this->tools->grt->phi) - $px['x3']);
		$px['_m-caption-h2-m'] = $px['_m-caption'] - ((($px['g2'] - $px['f2']) / 2) - (($px['g3'] - $px['f3']) / 2));
		$px['_m-caption-h3'] = round((($px['x4'] - $px['x3']) / $this->tools->grt->phi) - $px['x4']);
		$px['_m-caption-h3-m'] = $px['_m-caption-h3'] - ((($px['g3'] - $px['f3']) / 2) - (($px['g4'] - $px['f4']) / 2));
		// Add the 'px' unit to the $px array constructed above
		$vars = is_array($px) ? array_merge($vars, $this->tools->css->unit($px)) : $vars;
		// Add Google Fonts (for use in the Content Editor)
		$vars['_google-fonts'] = false;
		$gf = array();
		$google_fonts = $motor->fonts->google->get($this->design);
		foreach ($google_fonts as $num => $font) {
			if (!empty($font['url']))
				$gf[] = "@import url('{$font['url']}');";
			$vars['_google-fonts'] = implode("\n", $gf);
		}
		// Add phi for in-stylesheet calculations
		$vars['phi'] = strval(round($this->tools->grt->phi, 10));
		// CSS Features
		$vars['__bar'] = $vars['__bleed'] = true;
		$vars['__sidebar'] = false;
		$vars['__center-layout'] = true;
//		print_r($vars);
		return $vars;
	}

	protected function scss_mixins() {
		return array(
			'a' => array(
				'description' => 'Basic link styles',
				'path' => PM_THEME. '/scss/mixins/a.scss'),
			'bar' => array(
				'description' => 'Content bars: Whitespace out to the sides of the main column of text',
				'path' => PM_THEME. '/scss/mixins/bar.scss'),
			'bleed' => array(
				'description' => 'Full-width Bleeds for use within the main column of text',
				'path' => PM_THEME. '/scss/mixins/bleed.scss'),
			'button' => array(
				'description' => 'Base button styles',
				'path' => PM_THEME. '/scss/mixins/button.scss'),
			'button-action' => array(
				'description' => 'Action button styles',
				'path' => PM_THEME. '/scss/mixins/button-action.scss'),
			'button-save' => array(
				'description' => 'Save button styles',
				'path' => PM_THEME. '/scss/mixins/button-save.scss'),
			'button-delete' => array(
				'description' => 'Delete button styles',
				'path' => PM_THEME. '/scss/mixins/button-delete.scss'),
			'button-update' => array(
				'description' => 'Update button styles',
				'path' => PM_THEME. '/scss/mixins/button-update.scss'),
			'container' => array(
				'description' => 'Structural layout containers',
				'path' => PM_THEME. '/scss/mixins/container.scss'),
			'grt' => array(
				'description' => 'Golden Ratio Typography (GRT) base styles',
				'path' => PM_THEME. '/scss/mixins/grt.scss'),
			'grt-content' => array(
				'description' => 'Extended GRT content styles',
				'path' => PM_THEME. '/scss/mixins/grt-content.scss'),
			'grt-sidebar' => array(
				'description' => 'Sidebar GRT styles',
				'path' => PM_THEME. '/scss/mixins/grt-sidebar.scss'),
			'input' => array(
				'description' => 'Form input element styles',
				'path' => PM_THEME. '/scss/mixins/input.scss'),
			'menu' => array(
				'description' => 'Menu with horizontal scrolling adaptation for repsonsive design',
				'path' => PM_THEME. '/scss/mixins/menu-scroll-x.scss'),
			'site-title' => array(
				'description' => 'Site Title styles',
				'path' => PM_THEME. '/scss/mixins/site-title.scss'));
	}

	protected function scss_includes() {
		return array(
			'reset' => array(
				'name' => 'Reset',
				'path' => PM_THEME. '/scss/includes/reset.scss'),
			'body' => array(
				'name' => 'Body',
				'path' => PM_THEME. '/scss/includes/body.scss'),
			'formatting' => array(
				'name' => 'Text Formatting',
				'mixins' => array('a', 'grt-content'),
				'path' => PM_THEME. '/scss/includes/formatting.scss'),
			'form' => array(
				'name' => 'Forms',
				'mixins' => array('input', 'button', 'button-save', 'button-delete', 'button-action', 'button-update'),
				'path' => PM_THEME. '/scss/includes/form.scss'),
			'structure' => array(
				'name' => 'Layout Structure',
				'mixins' => array('container'),
				'path' => PM_THEME. '/scss/includes/structure.scss'),
			'elements' => array(
				'name' => 'Conditional Elements',
				'mixins' => array('site-title', 'menu', 'bar', 'bleed', 'grt-sidebar'),
				'path' => PM_THEME. '/scss/includes/elements.scss'),
			'modes' => array(
				'name' => 'Layout Modes',
				'path' => PM_THEME. '/scss/includes/modes.scss'));
	}

	protected function scss_includes_editor() {
		return array(
			'google-fonts' => array(
				'name' => 'Google Fonts',
				'path' => PM_THEME. '/scss/includes/google-fonts.scss'),
			'reset' => array(
				'name' => 'Reset',
				'path' => PM_THEME. '/scss/includes/reset.scss'),
			'body-editor' => array(
				'name' => 'Body (Editor)',
				'path' => PM_THEME. '/scss/includes/body-editor.scss'),
			'formatting-editor' => array(
				'name' => 'Text Formatting (Editor)',
				'mixins' => array('a'),
				'path' => PM_THEME. '/scss/includes/formatting-editor.scss'),
			'form' => array(
				'name' => 'Forms',
				'mixins' => array('input', 'button', 'button-save', 'button-delete', 'button-action', 'button-update'),
				'path' => PM_THEME. '/scss/includes/form.scss'),
			'elements-editor' => array(
				'name' => 'Bars and Bleeds',
				'mixins' => array('bar', 'bleed'),
				'path' => PM_THEME. '/scss/includes/elements-editor.scss'),
			'modes-editor' => array(
				'name' => 'Layout Modes (Editor)',
				'path' => PM_THEME. '/scss/includes/modes-editor.scss'));
	}
}