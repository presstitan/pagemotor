<?php
/**
 * PageMotor Tools
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Tools {
	public $form = false;
	public $box_form = false;
	public $files = false;
	public $svg = false;
	public $text = false;
	public $ui = false;
	public $date_format = 'F j, Y';

	public function __construct() {
		define('PM_TOOLS', PM_LIB. '/tools');
		require_once(PM_TOOLS. '/form.php');
		require_once(PM_TOOLS. '/box-form.php');
		require_once(PM_TOOLS. '/files.php');
		require_once(PM_TOOLS. '/svg.php');
		require_once(PM_TOOLS. '/text.php');
		require_once(PM_TOOLS. '/ui.php');
		require_once(PM_TOOLS. '/uploader.php');
		$this->form = new PM_Form;
		$this->files = new PM_Files;
		$this->svg = new PM_SVG;
		$this->text = new PM_Text;
		$this->ui = new PM_UI;
	}

	public function box_form() {
		return new PM_Box_Form;
	}

	public function date($date = false, $format = false) {
		return empty($date) ? false :
			date(!empty($format) ? $format : $this->date_format, strtotime($date));
	}

	public function remove_slashes($dir) {
		return rtrim(trim($dir, '/'), '/');
	}

/*
	Parse URL and return only the relative path. This is useful for "futureproofing" URLs
	against domain changes in the future.
	— $url: the URL to parse
*/
	public function url_relative($url = false) {
		global $motor;
		return empty($url) ? false :
			str_replace($motor->site_url, '', $url);
	}

/*
	Parse URLs and return a relative URL with the current site URL preprended.
	This method is useful for outputting saved URL data in a way that adapts the URL to the current domain.
	— $url: the saved URL to be 'currentized'
*/
	public function url_from_relative($url = false) {
		global $motor;
		return empty($url) ? false :
			(parse_url($url, PHP_URL_SCHEME) == NULL ?
				$motor->site_url. $url :
				$url);
	}

	public function write($filename, $content, $mode = 'w') {
		if (empty($filename) || empty($content))
			return;
		$r = fopen($filename, $mode);
		fwrite($r, $content);
		fclose($r);
	}

/*
	Operational method to sort a multi-dimensional associative array by a provided index.
	— $array: the multi-dimensional array to sort
	— $index: the array which will determine the sort order
	— $order: sort ordering, 'false' is a reverse sort (largest value comes first)
*/
	public function sort_by($array, $index, $order = false) {
		if (empty($array) || !is_array($array) || empty($index) || !is_string($index))
			return false;
		$sort_by = $remainder = $sorted = array();
		foreach ($array as $i => $item)
			if (isset($item[$index]) && !empty($item[$index]))
				$sort_by[$i] = $item[$index];
			else
				$remainder[$i] = $item;
		if (empty($order))
			arsort($sort_by);
		else
			asort($sort_by);
		foreach ($sort_by as $i => $item)
			$sorted[$i] = $array[$i];
		if (count($sorted) !== count($array))
			$sorted = $sorted + $remainder;
		return $sorted;
	}

	public function is_json($string) {
		json_decode($string);
		return json_last_error() === JSON_ERROR_NONE;
	}

/*
	Returns a space-separated string of sanitized HTML attributes.
	— $raw_attributes: 
*/
	public function sanitize_html_attributes($raw_attributes = false) {
		global $motor;
		if (empty($raw_attributes))
			return false;
		$raw_attributes = trim($raw_attributes);
		// Split attributes into groups.
		$attributes = array();
		$attribute_name = '';
		$in_attribute_value = false;
		$quote_char = '';
		$attribute_value = '';
		$attribute_finished = false;
		for ($i = 0; $i < strlen($raw_attributes); ++$i) {
			$chr = substr($raw_attributes, $i, 1);
			// Check if we're still building the attribute name.
			if (!$in_attribute_value) {
				if ($chr === '=')
					$in_attribute_value = true;
				else if (preg_match('/\s/', $chr))
					$attribute_finished = true; // A space character will terminate the attribute.
				else
					$attribute_name .= $chr; // Accumulate the value.
			}
			else {
				// First char encountered, if quote char, establishes quotation.
				if (($chr === '"' || $chr === '\'') && empty($attribute_value) && empty($quote_char))
					$quote_char = $chr;
				// If we encounter the same character later, it terminates the value.
				// Outside of quoted strings, whitespace terminates the value.
				else if ($chr === $quote_char || (empty($quote_char) && preg_match('/\s/', $chr)))
					$attribute_finished = true;
				else
					$attribute_value .= $chr; // Accumulate the value.
			}
			if ($i == strlen($raw_attributes) - 1)
				$attribute_finished = true;
			if ($attribute_finished) {
				$attribute_value = trim($attribute_value);
				// Attribute name are case-insensitive so make our comparisons easier.
				$attribute_name = strtolower(trim($attribute_name));
				// Check for invalid characters in the name.
				$valid_name = !empty($attribute_name) && !preg_match('/[\t\n\f \/>"\'=]/', $attribute_name);
				// Ensure no control codes. This is overly simplified and also
				// restricts extended-ASCII/UTF.
				$valid_name = $valid_name && preg_match('/^[ -~]+$/', $attribute_name);
				// Don't allow overriding attributes in a silly way that may expose
				// XSS vulnerabilities.
				$valid_name = $valid_name && !preg_match('/^(href|src)/', $attribute_name);
				// Don't allow JavaScript "on-" events, except for super admin (Site
				// Admin in MultiSite or admin in non-networked instances).
//				if (!is_super_admin())
//					$valid_name = $valid_name && substr($attribute_name, 0, 2) !== 'on';
				if ($valid_name)
					// HTML attributes can be standalone. Check $in_attribute_value to
					// see if assignment ever happened.
					$attributes[$attribute_name] = $in_attribute_value ?
						sprintf('%1$s="%2$s"', $attribute_name, $motor->text($attribute_value, 'escape-html')) :
						$attribute_name;
				// Reset everything in preparation for any future attributes.
				$quote_char = '';
				$attribute_name = '';
				$attribute_value = '';
				$in_attribute_value = false;
				$attribute_finished = false;
			}
		}
		return implode(' ', $attributes);
	}
}