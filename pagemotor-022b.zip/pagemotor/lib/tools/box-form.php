<?php
/**
 * PageMotor Box Form Helper
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Box_Form extends PM_Form {
	private $boxes = array();				// filtered array of box objects applicable to the current form
	private $active = array();				// array of all box ids that will be output in the active area of the current form
	private $add = array();					// array of box objects eligible to be added via the Add Box mechanism
	private $used = array();				// array used in queue output
	private $root_toggle = 'HTML_Head';		// ID of root Container that should include a toggle switch

	public function body($args = array()) {
		if (empty($args)) return;
		extract($args); // boxes, active, add, roots, depth
		$this->boxes = !empty($boxes) && is_array($boxes) ? $boxes : $this->boxes;
		$this->active = !empty($active) && is_array($active) ? $active : $this->active;
		$this->add = !empty($add) && is_array($add) ? $add : $this->add;
		$depth = !empty($depth) ? $depth : 0;
		$boxes = $this->boxes(!empty($roots) && is_array($roots) ? $roots : array(), $depth + 1);
		$tab = str_repeat("\t", $depth);
		return
			"$tab<div id=\"theme-boxes\" data-style=\"box\">\n".
			"$tab\t<div id=\"template-boxes\">\n".
			$boxes.
			"$tab\t</div>\n".
			"$tab\t<div id=\"box-management\">\n".
			$this->delete_boxes($depth + 2).
			$this->box_queue($depth + 2).
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

	public function boxes($roots, $depth = 0) {
		if (empty($roots))
			return false;
		$boxes = '';
		foreach ($roots as $root)
			if (!empty($this->boxes[$root]))
				$boxes .= $this->box($this->boxes[$root], $depth);
		return $boxes;
	}

	public function box($box, $depth) {
		global $motor;
		if (!is_object($box) || in_array($box->_id, $this->used) || $box->type === 'false')
			return;
		$tab = str_repeat("\t", $depth);
		$classes = $type = array();
		$root = $container = $sortable = $tray_boxes = $tray = '';
		$type = $box->type;
		$classes['draggable'] = 'draggable';
		if ($box->root) {
			$root = ' data-root="true"'. ($box->_id != $this->root_toggle ? ' data-root-show="true"' : false);
			$classes['root'] = 'box-root';
		}
		if ($box->head)
			$classes['head'] = 'box-head';
		if ($box->_parent) {
			$classes['parent'] = "parent-$box->_parent";
			$classes['child'] = "box-child";
		}
		if ($box->name)
			$classes['instance'] = 'instance';
		elseif ($box->type == 'box' && !$box->_parent)
			$classes['core'] = 'box-core';
		$classes = implode(' ', $classes);
		$title = $motor->text(($box->_lineage ? $box->_lineage : ''). ($box->name ? trim($box->name) : $box->title), 'inline-no-links');
		$settings = !empty($box->_html_options) ||
			(($box->head || (empty($box->head) && apply_filters('pm-form-box-options', false))) && !empty($box->_box_options)) ||
			!empty($box->_uploader) || !empty($box->_admin_options) ?
			$motor->tools->svg->icon('settings', $depth + 2, false, 'switch-options hidden') : false;
		$deletable = $box->name ? "<span class=\"deletable hidden\">[deletable]</span>\n" : false;
		$toggle = $box->type == 'container' && (!$box->root || ($box->root && $box->_id == $this->root_toggle)) ?
			"$tab\t\t<div class=\"toggle-box". ($box->_toggle ? ' toggled' : ''). " hidden\" data-style=\"toggle\" title=\"show/hide box contents\">\n".
			$motor->tools->svg->icon('plus-square', $depth + 3, false, 'toggle-on').
			$motor->tools->svg->icon('minus-square', $depth + 3, false, 'toggle-off').
			"$tab\t\t</div>\n" : false;
		if ($box->type == 'container') {
			$boxes = !empty($box->_boxes) ?
				$box->_boxes : (!empty($box->_startup) ?
				$box->_startup : array());
			foreach ($boxes as $item => $id)
				$sortable .= $this->box(!empty($this->boxes[$id]) ?
					$this->boxes[$id] : (!empty($box->_add_boxes[$id]) ?
					$box->_add_boxes[$id] : false), $depth + 2);
			if (!empty($box->_dependents)) {
				$children = !empty($boxes) ? array_diff($box->_dependents, $boxes) : $box->_dependents;
				foreach ($children as $child)
					if (!in_array($child, $this->active)) {
						$tray_boxes .= $this->box(!empty($this->boxes[$child]) ?
							$this->boxes[$child] : (!empty($box->_add_boxes[$child]) ?
							$box->_add_boxes[$child] : false), $depth + 3);
					}
				$tray =
					"$tab\t<div class=\"tray\">\n".
					"$tab\t\t<div class=\"tray-dropper\">Drop child boxes here to hide them in the tray</div>\n".
					"$tab\t\t<div class=\"tray-body\">\n".
					"$tab\t\t\t<p class=\"tray-instructions\">Click any box below to add it to the active area above</p>\n".
					"$tab\t\t\t<div class=\"tray-list\">\n".
					$tray_boxes.
					"$tab\t\t\t</div>\n".
					"$tab\t\t</div>\n".
					"$tab\t\t<div class=\"tray-bar\">\n".
					"$tab\t\t\t<span class=\"tray-control show-tray\">show tray &darr;</span>\n".
					"$tab\t\t\t<span class=\"tray-control hide-tray\">hide tray &uarr;</span>\n".
					"$tab\t\t</div>\n".
					"$tab\t</div>\n";
			}
			$container =
				"$tab\t<div class=\"sortable\">\n".
				$sortable.
				"$tab\t</div>\n".
				$tray;
		}
		$this->used[] = $box->_id;
		return
			"$tab<div data-id=\"$box->_id\"$root data-class=\"$box->_class\" data-type=\"$type\" class=\"$classes\">\n".
			"$tab\t<div id=\"$box->_id\" class=\"box-control\">\n".
			"$tab\t\t<div class=\"box-name\">$title</div>\n".
			$settings.
			$deletable.
			$toggle.
			"$tab\t</div>\n".
			$container.
			"$tab</div>\n".
			$this->options($box, $depth);
	}

	private function options($box, $depth) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$menu = $panes = array();
		$name = false;
		$type = $box->type == 'box' ? ($box->name ? 'instance' : (!$box->_parent ? 'box-core' : 'box')) : $box->type;
		if ($box->name)
			$name = array(
				'id' => "{$box->_class}_{$box->_id}-name",
				'name' => "{$box->_class}[$box->_id][_name]",
				'value' => $box->name);
		if (!empty($box->_uploader)) {
			$menu['uploader'] = 'Uploader';
			$panes['uploader'] = $this->fields($box->_uploader, array(), "{$box->_class}_{$box->_id}_", "{$box->_class}[$box->_id]", $depth + 4);
		}
		if (!empty($box->_html_options)) {
			$menu['html'] = 'HTML';
			$panes['html'] = $this->fields($box->_html_options, $box->box_options, "{$box->_class}_{$box->_id}_", "{$box->_class}[$box->_id]", $depth + 4);
		}
		if (($box->head || (empty($box->head) && apply_filters('pm-form-box-options', false))) && !empty($box->_box_options)) {
			$menu['options'] = 'Options';
			$panes['options'] = $this->fields($box->_box_options, $box->box_options, "{$box->_class}_{$box->_id}_", "{$box->_class}[$box->_id]", $depth + 4);
		}
		if (!empty($box->_admin_options)) {
			$menu['admin'] = 'Admin';
			$panes['admin'] = $this->fields($box->_admin_options, $box->box_options, "{$box->_class}_{$box->_id}_", "{$box->_class}[$box->_id]", $depth + 4);
		}
		return $motor->tools->ui->popup(array(
			'id' => $box->_id,
			'type' => $box->_parent ? "{$type}-child" : ($box->root ? 'box-root' : $type),
			'title' => ($box->_lineage ? $box->_lineage : ''). $box->title,
			'name' => $name,
			'menu' => $menu,
			'panes' => $panes,
			'depth' => $depth));
	}

	private function box_queue($depth) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$classes = array();
		$queue = array(
			'intro' => array(
				'' => 'Select a Box to add:'),
			'add' => array(),
			'unused' => array());
		if (!empty($this->add)) {
			foreach ($this->add as $class => $box)
				$classes[$class] = $motor->text($box->title, 'no-html');
			natcasesort($classes);
			foreach ($classes as $class => $title)
				$queue['add'][$class] = "* $title";
		}
		if (!empty($queue['add']))
			$queue['intro']['*'] = '* indicates a new Box instance';
		foreach ($this->boxes as $id => $box)
			if (!in_array($id, $this->used) && !$box->_parent)
				$queue['unused'][$id] = $motor->text(!empty($box->name) ? $box->name : $box->title, 'no-html');
		natcasesort($queue['unused']);
		$queue = array_merge($queue['intro'], $queue['add'], $queue['unused']);
		$add = $this->fields(array(
			'box-id' => array(
				'type' => 'select',
				'options' => $queue)), array(), false, false, $depth + 2);
		return
			"$tab<div id=\"box-queue\" class=\"box-manager\">\n".
			"$tab\t<div id=\"remove-boxes\" class=\"dropzone\"><kbd>shift</kbd> + drag boxes here to <strong>remove</strong> them from the template</div>\n".
			"$tab\t<div id=\"add-box-form\">\n".
			$add.
//			"$tab\t\t". wp_nonce_field('thesis-add-box', '_wpnonce-thesis-add-box', true, false). "\n".
			"$tab\t\t<button type=\"submit\" id=\"add-box\" class=\"action\" name=\"add_box\">\n".
			$motor->tools->svg->icon('plus-square', $depth + 3).
			"$tab\t\t\tAdd Box\n".
			"$tab\t\t</button>\n".
			"$tab\t</div>\n".
			"$tab\t<div class=\"sortable\">\n".
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

	private function delete_boxes($depth) {
		if (empty($this->add)) return;
		$tab = str_repeat("\t", $depth);
		return
			"$tab<div id=\"delete-boxes\" class=\"box-manager\">\n".
			"$tab\t<div class=\"dropzone\"><kbd>shift</kbd> + drag deletable boxes here to <strong>delete</strong> them on save</div>\n".
			"$tab\t<div class=\"delete-warning\"><strong>Warning:</strong> Deleted boxes will be removed from ALL templates!</div>\n".
			"$tab\t<div class=\"sortable\">\n".
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

	public function save($form) {
		if (!is_array($form))
			return false;
		$boxes = array();
		$containers = isset($form['boxes']) && is_array($form['boxes']) ? $form['boxes'] : array();
		$delete = isset($form['delete_boxes']) && is_array($form['delete_boxes']) ? $form['delete_boxes'] : array();
		foreach ($containers as $id => $inner_boxes)
			if (!in_array($id, $delete) && is_array($inner_boxes))
				$boxes[$id] = $inner_boxes;
		return array(
			'boxes' => $boxes,
			'delete' => !empty($delete) ? $delete : false);
	}
}