<?php
/**
 * PageMotor File Handler
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Files {
	public $headers = array(
		'name' => 'Name',
		'class' => 'Class',
		'type' => 'Type',
		'author' => 'Author',
		'description' => 'Description',
		'version' => 'Version',
		'requires' => 'Requires',
		'docs' => 'Docs',
		'changelog' => 'Changelog',
		'license' => 'License');
	public $bytes = 1024;
	public $perms = array(
		'files' => 0644,
		'dirs' => 0775);

	public function info($path, $type = 'theme') {
		if (empty($path) || !is_dir($path))
			return array();
		$items = array();
		$file = $type === 'theme' ? 'theme' : 'plugin';
		$directory = scandir($path);
		foreach ($directory as $dir) {
			if (in_array($dir, array('.', '..')) || strpos($dir, '.') === 0 || !is_dir("$path/$dir") || !file_exists("$path/$dir/$file.php"))
				continue;
			$item = $this->headers("$path/$dir/$file.php");
			$item['folder'] = $dir;
			$items[$item['class']] = $item;
		}
		return $items;
	}

	public function headers($file) {
		$data = file_get_contents($file, false, null, 0, 2 * $this->bytes);
		if ($data === false)
			$data = '';
		$detected = array();
		$data = str_replace("\r", "\n", $data);
		foreach ($this->headers as $type => $header)
			if (preg_match('/^(?:[ \t]*<\?php)?[ \t\/*#@]*'. preg_quote($header, '/'). ':(.*)$/mi', $data, $match) && $match[1])
				$detected[$type] = trim(preg_replace('/\s*(?:\*\/|\?>).*/', '', $match[1]));
			else
				$detected[$type] = '';
		return $detected;
	}

	public function copy_dir($source, $destination) {
		if (!is_dir($destination))
			if (!mkdir($destination, $this->perms['dirs'], true))
				return false;
		$files = scandir($source);
		foreach ($files as $file)
			if ($file !== '.' && $file !== '..') {
				if (is_dir("$source/$file")) {
					if (!$this->copy_dir("$source/$file", "$destination/$file"))
						return false;
				}
				else {
					if (!$this->copy("$source/$file", "$destination/$file", false, $this->perms['files']))
						return false;
				}
			}
		return true;
	}

	public function move($source, $destination, $overwrite = false) {
		if (!$overwrite && file_exists($destination))
			return false;
		if ($overwrite && file_exists($destination) && !$this->delete($destination, false, true))
			return false;
		if (rename($source, $destination))
			return true;
		if (is_file($source) && $this->copy($source, $destination, $overwrite) && file_exists($destination)) {
			$this->delete($source);
			return true;
		}
		else
			return false;
	}

	public function delete($file, $type = false, $recursive = false) {
		if (empty($file))
			return false;
		$file = str_replace('\\', '/', $file);
		if ($type === 'file' || is_file($file))
			return unlink($file);
		if (!$recursive && is_dir($file))
			return rmdir($file);
		$file = $this->trailing_slash($file);
		$files = $this->list_files($file);
		$delete = true;
		if (is_array($files))
			foreach ($files as $name => $info)
				if (!$this->delete($file. $name, $info['type'], $recursive))
					$delete = false;
		if (file_exists($file) && !rmdir($file))
			$delete = false;
		return $delete;
	}

	public function copy($source, $destination, $overwrite = false, $permissions = false) {
		if (!$overwrite && file_exists($destination))
			return false;
		$copy = copy($source, $destination);
		if ($permissions)
			$this->chmod($destination, $permissions);
		return $copy;
	}

	public function list_files($path, $hidden = true, $recursive = false) {
		if (is_file($path)) {
			$base = basename($path);
			$path = dirname($path);
		}
		else
			$base = false;
		if (!is_dir($path) || !is_readable($path))
			return false;
		$dir = dir($path);
		if (empty($dir))
			return false;
		$path = $this->trailing_slash($path);
		while (($file = $dir->read()) !== false) {
			$info = array();
			$info['name'] = $file;
			if ($info['name'] === '.' || $info['name'] === '..')
				continue;
			if (empty($hidden) && $info['name'][0] === '.')
				continue;
			if (!empty($base) && $info['name'] !== $base)
				continue;
			$info['perms'] = $this->get_chmod($path. $file);
			$info['permsn'] = $this->get_chmod_number($info['perms']);
			$info['number'] = false;
			$info['owner'] = $this->owner($path. $file);
			$info['group'] = $this->group($path. $file);
			$info['size'] = filesize($path. $file);
			$info['modified-unix'] = filemtime($path. $file);
			$info['modified'] = gmdate('M j', $info['modified-unix']);
			$info['time'] = gmdate('h:i:s', $info['modified-unix']);
			$info['type'] = is_dir($path. $file) ? 'dir' : 'file';
			if ($info['type'] === 'dir')
				$info['files'] = $recursive ? $this->list_files($path. $info['name'], $hidden, $recrusive) : array();
		}
		$dir->close();
		unset($dir);
		return array($info['name'] => $info);
	}

	public function get_chmod($file) {
		return substr(decoct(fileperms($file)), -3);
	}

	public function get_chmod_number($perms) {
		$actions = array('', 'w', 'r', 'x', '-');
		$convert = array(
			'-' => '0',
			'r' => '4',
			'w' => '2',
			'x' => '1');
		$perm_string = false;
		$permissions = preg_split('//', $perms);
		$count = count($permissions);
		for ($i = 0; $i < $count; $i++) {
			$key = array_search($permissions[$i], $actions, true);
			if ($key)
				$perm_string .= $actions[$key];
		}
		$perms = str_pad($perm_string, 10, '-', STR_PAD_LEFT);
		$perms = strtr($perms, $convert);
		return
			$perms[0]. ($perms[1] + $perms[2] + $perms[3]). ($perms[4] + $perms[5] + $perms[6]). ($perms[7] + $perms[8] + $perms[9]);
	}

	public function get_hex_chmod($file) {
		$perms = intval($this->chmod($file), 8);
		if (($perms & 0xC000) === 0xC000)			// socket
			$info = 's';
		elseif (($perms & 0xA000) === 0xA000) 		// symlink
			$info = 'l';
		elseif (($perms & 0x8000) === 0x8000)		// regular
			$info = '-';
		elseif (($perms & 0x6000) === 0x6000)		// block
			$info = 'b';
		elseif (($perms & 0x4000) === 0x4000)		// directory
			$info = 'd';
		elseif (($perms & 0x2000) === 0x2000)	 	// character
			$info = 'c';
		elseif (($perms & 0x1000) === 0x1000)		// pipe
			$info = 'p';
		else										// unknown
			$info = 'u';
		// owner
		$info .= (($perms & 0x0100) ? 'r' : '-');
		$info .= (($perms & 0x0080) ? 'w' : '-');
		$info .= (($perms & 0x0040) ?
			(($perms & 0x0800) ? 's' : 'x') :
			(($perms & 0x0800) ? 'S' : '-'));
		// group
		$info .= (($perms & 0x0020) ? 'r' : '-');
		$info .= (($perms & 0x0010) ? 'w' : '-');
		$info .= (($perms & 0x0008) ?
		(($perms & 0x0400) ? 's' : 'x') :
		(($perms & 0x0400) ? 'S' : '-'));
		// world
		$info .= (($perms & 0x0004) ? 'r' : '-');
		$info .= (($perms & 0x0002) ? 'w' : '-');
		$info .= (($perms & 0x0001) ?
			(($perms & 0x0200) ? 't' : 'x') :
			(($perms & 0x0200) ? 'T' : '-'));
		return $info;
	}

	public function chmod($file, $recursive = false) {
		$perms = is_file($file) ?
			$this->perms['files'] : (is_dir($file) ?
			$this->perms['dirs'] : false);
		if (!$perms)
			return false;
		if (!$recursive || !is_dir($file))
			return chmod($file, $perms);
		$file = $this->trailing_slash($file);
		$list = $this->list_files($file);
	}

	public function owner($file) {
		$id = fileowner($file);
		if (empty($id))
			return false;
		if (!function_exists('posix_getpwuid'))
			return $id;
		$owner = posix_getpwuid($id);
		if (empty($owner))
			return false;
		return
			$owner['name'];
	}

	public function group($file) {
		$id = filegroup($file);
		if (empty($id))
			return false;
		if (!function_exists('posix_getgrgid'))
			return $id;
		$group = posix_getgrgid($id);
		if (empty($group))
			return false;
		return
			$group['name'];
	}

	public function trailing_slash($path) {
		return rtrim($path, '/\\'). '/';
	}
}