<?php
/**
 * PageMotor Form and Options Tools
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Form {
	/**
	 * Generate form HTML from an array of options in Thesis Options API Array Format
	 * @param $fields: (array) option fields in Thesis Options API Array Format
	 * @param $values: (array) current options values
	 * @param $id_prefix: (string) ID prefix to add to resulting options
	 * @param $name_prefix: (string) name prefix to add to resulting options
	 * @param $depth: (int) starting HTML depth
	 * @see https://diythemes.com/thesis/rtfm/api/options/array-format/
	 * @return form HTML output
	 */
	public function fields($fields, $values = array(), $id_prefix = false, $name_prefix = false, $depth = 0) {
		$form_fields = false;
		if (empty($fields) || !is_array($fields))
			return $form_fields;
		foreach ($fields as $id => $field) {
			$field['id'] = $id;
			$form_field = $field['type'] == 'group' ?
				$this->field_group(
					$field,
					$values,
					$id_prefix,
					$name_prefix,
					$depth) :
			($field['type'] == 'custom' && !empty($field['html']) ?
				$this->field_custom(
					$field,
					$depth) :
				$this->field(
					$field,
					(!empty($id_prefix) ? $id_prefix. $id : $id),
					(!empty($name_prefix) ? "{$name_prefix}[{$id}]" : $id),
					(!empty($values[$id]) ? $values[$id] : false),
					$depth));
			$form_fields .= $form_field;
		}
		return $form_fields;
	}

	/**
	 * Generate option group HTML
	 * @param $field: (array) group options in Thesis Options API Array Format
	 * @param $values: (array) current options values
	 * @param $id_prefix: (string) ID prefix to add to resulting options
	 * @param $name_prefix: (string) name prefix to add to resulting options
	 * @param $depth: (int) starting HTML depth
	 * @see https://diythemes.com/thesis/rtfm/api/options/array-format/
	 * @return group HTML output
	 */
	public function field_group($field, $values = array(), $id_prefix = false, $name_prefix = false, $depth = 0) {
		global $motor;
		if (!is_array($field['fields']))
			return;
		$tab = str_repeat("\t", $depth);
		$class = 'option-item option-group'. (!empty($field['class']) ? ' '. $motor->text($field['class']) : ''). (!empty($field['parent']) ? $this->field_parent($field['parent']) : '');
		return
			"$tab<div class=\"$class\" id=\"group-{$field['id']}\">\n".
			(!empty($field['label']) ?
			"$tab\t<label>\n".
			"$tab\t\t{$field['label']}\n".
			"$tab\t\t<div class=\"toggle-group\">\n".
			$motor->tools->svg->icon('plus-square', $depth + 3, false, 'toggle-on').
			$motor->tools->svg->icon('minus-square', $depth + 3, false, 'toggle-off').
			"$tab\t\t</div>\n".
			"$tab\t</label>\n".
			"$tab\t<div class=\"group-fields\">\n" : '').
			(!empty($field['description']) ?
			"$tab\t\t<div class=\"option-item option-field group-description\">{$field['description']}</div>\n" : '').
			$this->fields($field['fields'], $values, $id_prefix, $name_prefix, $depth + 1).
			(!empty($field['label']) ?
			"$tab\t</div>\n" : '').
			"$tab</div>\n";
	}

	/**
	 * Generate HTML output for a custom option
	 * @param $field: (array) single option array in Thesis Options API Array Format (custom field only)
	 * @param $depth: (int) starting HTML depth
	 * @see https://diythemes.com/thesis/rtfm/api/options/array-format/
	 * @return custom option HTML output
	 */
	public function field_custom($field, $depth = 0) {
		global $motor;
		if (empty($field['html']))
			return;
		$tab = str_repeat("\t", $depth);
		$class = 'option-item option-custom'. (!empty($field['class']) ? ' '. $motor->text($field['class']) : ''). (!empty($field['parent']) ? $this->field_parent($field['parent']) : '');
		return
			"$tab<div class=\"$class\">\n".
			(!empty($field['label']) ?
			"\t<label>{$field['label']}</label>\n" : '').
			rtrim($field['html'], "\n"). "\n".
			"$tab</div>\n";
	}

	/**
	 * Include parent-dependent relationships in form HTML output
	 * @param $parent: (array) parent option for the current (dependent) option
	 * @return string for use in HTML class of dependent option
	 */
	public function field_parent($parent) {
		if (!is_array($parent)) return;
		$dependent = ' dependent';
		foreach ($parent as $option => $value) {
			$dependent .= " dependent-$option";
			if (is_array($value))
				foreach ($value as $dependent_value)
					$dependent .= " dependent-{$option}-$dependent_value";
			else
				$dependent .= " dependent-{$option}-$value";
		}
		return $dependent;
	}

	/**
	 * Generate HTML output for a single option field
	 * @param $field: (array) the current option field (Thesis Options API Array Format)
	 * @param $id: (string) HTML ID of the option input
	 * @param $name: (string) HTML name of the option input
	 * @param $value: (mixed) current option value
	 * @param $depth: (int) current HTML depth
	 * @see https://diythemes.com/thesis/rtfm/api/options/array-format/
	 * @return single option HTML output
	 */
	public function field($field, $id, $name, $value = false, $depth = 0) {
		global $motor;
		if (!(is_array($field) && $id && $name))
			return;
		// Set up basic field properties
		$tab = str_repeat("\t", $depth);
		$wrapper = $classes = array();
		$html = $required = $req = $tooltip = $tooltip_show = '';
		$wrapper['field'] = 'option-item option-field';
		if (!empty($field['dependents']) && is_array($field['dependents']))
			$wrapper['group'] = 'control-group';
		if (!empty($field['parent']) && $field['parent'])
			$wrapper['dependent'] = trim($this->field_parent($field['parent']));
		if (!empty($field['stack']) && $field['stack'])
			$wrapper['stack'] = 'stack';
		if (!empty($field['clear']) && $field['clear'])
			$wrapper['clear'] = 'clear-stack';
		if (!empty($field['item-class']))
			$wrapper['item-class'] = $motor->text($field['item-class']);
		$wrapper = !empty($wrapper) ? ' class="'. implode(' ', $wrapper). "\" id=\"field-$id\"" : '';
		if (!empty($field['required'])) {
			$required = " <span class=\"required\" title=\"required\">{$field['required']}</span>";
			$req = ' required';
		}
		if (!empty($field['tooltip'])) {
			$tooltip = "$tab\t<p class=\"tooltip\">{$field['tooltip']}</p>\n";
			$tooltip_show = $motor->tools->svg->icon('help-circle', $depth + 2, false, 'tooltip-show');
		}
		$placeholder = !empty($field['placeholder']) ? ' placeholder="'. $motor->text($field['placeholder'], 'no-html'). '"' : '';
		$readonly = !empty($field['readonly']) ? ' readonly="readonly"' : '';
		$value = !empty($field['readonly']) && !empty($field['default']) ?
			$field['default'] : (!!$value || !!strlen($value) ?
			$value : false);
		if ($field['type'] == 'checkbox')
			$classes['checkbox'] = 'checkboxes';
		elseif ($field['type'] == 'radio')
			$classes['radio'] = 'radio';
		if (!empty($field['multiple']))
			$classes['multiple'] = 'select-multiple';
		$classes = !empty($classes) ? ' class="'. implode(' ', $classes). '"' : '';
		// Begin field type output
		if ($field['type'] == 'hidden')
			$html = "$tab\t<input type=\"hidden\" class=\"hidden-input\" id=\"$id\" name=\"$name\" value=\"". $motor->text($value). "\">\n";
		elseif ($field['type'] == 'text') {
			$type = !empty($field['sub-type']) ? trim($field['sub-type']) : 'text';
			$class = ($type == 'password' ? ' password-input' : ''). (!empty($field['width']) ? " {$field['width']}" : ''). (!empty($field['counter']) ? ' count-field' : ''). (!empty($field['code']) ? ' code-input' : '');
			$html =
				(!empty($field['label']) ?
				"$tab\t<label for=\"$id\">\n".
				"$tab\t\t{$field['label']}$required\n".
				$tooltip_show.
				"$tab\t</label>\n" : '').
				"$tab\t<input type=\"$type\" class=\"text-input$class\" id=\"$id\" name=\"$name\" value=\"". $motor->text($value). "\"$placeholder$readonly$req>\n".
				(!empty($field['counter']) ?
				"$tab\t<input type=\"text\" readonly=\"readonly\" class=\"counter\" size=\"2\" maxlength=\"3\" value=\"0\">\n".
				"$tab\t<label class=\"counter-label\">{$field['counter']}</label>\n" : (!empty($field['description']) ?
				"$tab\t<span class=\"input-description\">{$field['description']}</span>\n" : ''));
		}
		elseif ($field['type'] == 'color') {
			$class = (!empty($field['width']) ? " {$field['width']}" : '');
			$html =
				(!empty($field['label']) ?
				"$tab\t<label for=\"$id\">\n".
				"$tab\t\t{$field['label']}$required\n".
				$tooltip_show.
				"$tab\t</label>\n" : '').
				"$tab\t<input type=\"text\" class=\"color$class {required:false,adjust:false,pickerPosition:'right'}\" id=\"$id\" name=\"$name\" value=\"". $motor->text($value). "\"$readonly>\n".
				(!empty($field['description']) ?
				"$tab\t<span class=\"input-description\">{$field['description']}</span>\n" : '');
		}
		elseif ($field['type'] == 'textarea') {
			$class = array();
			if (!empty($field['counter']))
				$class['counter'] = 'count-field';
			if (!empty($field['code']))
				$class['code'] = 'code-input';
			$class = !empty($class) ? ' class="'. implode(' ', $class). '"' : '';
			$html =
				(!empty($field['label']) ?
				"$tab\t<label for=\"$id\">\n".
				"$tab\t\t{$field['label']}$required\n".
				$tooltip_show.
				"$tab\t</label>\n" : '').
				"$tab\t<textarea id=\"$id\"$class name=\"$name\"". (!empty($field['rows']) && is_numeric($field['rows']) ? " rows=\"{$field['rows']}\"" : ''). "$req>$value</textarea>\n".
				(!empty($field['counter']) ?
				"$tab\t<input type=\"text\" readonly=\"readonly\" class=\"counter\" size=\"2\" maxlength=\"3\" value=\"0\">\n".
				"$tab\t<label class=\"counter-label\">{$field['counter']}</label>\n" : (!empty($field['description']) ?
				"$tab\t<span class=\"input-description\">{$field['description']}</span>\n" : ''));
		}
/*		elseif ($field['type'] == 'password') {
			$class = !empty($field['width']) ? " {$field['width']}" : '';
			$html =
				(!empty($field['label']) ?
				"$tab\t<label for=\"$id\">\n".
				"$tab\t\t{$field['label']}$required\n".
				$tooltip_show.
				"$tab\t</label>\n" : '').
				"$tab\t<input type=\"password\" class=\"text-input password$class\" id=\"$id\" name=\"$name\" value=\"". $motor->text($value). "\"$req>\n";
		}*/
		elseif (!empty($field['options'])) {
			$items = '';
			if ($field['type'] == 'checkbox') {
				$value = is_array($value) ? $value : array();
				foreach ($field['options'] as $option => $option_label) {
					$control = !empty($field['dependents']) && in_array($option, $field['dependents']) ?
						" class=\"control\" data-id=\"{$field['id']}-$option\"" : '';
					$checked = !empty($value[$option]) ? ' checked="checked"' : '';
					$items .=
						"$tab\t\t<li>\n".
						"$tab\t\t\t<input type=\"hidden\" name=\"{$name}[$option]\" value=\"0\">\n".
						"$tab\t\t\t<input type=\"checkbox\" id=\"{$id}-{$option}\"$control name=\"{$name}[$option]\" value=\"1\"$checked>\n".
						"$tab\t\t\t<label for=\"{$id}-{$option}\">$option_label</label>\n".
						"$tab\t\t</li>\n";
				}
				$html = (!empty($field['label']) ?
					"$tab\t<label class=\"list-label\">\n".
					"$tab\t\t{$field['label']}$required\n".
					$tooltip_show.
					"$tab\t</label>\n" : '').
					"$tab\t<ul$classes>\n".
					$items.
					"$tab\t</ul>\n";
			}
			elseif ($field['type'] == 'radio') {
				foreach ($field['options'] as $option_value => $option_label) {
					$control = !empty($field['dependents']) && in_array($option_value, $field['dependents']) ?
						" class=\"control\" data-id=\"{$field['id']}-$option_value\"" : '';
					$checked = isset($value) && $value == $option_value ? ' checked="checked"' : '';
					$items .=
						"$tab\t\t<li>\n".
						"$tab\t\t\t<input type=\"radio\" id=\"{$id}-{$option_value}\"$control name=\"$name\" value=\"$option_value\"$checked>\n".
						"$tab\t\t\t<label for=\"{$id}-{$option_value}\">$option_label</label>\n".
						"$tab\t\t</li>\n";
				}
				$html = (!empty($field['label']) ?
					"$tab\t<label class=\"list-label\">\n".
					"$tab\t\t{$field['label']}$required\n".
					$tooltip_show.
					"$tab\t</label>\n" : '').
					"$tab\t<ul$classes data-id=\"{$field['id']}\">\n".
					$items.
					"$tab\t</ul>\n";
			}
			elseif ($field['type'] == 'select') {
				// DO NOT attempt to use mutiple select elements at this time!
				$multiple = '';
				if (!empty($field['multiple'])) {
					$multiple = ' multiple="multiple"';
					$value = is_array($value) ? $value : array();
				}
				foreach ($field['options'] as $option_value => $option_text) {
					$control = !empty($field['dependents']) && in_array($option_value, $field['dependents']) ?
						" class=\"control\" data-id=\"{$field['id']}-$option_value\"" : '';
					$selected = $value == $option_value ? ' selected="selected"' : '';
					$items .=
						"$tab\t\t<option$control value=\"$option_value\"$selected>$option_text</option>\n";
				}
				$html =
					(!empty($field['label']) ?
					"$tab\t<label for=\"$id\">\n".
					"$tab\t\t{$field['label']}$required\n".
					$tooltip_show.
					"$tab\t</label>\n" : '').
					"$tab\t<select id=\"$id\"$classes name=\"$name\" data-id=\"{$field['id']}\" size=\"1\"$multiple>\n".
					$items.
					"$tab\t</select>\n".
					(!empty($field['description']) ?
					"$tab\t<span class=\"input-description\">{$field['description']}</span>\n" : '');
			}
		}
		return
			"$tab<div$wrapper>\n".
			$html.
			$tooltip.
			"$tab</div>\n";
	}
}