<?php
/**
 * PageMotor SVG Tools
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_SVG {
	private $stroke = 2;

	public function icon($icon, $depth = 0, $id = false, $class = false, $stroke = 2) {
		global $motor;
		if (empty($icon))
			return 'You must specify an SVG icon by name!';
		$tab = str_repeat("\t", $depth);
		$id = !empty($id) ? ' id="'. trim($motor->text($id)). '"' : '';
		$class = !empty($class) ? ' class="'. trim($motor->text($class)). '"' : ''; 
		$stroke = !is_numeric($stroke) ? $this->stroke : round($stroke, 1);
		$icons = apply_filters('pm-svg-icons', array(
			'arrow-up' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M12 19V6M5 12l7-7 7 7\" />\n".
				"$tab</svg>\n",
			'arrow-down' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M12 5v13M5 12l7 7 7-7\" />\n".
				"$tab</svg>\n",
			'arrow-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M19 12H6M12 5l-7 7 7 7\" />\n".
				"$tab</svg>\n",
			'arrow-right' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M5 12h13M12 5l7 7-7 7\" />\n".
				"$tab</svg>\n",
			'arrow-up-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M17 17L7.8 7.7M7 17V7h10\" />\n".
				"$tab</svg>\n",
			'arrow-up-right' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M7 17l9.2-9.2M17 17V7H7\" />\n".
				"$tab</svg>\n",
			'arrow-down-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M17 7l-9.2 9.2M7 7v10h10\" />\n".
				"$tab</svg>\n",
			'corner-down-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M10 9l-6 6 6 6\" />\n".
				"$tab\t<path d=\"M20 4v7a4 4 0 0 1-4 4H5\" />\n".
				"$tab</svg>\n",
			'corner-down-right' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M14 9l6 6-6 6\" />\n".
				"$tab\t<path d=\"M4 4v7a4 4 0 0 0 4 4h11\" />\n".
				"$tab</svg>\n",
			'corner-up-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M10 16l-6-6 6-6\" />\n".
				"$tab\t<path d=\"M20 21v-7a4 4 0 0 0-4-4H5\" />\n".
				"$tab</svg>\n",
			'corner-up-right' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M14 16l6-6-6-6\" />\n".
				"$tab\t<path d=\"M4 21v-7a4 4 0 0 1 4-4h11\" />\n".
				"$tab</svg>\n",
			'corner-left-down' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M15 14l-6 6-6-6\" />\n".
				"$tab\t<path d=\"M20 4h-7a4 4 0 0 0-4 4v11\" />\n".
				"$tab</svg>\n",
			'corner-left-up' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M15 10L9 4l-6 6\" />\n".
				"$tab\t<path d=\"M20 20h-7a4 4 0 0 1-4-4V5\" />\n".
				"$tab</svg>\n",
			'corner-right-down' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M9 14l6 6 6-6\" />\n".
				"$tab\t<path d=\"M4 4h7a4 4 0 0 1 4 4v11\" />\n".
				"$tab</svg>\n",
			'corner-right-up' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M9 10l6-6 6 6\" />\n".
				"$tab\t<path d=\"M4 20h7a4 4 0 0 0 4-4V5\" />\n".
				"$tab</svg>\n",
			'chevron-down' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M6 9l6 6 6-6\" />\n".
				"$tab</svg>\n",
			'chevron-up' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M18 15l-6-6-6 6\" />\n".
				"$tab</svg>\n",
			'chevron-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M15 18l-6-6 6-6\" />\n".
				"$tab</svg>\n",
			'chevron-right' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M9 18l6-6-6-6\" />\n".
				"$tab</svg>\n",
			'chevrons-down' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M7 13l5 5 5-5M7 6l5 5 5-5\" />\n".
				"$tab</svg>\n",
			'chevrons-up' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M17 11l-5-5-5 5M17 18l-5-5-5 5\" />\n".
				"$tab</svg>\n",
			'chevrons-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M11 17l-5-5 5-5M18 17l-5-5 5-5\" />\n".
				"$tab</svg>\n",
			'chevrons-right' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M13 17l5-5-5-5M6 17l5-5-5-5\" />\n".
				"$tab</svg>\n",
			'arrow-up-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<path d=\"M16 12l-4-4-4 4M12 16V9\" />\n".
				"$tab</svg>\n",
			'arrow-down-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<path d=\"M16 12l-4 4-4-4M12 8v7\" />\n".
				"$tab</svg>\n",
			'arrow-right-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<path d=\"M12 8l4 4-4 4M8 12h7\" />\n".
				"$tab</svg>\n",
			'arrow-left-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<path d=\"M12 8l-4 4 4 4M16 12H9\" />\n".
				"$tab</svg>\n",
			'refresh-ccw' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M2.5 2v6h6M21.5 22v-6h-6\"/>\n".
				"$tab\t<path d=\"M22 11.5A10 10 0 0 0 3.2 7.2M2 12.5a10 10 0 0 0 18.8 4.2\"/>\n".
				"$tab</svg>\n",
			'refresh-cw' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2\"/>\n".
				"$tab</svg>\n",
			'rotate-left' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M2.5 2v6h6M2.66 15.57a10 10 0 1 0 .57-8.38\"/>\n".
				"$tab</svg>\n",
			'arrow-in' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M13.8 12H3\"/>\n".
				"$tab</svg>\n",
			'arrow-out' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M10 3H6a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h4M16 17l5-5-5-5M19.8 12H9\"/>\n".
				"$tab</svg>\n",
			'upload' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M3 15v4c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-4M17 8l-5-5-5 5M12 4.2v10.3\" />\n".
				"$tab</svg>\n",
			'download' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M3 15v4c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2v-4M17 9l-5 5-5-5M12 12.8V2.5\" />\n".
				"$tab</svg>\n",
			'move' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M5.2 9l-3 3 3 3M9 5.2l3-3 3 3M15 18.9l-3 3-3-3M18.9 9l3 3-3 3M3.3 12h17.4M12 3.2v17.6\" />\n".
				"$tab</svg>\n",
			'external-link' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<g fill-rule=\"evenodd\">\n".
				"$tab\t\t<path d=\"M18 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8c0-1.1.9-2 2-2h5M15 3h6v6M10 14L20.2 3.8\" />\n".
				"$tab\t</g>\n".
				"$tab</svg>\n",
			'menu' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<line x1=\"3\" y1=\"12\" x2=\"21\" y2=\"12\" />\n".
				"$tab\t<line x1=\"3\" y1=\"6\" x2=\"21\" y2=\"6\" />\n".
				"$tab\t<line x1=\"3\" y1=\"18\" x2=\"21\" y2=\"18\" />\n".
				"$tab</svg>\n",
			'alert-triangle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z\" />\n".
				"$tab\t<line x1=\"12\" y1=\"9\" x2=\"12\" y2=\"13\" />\n".
				"$tab\t<line x1=\"12\" y1=\"17\" x2=\"12.01\" y2=\"17\" />\n".
				"$tab</svg>\n",
			'help-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<path d=\"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3\" />\n".
				"$tab\t<line x1=\"12\" y1=\"17\" x2=\"12.01\" y2=\"17\" />\n".
				"$tab</svg>\n",
			'info' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<line x1=\"12\" y1=\"16\" x2=\"12\" y2=\"12\" />\n".
				"$tab\t<line x1=\"12\" y1=\"8\" x2=\"12.01\" y2=\"8\" />\n".
				"$tab</svg>\n",
			'plus' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<line x1=\"12\" y1=\"5\" x2=\"12\" y2=\"19\"></line>\n".
				"$tab\t<line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line>\n".
				"$tab</svg>\n",
			'minus' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"></line>\n".
				"$tab</svg>\n",
			'x' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\" />\n".
				"$tab\t<line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\" />\n".
				"$tab</svg>\n",
			'plus-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"16\" />\n".
				"$tab\t<line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\" />\n".
				"$tab</svg>\n",
			'minus-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\" />\n".
				"$tab</svg>\n",
			'x-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<line x1=\"15\" y1=\"9\" x2=\"9\" y2=\"15\" />\n".
				"$tab\t<line x1=\"9\" y1=\"9\" x2=\"15\" y2=\"15\" />\n".
				"$tab</svg>\n",
			'plus-square' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M3 3h18v18H3zM12 8v8m-4-4h8\" />\n".
				"$tab</svg>\n",
			'minus-square' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M3 3h18v18H3zM8 12h8\" />\n".
				"$tab</svg>\n",
			'x-square' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M3 3h18v18H3zM15 9l-6 6m0-6l6 6\" />\n".
				"$tab</svg>\n",
			'check' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<polyline points=\"20 6 9 17 4 12\" />\n".
				"$tab</svg>\n",
			'check-2' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"square\">\n".
				"$tab\t<polyline points=\"20 6 9 17 4 12\" />\n".
				"$tab</svg>\n",
			'check-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M22 11.08V12a10 10 0 1 1-5.93-9.14\" />\n".
				"$tab\t<polyline points=\"22 4 12 14.01 9 11.01\" />\n".
				"$tab</svg>\n",
			'check-square' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<polyline points=\"9 11 12 14 22 4\" />\n".
				"$tab\t<path d=\"M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11\" />\n".
				"$tab</svg>\n",
			'slash' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<line x1=\"4.93\" y1=\"4.93\" x2=\"19.07\" y2=\"19.07\" />\n".
				"$tab</svg>\n",
			'more-horizontal' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"1\" />\n".
				"$tab\t<circle cx=\"19\" cy=\"12\" r=\"1\" />\n".
				"$tab\t<circle cx=\"5\" cy=\"12\" r=\"1\" />\n".
				"$tab</svg>\n",
			'more-vertical' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"1\" />\n".
				"$tab\t<circle cx=\"12\" cy=\"5\" r=\"1\" />\n".
				"$tab\t<circle cx=\"12\" cy=\"19\" r=\"1\" />\n".
				"$tab</svg>\n",
			'edit' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34\" />\n".
				"$tab\t<polygon points=\"18 2 22 6 12 16 8 16 8 12 18 2\" />\n".
				"$tab</svg>\n",
			'edit-2' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<polygon points=\"16 3 21 8 8 21 3 21 3 16 16 3\" />\n".
				"$tab</svg>\n",
			'edit-3' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<polygon points=\"14 2 18 6 7 17 3 17 3 13 14 2\" />\n".
				"$tab\t<line x1=\"3\" y1=\"22\" x2=\"21\" y2=\"22\" />\n".
				"$tab</svg>\n",
			'settings' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"3\" />\n".
				"$tab\t<path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z\" />\n".
				"$tab</svg>\n",
			'sliders' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<line x1=\"4\" y1=\"21\" x2=\"4\" y2=\"14\" />\n".
				"$tab\t<line x1=\"4\" y1=\"10\" x2=\"4\" y2=\"3\" />\n".
				"$tab\t<line x1=\"12\" y1=\"21\" x2=\"12\" y2=\"12\" />\n".
				"$tab\t<line x1=\"12\" y1=\"8\" x2=\"12\" y2=\"3\" />\n".
				"$tab\t<line x1=\"20\" y1=\"21\" x2=\"20\" y2=\"16\" />\n".
				"$tab\t<line x1=\"20\" y1=\"12\" x2=\"20\" y2=\"3\" />\n".
				"$tab\t<line x1=\"1\" y1=\"14\" x2=\"7\" y2=\"14\" />\n".
				"$tab\t<line x1=\"9\" y1=\"8\" x2=\"15\" y2=\"8\" />\n".
				"$tab\t<line x1=\"17\" y1=\"16\" x2=\"23\" y2=\"16\" />\n".
				"$tab</svg>\n",
			'search' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"11\" cy=\"11\" r=\"8\" />\n".
				"$tab\t<line x1=\"21\" y1=\"21\" x2=\"16.65\" y2=\"16.65\" />\n".
				"$tab</svg>\n",
			'clock' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab\t<polyline points=\"12 6 12 12 16 14\" />\n".
				"$tab</svg>\n",
			'eye' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z\"></path>\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"3\"></circle>\n".
				"$tab</svg>\n",
			'star' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<polygon points=\"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2\" />\n".
				"$tab</svg>\n",
			'heart' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z\" />\n".
				"$tab</svg>\n",
			'flag' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z\" />\n".
				"$tab\t<line x1=\"4\" y1=\"22\" x2=\"4\" y2=\"15\" />\n".
				"$tab</svg>\n",
			'message-square' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z\" />\n".
				"$tab</svg>\n",
			'trash' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<polyline points=\"3 6 5 6 21 6\" />\n".
				"$tab\t<path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\" />\n".
				"$tab\t<line x1=\"10\" y1=\"11\" x2=\"10\" y2=\"17\" />\n".
				"$tab\t<line x1=\"14\" y1=\"11\" x2=\"14\" y2=\"17\" />\n".
				"$tab</svg>\n",
			'thumbs-down' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17\" />\n".
				"$tab</svg>\n",
			'thumbs-up' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3\" />\n".
				"$tab</svg>\n",
			'mail' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M4 4H20C21.1046 4 22 4.89543 22 6V18C22 19.1046 21.1046 20 20 20H4C2.89543 20 2 19.1046 2 18V6C2 4.89543 2.89543 4 4 4Z\"/>\n".
				"$tab\t<path d=\"M22 7L12.8944 11.5528C12.3314 11.8343 11.6686 11.8343 11.1056 11.5528L2 7\"/>\n".
				"$tab</svg>\n",
			'shopping-bag' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M6 2L3 6v14c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2V6l-3-4H6zM3.8 6h16.4M16 10a4 4 0 1 1-8 0\"/>\n".
				"$tab</svg>\n",
			'home' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\" />\n".
				"$tab\t<polyline points=\"9 22 9 12 15 12 15 22\" />\n".
				"$tab</svg>\n",
			'video' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M15.6 11.6L22 7v10l-6.4-4.5v-1zM4 5h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7c0-1.1.9-2 2-2z\" />\n".
				"$tab</svg>\n",
			'camera' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<g transform=\"translate(2 3)\">\n".
				"$tab\t\t<path d=\"M20 16a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3l2-3h6l2 3h3a2 2 0 0 1 2 2v11z\" />\n".
				"$tab\t\t<circle cx=\"10\" cy=\"10\" r=\"4\" />\n".
				"$tab\t</g>\n".
				"$tab</svg>\n",
			'image' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"2\" />\n".
				"$tab\t<circle cx=\"8.5\" cy=\"8.5\" r=\"1.5\" />\n".
				"$tab\t<path d=\"M20.4 14.5L16 10 4 20\" />\n".
				"$tab</svg>\n",
			'file' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M13 2H6a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h12a2 2 0 0 0 2-2V9l-7-7z\" />\n".
				"$tab\t<path d=\"M13 3v6h6\" />\n".
				"$tab</svg>\n",
			'file-text' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M14 2H6a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h12a2 2 0 0 0 2-2V8l-6-6z\" />\n".
				"$tab\t<path d=\"M14 3v5h5M16 13H8M16 17H8M10 9H8\" />\n".
				"$tab</svg>\n",
			'file-plus-2' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M20 11.08V8l-6-6H6a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h6\"/>\n".
				"$tab\t<path d=\"M14 3v5h5M18 21v-6M15 18h6\"/>\n".
				"$tab</svg>\n",
			'file-x-2' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M20 11.08V8l-6-6H6a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h6\"/>\n".
				"$tab\t<path d=\"M14 3v5h5M15.88 20.12l4.24-4.24M15.88 15.88l4.24 4.24\"/>\n".
				"$tab</svg>\n",
			'folder' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z\" />\n".
				"$tab</svg>\n",
			'copy' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\" ry=\"2\"></rect>\n".
				"$tab\t<path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"></path>\n".
				"$tab</svg>\n",
			'delete' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"square\" stroke-linejoin=\"arcs\">\n".
				"$tab\t<path d=\"M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z\"></path>\n".
				"$tab\t<line x1=\"18\" y1=\"9\" x2=\"12\" y2=\"15\"></line>\n".
				"$tab\t<line x1=\"12\" y1=\"9\" x2=\"18\" y2=\"15\"></line>\n".
				"$tab</svg>\n",
			'user-circle' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M5.52 19c.64-2.2 1.84-3 3.22-3h6.52c1.38 0 2.58.8 3.22 3\" />\n".
				"$tab\t<circle cx=\"12\" cy=\"10\" r=\"3\" />\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"10\" />\n".
				"$tab</svg>\n",
			'plant' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M9.34882 11.1825C7.73784 12.3891 5.44323 12.26 3.9785 10.7953C1.55484 8.37164 2.03957 3.03957 2.03957 3.03957C2.03957 3.03957 7.37164 2.55484 9.7953 4.9785C10.7548 5.93803 11.1412 7.25369 10.9543 8.5\"/>\n".
				"$tab\t<path d=\"M14.9638 12.8175C13.644 11.3832 13.6797 9.14983 15.0708 7.75867C17.2252 5.6043 21.9648 6.03517 21.9648 6.03517C21.9648 6.03517 22.3957 10.7748 20.2413 12.9292C19.4877 13.6828 18.487 14.0386 17.5 13.9967\"/>\n".
				"$tab\t<path d=\"M18 10C18 10 12 14 12 21C12 12 6 7 6 7\"/>\n".
				"$tab</svg>\n",
/*			'nano' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M5 16L10 13M14 11L19 8M12 5V10M12 14V19M5 8L10 11M14 13L19 16\"/>\n".
				"$tab\t<path d=\"M20.5 9.00001V14.5M13.5 20.5L19 17.5M4.5 17.5L10.5 20.5M3.5 15V9.00001M4.5 6.5L10.5 3.5M19.5 6.5L13.5 3.5\"/>\n".
				"$tab\t<circle cx=\"12\" cy=\"3.5\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"12\" cy=\"20.5\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"3.5\" cy=\"7.5\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"20.5\" cy=\"7.5\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"20.5\" cy=\"16.5\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"3.5\" cy=\"16.5\" r=\"1.5\"/>\n".
				"$tab\t<path d=\"M12 9.75L14 10.875V13.125L12 14.25L10 13.125V10.875L12 9.75Z\"/>\n".
				"$tab</svg>\n",*/
			'pagemotor' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill=\"none\" stroke-width=\"$stroke\" stroke-linejoin=\"round\">\n".
				"$tab\t<path d=\"M6.371 15.25L9.835 13.25M14.165 10.75L17.629 8.75M12 5.5V9.5M12 14.5V18.5M6.371 8.75L9.835 10.75M14.165 13.25L17.629 15.25\"/>\n".
				"$tab\t<path d=\"M13.299 4.75L17.629 7.25M18.928 9.5L18.928 14.5M17.629 16.75L13.299 19.25M10.701 19.25L6.371 16.75M5.072 14.5L5.072 9.5M6.371 7.25L10.701 4.75\"/>\n".
				"$tab\t<circle cx=\"5.072\" cy=\"8\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"5.072\" cy=\"16\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"12\" cy=\"4\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"12\" cy=\"20\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"18.928\" cy=\"8\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"18.928\" cy=\"16\" r=\"1.5\"/>\n".
				"$tab\t<circle cx=\"12\" cy=\"12\" r=\"2.5\"/>\n".
				"$tab</svg>\n",
			'bitcoin' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M11 24v-3.022h-1v3.022h-2v-3.022h-4.969l.5-2.978h1.079c.884 0 1.39-.851 1.39-1.707v-8.889c0-.833-.485-1.404-1.365-1.404h-1.635v-3h5v-3h2v3h1v-3h2v3.053c4.315.146 6.024 1.781 6.514 3.625.58 2.18-.857 4.01-2.093 4.456 1.501.382 3.579 1.491 3.579 4.05 0 3.483-2.688 5.816-8 5.816v3h-2zm-1-11.006v5.006c3.969 0 6.688-.375 6.688-2.516 0-2.296-2.938-2.49-6.688-2.49zm0-1.994c2.211 0 5.578-.156 5.578-2.5 0-2-2.078-2.5-5.578-2.5v5z\" />\n".
				"$tab</svg>\n",
			'github' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z\" />\n".
				"$tab</svg>\n",
			'facebook' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M24 12.07C24 5.41 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.04V9.41c0-3.02 1.8-4.7 4.54-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.5c-1.5 0-1.96.93-1.96 1.89v2.26h3.32l-.53 3.5h-2.8V24C19.62 23.1 24 18.1 24 12.07\" />\n".
				"$tab</svg>\n",
			'twitter' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M24 4.37a9.6 9.6 0 0 1-2.83.8 5.04 5.04 0 0 0 2.17-2.8c-.95.58-2 1-3.13 1.22A4.86 4.86 0 0 0 16.61 2a4.99 4.99 0 0 0-4.79 6.2A13.87 13.87 0 0 1 1.67 2.92 5.12 5.12 0 0 0 3.2 9.67a4.82 4.82 0 0 1-2.23-.64v.07c0 2.44 1.7 4.48 3.95 4.95a4.84 4.84 0 0 1-2.22.08c.63 2.01 2.45 3.47 4.6 3.51A9.72 9.72 0 0 1 0 19.74 13.68 13.68 0 0 0 7.55 22c9.06 0 14-7.7 14-14.37v-.65c.96-.71 1.79-1.6 2.45-2.61z\" />\n".
				"$tab</svg>\n",
			'x-twitter' =>
				"$tab<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z\" />\n".
				"$tab</svg>\n",
			'instagram' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M16.98 0a6.9 6.9 0 0 1 5.08 1.98A6.94 6.94 0 0 1 24 7.02v9.96c0 2.08-.68 3.87-1.98 5.13A7.14 7.14 0 0 1 16.94 24H7.06a7.06 7.06 0 0 1-5.03-1.89A6.96 6.96 0 0 1 0 16.94V7.02C0 2.8 2.8 0 7.02 0h9.96zm.05 2.23H7.06c-1.45 0-2.7.43-3.53 1.25a4.82 4.82 0 0 0-1.3 3.54v9.92c0 1.5.43 2.7 1.3 3.58a5 5 0 0 0 3.53 1.25h9.88a5 5 0 0 0 3.53-1.25 4.73 4.73 0 0 0 1.4-3.54V7.02a5 5 0 0 0-1.3-3.49 4.82 4.82 0 0 0-3.54-1.3zM12 5.76c3.39 0 6.2 2.8 6.2 6.2a6.2 6.2 0 0 1-12.4 0 6.2 6.2 0 0 1 6.2-6.2zm0 2.22a3.99 3.99 0 0 0-3.97 3.97A3.99 3.99 0 0 0 12 15.92a3.99 3.99 0 0 0 3.97-3.97A3.99 3.99 0 0 0 12 7.98zm6.44-3.77a1.4 1.4 0 1 1 0 2.8 1.4 1.4 0 0 1 0-2.8z\" />\n".
				"$tab</svg>\n",
			'youtube' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M12.04 3.5c.59 0 7.54.02 9.34.5a3.02 3.02 0 0 1 2.12 2.15C24 8.05 24 12 24 12v.04c0 .43-.03 4.03-.5 5.8A3.02 3.02 0 0 1 21.38 20c-1.76.48-8.45.5-9.3.51h-.17c-.85 0-7.54-.03-9.29-.5A3.02 3.02 0 0 1 .5 17.84c-.42-1.61-.49-4.7-.5-5.6v-.5c.01-.9.08-3.99.5-5.6a3.02 3.02 0 0 1 2.12-2.14c1.8-.49 8.75-.51 9.34-.51zM9.54 8.4v7.18L15.82 12 9.54 8.41z\" />\n".
				"$tab</svg>\n",
			'reddit' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M24 11.779c0-1.459-1.192-2.645-2.657-2.645-.715 0-1.363.286-1.84.746-1.81-1.191-4.259-1.949-6.971-2.046l1.483-4.669 4.016.941-.006.058c0 1.193.975 2.163 2.174 2.163 1.198 0 2.172-.97 2.172-2.163s-.975-2.164-2.172-2.164c-.92 0-1.704.574-2.021 1.379l-4.329-1.015c-.189-.046-.381.063-.44.249l-1.654 5.207c-2.838.034-5.409.798-7.3 2.025-.474-.438-1.103-.712-1.799-.712-1.465 0-2.656 1.187-2.656 2.646 0 .97.533 1.811 1.317 2.271-.052.282-.086.567-.086.857 0 3.911 4.808 7.093 10.719 7.093s10.72-3.182 10.72-7.093c0-.274-.029-.544-.075-.81.832-.447 1.405-1.312 1.405-2.318zm-17.224 1.816c0-.868.71-1.575 1.582-1.575.872 0 1.581.707 1.581 1.575s-.709 1.574-1.581 1.574-1.582-.706-1.582-1.574zm9.061 4.669c-.797.793-2.048 1.179-3.824 1.179l-.013-.003-.013.003c-1.777 0-3.028-.386-3.824-1.179-.145-.144-.145-.379 0-.523.145-.145.381-.145.526 0 .65.647 1.729.961 3.298.961l.013.003.013-.003c1.569 0 2.648-.315 3.298-.962.145-.145.381-.144.526 0 .145.145.145.379 0 .524zm-.189-3.095c-.872 0-1.581-.706-1.581-1.574 0-.868.709-1.575 1.581-1.575s1.581.707 1.581 1.575-.709 1.574-1.581 1.574z\" />\n".
				"$tab</svg>\n",
			'medium' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M2.846 6.887c.03-.295-.083-.586-.303-.784l-2.24-2.7v-.403h6.958l5.378 11.795 4.728-11.795h6.633v.403l-1.916 1.837c-.165.126-.247.333-.213.538v13.498c-.034.204.048.411.213.537l1.871 1.837v.403h-9.412v-.403l1.939-1.882c.19-.19.19-.246.19-.537v-10.91l-5.389 13.688h-.728l-6.275-13.688v9.174c-.052.385.076.774.347 1.052l2.521 3.058v.404h-7.148v-.404l2.521-3.058c.27-.279.39-.67.325-1.052v-10.608z\" />\n".
				"$tab</svg>\n",
			'patreon' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M15.386.524c-4.764 0-8.64 3.876-8.64 8.64 0 4.75 3.876 8.613 8.64 8.613 4.75 0 8.614-3.864 8.614-8.613C24 4.4 20.136.524 15.386.524M.003 23.537h4.22V.524H.003\" />\n".
				"$tab</svg>\n",
			'paypal' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M22 9.761c0 .536-.065 1.084-.169 1.627-.847 4.419-3.746 5.946-7.449 5.946h-.572c-.453 0-.838.334-.908.789l-.803 5.09c-.071.453-.456.787-.908.787h-2.736c-.39 0-.688-.348-.628-.732l1.386-8.88.062-.056h2.155c5.235 0 8.509-2.618 9.473-7.568.812.814 1.097 1.876 1.097 2.997zm-14.216 4.252c.116-.826.459-1.177 1.385-1.179l2.26-.002c4.574 0 7.198-2.09 8.023-6.39.8-4.134-2.102-6.442-6.031-6.442h-7.344c-.517 0-.958.382-1.038.901-2.304 14.835-2.97 18.607-3.038 19.758-.021.362.269.672.635.672h3.989l1.159-7.318z\" />\n".
				"$tab</svg>\n",
			'dribbble' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M23.76 9.58A11.99 11.99 0 0 0 0 12a12.08 12.08 0 0 0 3.51 8.49 12.12 12.12 0 0 0 6.07 3.27A11.99 11.99 0 0 0 24 12a12 12 0 0 0-.24-2.42zm-1.51 2.32c-.15-.03-3.62-.78-7.14-.34a38.64 38.64 0 0 0-.9-2.01c4.04-1.66 5.69-4.03 5.7-4.06a10.2 10.2 0 0 1 2.34 6.4zm-3.48-7.6c-.03.05-1.49 2.27-5.35 3.72a52.06 52.06 0 0 0-3.83-5.98 10.23 10.23 0 0 1 9.18 2.27zM7.63 2.74a61.6 61.6 0 0 1 3.8 5.9A37.91 37.91 0 0 1 1.97 9.9c.67-3.18 2.8-5.8 5.66-7.16zM1.75 12l.01-.32c.18 0 5.25.11 10.52-1.46.3.57.58 1.15.83 1.74l-.4.12c-5.53 1.79-8.34 6.76-8.34 6.76A10.21 10.21 0 0 1 1.76 12zM12 22.25a10.2 10.2 0 0 1-6.53-2.35l.23.18s1.97-4.29 8.04-6.4l.07-.02a42.64 42.64 0 0 1 2.2 7.78 10.2 10.2 0 0 1-4.01.8zm5.73-1.75c-.1-.62-.65-3.63-2-7.32 3.31-.53 6.18.38 6.39.45a10.26 10.26 0 0 1-4.4 6.87z\" />\n".
				"$tab</svg>\n",
			'spotify' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M12 0a12 12 0 1 0 0 24 12 12 0 0 0 0-24zm4.87 17.66c-.2 0-.33-.06-.51-.18a12.03 12.03 0 0 0-6.2-1.6c-1.3 0-2.59.16-3.8.42-.19.04-.44.11-.59.11a.75.75 0 0 1-.75-.75c0-.5.29-.75.65-.82 1.48-.34 2.96-.53 4.49-.53 2.62 0 4.97.6 6.98 1.8.3.18.47.36.47.8 0 .43-.35.75-.74.75zm1.3-3.17c-.25 0-.42-.1-.6-.21a15.22 15.22 0 0 0-7.62-1.93c-1.51 0-2.83.21-3.91.5-.24.07-.37.14-.59.14a.94.94 0 0 1-.93-.95c0-.5.24-.86.74-1C6.61 10.67 8 10.4 10 10.4c3.15 0 6.18.78 8.57 2.2.4.24.55.53.55.96 0 .52-.41.94-.93.94zm1.5-3.7c-.25 0-.4-.06-.62-.18-2.18-1.3-5.55-2.02-8.8-2.02-1.63 0-3.29.16-4.8.57-.17.05-.4.14-.62.14-.64 0-1.13-.51-1.13-1.15 0-.65.4-1.02.84-1.15 1.71-.5 3.62-.74 5.7-.74 3.52 0 7.23.73 9.94 2.32.36.2.62.52.62 1.09 0 .65-.53 1.12-1.14 1.12z\" />\n".
				"$tab</svg>\n",
			'linkedin' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M22.23 0H1.77C.8 0 0 .77 0 1.72v20.56C0 23.23.8 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.72V1.72C24 .77 23.2 0 22.23 0zM7.27 20.1H3.65V9.24h3.62V20.1zM5.47 7.76h-.03c-1.22 0-2-.83-2-1.87 0-1.06.8-1.87 2.05-1.87 1.24 0 2 .8 2.02 1.87 0 1.04-.78 1.87-2.05 1.87zM20.34 20.1h-3.63v-5.8c0-1.45-.52-2.45-1.83-2.45-1 0-1.6.67-1.87 1.32-.1.23-.11.55-.11.88v6.05H9.28s.05-9.82 0-10.84h3.63v1.54a3.6 3.6 0 0 1 3.26-1.8c2.39 0 4.18 1.56 4.18 4.89v6.21z\" />\n".
				"$tab</svg>\n",
			'pinterest' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M12 0a12 12 0 0 0-4.82 23c-.03-.85 0-1.85.21-2.76l1.55-6.54s-.39-.77-.39-1.9c0-1.78 1.03-3.1 2.32-3.1 1.09 0 1.62.81 1.62 1.8 0 1.09-.7 2.73-1.06 4.25-.3 1.27.63 2.31 1.89 2.31 2.27 0 3.8-2.92 3.8-6.38 0-2.63-1.77-4.6-4.99-4.6a5.68 5.68 0 0 0-5.9 5.75c0 1.05.3 1.78.78 2.35.23.27.26.37.18.67l-.25.97c-.08.3-.32.4-.6.3-1.67-.69-2.46-2.52-2.46-4.59 0-3.4 2.88-7.5 8.58-7.5 4.58 0 7.6 3.32 7.6 6.88 0 4.7-2.62 8.22-6.48 8.22-1.3 0-2.51-.7-2.93-1.5l-.84 3.3c-.26.93-.76 1.86-1.21 2.58A11.99 11.99 0 0 0 24 12 12 12 0 0 0 12 0z\" />\n".
				"$tab</svg>\n",
			'slack' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M22.672 15.226l-2.432.811.841 2.515c.33 1.019-.209 2.127-1.23 2.456-1.15.325-2.148-.321-2.463-1.226l-.84-2.518-5.013 1.677.84 2.517c.391 1.203-.434 2.542-1.831 2.542-.88 0-1.601-.564-1.86-1.314l-.842-2.516-2.431.809c-1.135.328-2.145-.317-2.463-1.229-.329-1.018.211-2.127 1.231-2.456l2.432-.809-1.621-4.823-2.432.808c-1.355.384-2.558-.59-2.558-1.839 0-.817.509-1.582 1.327-1.846l2.433-.809-.842-2.515c-.33-1.02.211-2.129 1.232-2.458 1.02-.329 2.13.209 2.461 1.229l.842 2.515 5.011-1.677-.839-2.517c-.403-1.238.484-2.553 1.843-2.553.819 0 1.585.509 1.85 1.326l.841 2.517 2.431-.81c1.02-.33 2.131.211 2.461 1.229.332 1.018-.21 2.126-1.23 2.456l-2.433.809 1.622 4.823 2.433-.809c1.242-.401 2.557.484 2.557 1.838 0 .819-.51 1.583-1.328 1.847m-8.992-6.428l-5.01 1.675 1.619 4.828 5.011-1.674-1.62-4.829z\" />\n".
				"$tab</svg>\n",
			'snapchat' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M12.15 23.5h-.3c-1.42 0-2.34-.66-3.22-1.3-.6-.44-1.18-.85-1.86-.97a5.9 5.9 0 0 0-.98-.08c-.57 0-1.02.1-1.35.16-.2.04-.38.07-.5.07-.15 0-.3-.03-.36-.25-.05-.2-.1-.39-.13-.57-.1-.47-.18-.76-.37-.8-2.26-.35-2.9-.84-3.04-1.18a.45.45 0 0 1-.04-.15c0-.13.08-.25.21-.27 3.47-.58 5.02-4.2 5.09-4.35v-.01c.22-.44.26-.82.13-1.14-.24-.57-1.02-.82-1.53-.99l-.34-.11c-1.02-.42-1.1-.84-1.07-1.06.07-.37.55-.62.94-.62.11 0 .2.02.28.05.47.22.88.34 1.24.34.5 0 .71-.22.74-.24l-.05-.75c-.1-1.68-.23-3.75.29-4.94A6.25 6.25 0 0 1 11.75.5h.49c.97 0 4.27.28 5.83 3.84.52 1.18.39 3.26.29 4.94v.07l-.05.68c.03.02.23.22.68.23.34 0 .73-.12 1.16-.33a.86.86 0 0 1 .36-.07c.15 0 .3.03.42.08.35.13.58.38.59.64 0 .25-.18.61-1.08.98l-.34.11c-.51.17-1.29.42-1.53 1-.13.3-.09.69.13 1.13.07.16 1.62 3.78 5.09 4.36.13.02.22.14.21.27 0 .05-.02.1-.04.15-.14.34-.78.83-3.04 1.18-.18.03-.26.28-.37.8a8.1 8.1 0 0 1-.13.56c-.05.16-.15.24-.32.24h-.03c-.12 0-.3-.02-.5-.06a6.6 6.6 0 0 0-2.34-.07c-.68.12-1.25.53-1.86.97-.88.64-1.8 1.3-3.22 1.3z\" />\n".
				"$tab</svg>\n",
			'vimeo' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M22.875 10.063c-2.442 5.217-8.337 12.319-12.063 12.319-3.672 0-4.203-7.831-6.208-13.043-.987-2.565-1.624-1.976-3.474-.681l-1.128-1.455c2.698-2.372 5.398-5.127 7.057-5.28 1.868-.179 3.018 1.098 3.448 3.832.568 3.593 1.362 9.17 2.748 9.17 1.08 0 3.741-4.424 3.878-6.006.243-2.316-1.703-2.386-3.392-1.663 2.673-8.754 13.793-7.142 9.134 2.807z\" />\n".
				"$tab</svg>\n",
			'whatsapp' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M24 11.7c0 6.45-5.27 11.68-11.78 11.68-2.07 0-4-.53-5.7-1.45L0 24l2.13-6.27a11.57 11.57 0 0 1-1.7-6.04C.44 5.23 5.72 0 12.23 0 18.72 0 24 5.23 24 11.7M12.22 1.85c-5.46 0-9.9 4.41-9.9 9.83 0 2.15.7 4.14 1.88 5.76L2.96 21.1l3.8-1.2a9.9 9.9 0 0 0 5.46 1.62c5.46 0 9.9-4.4 9.9-9.83a9.88 9.88 0 0 0-9.9-9.83m5.95 12.52c-.08-.12-.27-.19-.56-.33-.28-.14-1.7-.84-1.97-.93-.26-.1-.46-.15-.65.14-.2.29-.75.93-.91 1.12-.17.2-.34.22-.63.08-.29-.15-1.22-.45-2.32-1.43a8.64 8.64 0 0 1-1.6-1.98c-.18-.29-.03-.44.12-.58.13-.13.29-.34.43-.5.15-.17.2-.3.29-.48.1-.2.05-.36-.02-.5-.08-.15-.65-1.56-.9-2.13-.24-.58-.48-.48-.64-.48-.17 0-.37-.03-.56-.03-.2 0-.5.08-.77.36-.26.29-1 .98-1 2.4 0 1.4 1.03 2.76 1.17 2.96.14.19 2 3.17 4.93 4.32 2.94 1.15 2.94.77 3.47.72.53-.05 1.7-.7 1.95-1.36.24-.67.24-1.25.17-1.37\" />\n".
				"$tab</svg>\n",
			'soundcloud' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M1.16 16.86c.05 0 .1-.04.1-.1l.27-2.1-.27-2.16c0-.05-.05-.1-.1-.1s-.1.05-.1.1l-.24 2.16.24 2.1c0 .06.05.1.1.1zm-.89-.8c.05 0 .09-.04.1-.09l.2-1.31-.2-1.33c-.01-.06-.05-.1-.1-.1s-.09.04-.1.1L0 14.66l.18 1.31c0 .05.04.1.1.1zm1.95-3.96c0-.07-.06-.12-.12-.12s-.11.05-.12.12l-.22 2.56.22 2.46c0 .07.06.12.12.12s.11-.05.12-.11l.26-2.47-.26-2.56zm.83 5.24c.08 0 .14-.06.14-.14l.24-2.54-.24-2.63c0-.08-.06-.14-.14-.14a.14.14 0 0 0-.14.14l-.21 2.63.21 2.54c0 .08.07.14.14.14zm.96.04c.09 0 .16-.07.16-.16l.23-2.56-.23-2.44c0-.09-.07-.16-.16-.16a.16.16 0 0 0-.16.16l-.2 2.44.2 2.56c0 .1.07.16.16.16zm1.36-2.72l-.21-3.96c0-.1-.09-.18-.18-.18-.1 0-.18.07-.19.18l-.18 3.96.18 2.56c.01.1.09.18.19.18s.17-.08.18-.18l.21-2.56zm.58 2.75c.1 0 .2-.09.2-.2l.2-2.55-.2-4.87a.2.2 0 0 0-.2-.2.2.2 0 0 0-.2.2l-.18 4.87.18 2.55c0 .11.1.2.2.2zm.98-8.25c-.12 0-.22.1-.22.22l-.16 5.28.16 2.52c0 .13.1.22.22.22s.22-.1.22-.22l.19-2.52-.19-5.28c0-.12-.1-.22-.22-.22zm1 8.25c.12 0 .23-.1.23-.24l.17-2.5-.17-5.46a.24.24 0 0 0-.24-.25c-.13 0-.24.11-.24.25l-.15 5.45.15 2.5c0 .14.1.25.24.25zm.99 0c.14 0 .26-.12.26-.27l.16-2.48-.16-5.32a.26.26 0 0 0-.26-.26.26.26 0 0 0-.27.26l-.13 5.32.13 2.48c0 .15.12.27.27.27zm1.43-2.75l-.14-5.12a.29.29 0 0 0-.29-.28.29.29 0 0 0-.28.28l-.13 5.12.13 2.47a.28.28 0 0 0 .57 0l.14-2.47zm.59 2.76a.3.3 0 0 0 .3-.3l.13-2.46-.13-6.1a.3.3 0 0 0-.3-.3.3.3 0 0 0-.3.3l-.12 6.1.11 2.45c0 .17.14.3.3.3zm1-9.73a.33.33 0 0 0-.32.33l-.14 6.64.14 2.42c0 .17.15.32.32.32.18 0 .33-.15.33-.32l.14-2.42-.14-6.64a.33.33 0 0 0-.33-.33zm.93 9.73h8.18a2.95 2.95 0 1 0-1.14-5.67 5.2 5.2 0 0 0-7.08-4.4c-.22.09-.28.18-.28.35v9.37c0 .18.14.33.32.35z\" />\n".
				"$tab</svg>\n",
			'telegram' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\" fill-rule=\"evenodd\">\n".
				"$tab\t<path d=\"M18.384,22.779c0.322,0.228 0.737,0.285 1.107,0.145c0.37,-0.141 0.642,-0.457 0.724,-0.84c0.869,-4.084 2.977,-14.421 3.768,-18.136c0.06,-0.28 -0.04,-0.571 -0.26,-0.758c-0.22,-0.187 -0.525,-0.241 -0.797,-0.14c-4.193,1.552 -17.106,6.397 -22.384,8.35c-0.335,0.124 -0.553,0.446 -0.542,0.799c0.012,0.354 0.25,0.661 0.593,0.764c2.367,0.708 5.474,1.693 5.474,1.693c0,0 1.452,4.385 2.209,6.615c0.095,0.28 0.314,0.5 0.603,0.576c0.288,0.075 0.596,-0.004 0.811,-0.207c1.216,-1.148 3.096,-2.923 3.096,-2.923c0,0 3.572,2.619 5.598,4.062Zm-11.01,-8.677l1.679,5.538l0.373,-3.507c0,0 6.487,-5.851 10.185,-9.186c0.108,-0.098 0.123,-0.262 0.033,-0.377c-0.089,-0.115 -0.253,-0.142 -0.376,-0.064c-4.286,2.737 -11.894,7.596 -11.894,7.596Z\" />\n".
				"$tab</svg>\n",
			'messenger' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M12 0C5.37 0 0 4.97 0 11.11c0 3.5 1.74 6.62 4.47 8.65V24l4.09-2.24c1.09.3 2.24.46 3.44.46 6.63 0 12-4.97 12-11.1C24 4.96 18.63 0 12 0zm1.2 14.96l-3.06-3.26-5.97 3.26L10.73 8l3.13 3.26L19.76 8l-6.57 6.96z\" />\n".
				"$tab</svg>\n",
			'wechat' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M22.7 11.92a5.7 5.7 0 0 1-.66 7.94c-.7.6-.94 1.1-.5 1.91.08.15.1.34.14.52-.7-.31-1.35-.78-2.04-.85-.69-.07-1.41.32-2.13.4a7.1 7.1 0 0 1-5.76-1.89c-3.07-2.84-2.63-7.2.92-9.52 3.16-2.07 7.8-1.38 10.02 1.49zm-7.41-7.03a6.65 6.65 0 0 1 1.38 3.52c-2.22.11-4.16.79-5.73 2.31a6.81 6.81 0 0 0-2.12 5.78c-.87-.11-1.66-.23-2.46-.3-.28-.02-.6.01-.84.14-.77.44-1.51.93-2.4 1.48.17-.73.27-1.37.46-1.98.13-.45.07-.7-.35-1C.56 12.95-.57 10.13.28 7.22c.78-2.7 2.7-4.33 5.3-5.18a8.89 8.89 0 0 1 9.7 2.85zm-1.63 7.97c-.47 0-.86.4-.84.86a.84.84 0 0 0 1.67 0 .84.84 0 0 0-.83-.86zm5.17 0c-.44 0-.81.35-.83.8-.02.47.35.85.82.85a.8.8 0 0 0 .82-.78.82.82 0 0 0-.81-.87zm-7.06-6.39c-.55.01-1.01.48-1 1.01a1 1 0 0 0 1.03.98c.56 0 1-.44.99-1a1 1 0 0 0-1.02-.99zm-6.34 0a1 1 0 0 0-1.04.97c-.01.56.42 1 .98 1.02.56.01 1.03-.42 1.05-.96a1.03 1.03 0 0 0-.99-1.03z\" />\n".
				"$tab</svg>\n",
			'tiktok' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M22.5 9.84202C20.4357 9.84696 18.4221 9.20321 16.7435 8.00171V16.3813C16.7429 17.9333 16.2685 19.4482 15.3838 20.7233C14.499 21.9984 13.246 22.973 11.7923 23.5168C10.3387 24.0606 8.75362 24.1477 7.24914 23.7664C5.74466 23.3851 4.39245 22.5536 3.37333 21.383C2.3542 20.2125 1.71674 18.7587 1.54617 17.2161C1.3756 15.6735 1.68007 14.1156 2.41884 12.7507C3.15762 11.3858 4.2955 10.279 5.68034 9.57823C7.06517 8.87746 8.63095 8.61616 10.1683 8.82927V13.0439C9.4648 12.8227 8.70938 12.8293 8.0099 13.063C7.31041 13.2966 6.70265 13.7453 6.2734 14.345C5.84415 14.9446 5.61536 15.6646 5.6197 16.402C5.62404 17.1395 5.8613 17.8567 6.29759 18.4512C6.73387 19.0458 7.34688 19.4873 8.04906 19.7127C8.75125 19.9381 9.5067 19.9359 10.2075 19.7063C10.9084 19.4768 11.5188 19.0316 11.9515 18.4345C12.3843 17.8374 12.6173 17.1188 12.6173 16.3813V0H16.7435C16.7406 0.348435 16.7698 0.696395 16.8307 1.03948V1.03948C16.9741 1.80537 17.2722 2.53396 17.7068 3.18068C18.1415 3.8274 18.7035 4.37867 19.3585 4.80075C20.2903 5.41688 21.3829 5.74528 22.5 5.74505V9.84202Z\" />\n".
				"$tab</svg>\n",
			'bluesky' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M12 11.4963C11.8936 11.2963 7.45492 3 3.50417 3C1.33647 3 2.00456 8 2.50443 10.5C2.70653 11.5108 3.50417 14.5 8.003 14C8.003 14 4.00404 14.5 4.00404 17C4.00404 18.5 6.50339 21 8.50287 21C10.4606 21 11.9391 16.6859 12 16.5058C12.0609 16.6859 13.5394 21 15.4971 21C17.4966 21 19.996 18.5 19.996 17C19.996 14.5 15.997 14 15.997 14C20.4958 14.5 21.2935 11.5108 21.4956 10.5C21.9954 8 22.6635 3 20.4958 3C16.5451 3 12.1064 11.2963 12 11.4963Z\"/>\n".
				"$tab</svg>\n",
			'substack' =>
				"$tab<svg$id$class xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 24 24\">\n".
				"$tab\t<path d=\"M20 22.724l-8-4.572-8 4.572V10h16V22.724zM4 6H20V8H4zM4 2H20V4H4z\"/>\n".
				"$tab</svg>\n"));
		if (array_key_exists($icon, $icons))
			return $icons[$icon];
		elseif ($icon == 'all')
			return $icons;
		else
			return 'No SVG icon found with that name!';
	}
}