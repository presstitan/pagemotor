<?php
/**
 * PageMotor Text Formatting Tools
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Text {
	public $textify = false;			// [object] all your text-parsing needs in one handy package

	public function __construct() {
		require_once(PM_TOOLS. '/textify.php');
		foreach ($this->allowed_html['content'] as $tag => $attributes)
			$this->allowed_html['content'][$tag] = array_merge($attributes, $this->attributes);
		$no_links = $this->allowed_html['inline'];
		unset($no_links['a']);
		$this->allowed_html['inline-no-links'] = $no_links;
		$this->textify = new PM_Textify;
	}

/*
	Shortcut method to textify text and then escape characters (&, ', ", <, >)
	— $text: the text to escape
	— $type: if 'escape-html', text will be texturized; if 'escape-code', quotes will not be escaped
*/
	public function escape($text = false, $type = false) {
		global $motor;
		return strlen($text === 0) ? false :
			htmlspecialchars(
				$type == 'escape-html' ? $this->textify->convert($text) : $text,
				$type == 'escape-code' ? ENT_NOQUOTES : ENT_QUOTES,
				$motor->charset);
	}

/*
	Shortcut method to textify text and then ensure only allowed HTML tags
	appear in the final output.
	— $text: the text to textify and scrub
	— $html: which type of HTML is allowed ('content', 'inline', 'inline-no-links', or false for no HTML)
*/
	public function allow($text = false, $html = 'inline') {
		return $this->textify->allow($text, $html == 'inline' ?
			$this->allowed_html['inline'] : ($html == 'inline-no-links' ?
			$this->allowed_html['inline-no-links'] : ($html == 'content' ?
			$this->allowed_html['content'] : array())));
	}

	public function url($url = false, $type = 'attribute') {
		if (empty($url))
			return false;
		$url = str_replace(' ', '%20', ltrim($url));
		$url = preg_replace('|[^a-z0-9-~+_.?#=!&;,/:%@$\|*\'()\[\]\\x80-\\xff]|i', '', $url);
		if (empty($url))
			return false;
		$url = str_replace(';//', '://', $url);
		if (!$this->contains($url, ':')
		&& !in_array($url[0], array('/', '#', '?'), true)
		&& !preg_match('/^[a-z0-9-]+?\.php/i', $url))
			$url = 'https://'. $url;
		if ($type === 'attribute') {
			$url = $this->textify->allow_entities($url);
			$url = str_replace('&amp;', '&#038;', $url);
			$url = str_replace("'", '&#039;', $url);
		}
		if ($this->contains($url, '[') || $this->contains($url, ']')) {
			$parsed = parse_url($url);
			$beginning = isset($parsed['scheme']) ? "{$parsed['scheme']}://" : '//';
			if (isset($parsed['user']))
				$beginning .= $parsed['user'];
			if (isset($parsed['pass']))
				$beginning .= ":{$parsed['pass']}";
			if (isset($parsed['user']) || isset($parsed['pass']))
				$beginning .= '@';
			if (isset($parsed['host']))
				$beginning .= $parsed['host'];
			if (isset($parsed['port']))
				$beginning .= ":{$parsed['port']}";
			$find = str_replace($beginning, '', $url);
			$replace = str_replace(array('[', ']'), array('%5B', '%5D'), $find);
			$url = str_replace($find, $replace, $url);
		}
		return $this->add_url_slash($url);
	}

	public function add_url_slash($url) {
		$slash = true;
		$parsed = parse_url($url);
		if (!empty($parsed['query']) || (!empty($parsed['path']) && (!empty(pathinfo($parsed['path'], PATHINFO_EXTENSION)) || $this->ends_with($parsed['path'], '/'))))
			$slash = false;
		return $slash ? "$url/" : $url;
	}

/*
	Trim a text sample to the specified number of words after removing HTML
	tags AND the contents of any included styles or scripts.
*/
	public function trim($text = false, $limit = 55, $more = '&hellip;') {
		if (empty($text))
			return false;
		$text = trim(strip_tags(preg_replace('@<(script|style)[^>]*?>.*?</\\1>@si', '', $text)));
		// Strip shortcodes?
		$words = preg_split("/[\n\r\t ]+/", $text, $limit + 1, PREG_SPLIT_NO_EMPTY);
		if (count($words) > $limit) {
			array_pop($words);
			return implode(' ', $words). $more;
		}
		else
			return implode(' ', $words);
	}

	public function starts_with($string, $start) {
		if (function_exists('str_starts_with'))
			return str_starts_with($string, $start);
		return $start === '' || strpos($string, $start) === 0 ? true : false;
	}

	public function ends_with($string, $end) {
		if (function_exists('str_ends_with'))
			return str_ends_with($string, $end);
		if ($string === '')
			return $end === '';
		$length = strlen($end);
		return substr($string, -$length, $length) === $end;
	}

	public function contains($string, $contains) {
		if (function_exists('str_contains'))
			return str_contains($string, $contains);
		return $contains === '' || strpos($string, $contains) !== false ? true : false;
	}

	public function stripslashes($text) {
		return preg_replace('%\\\\"%', '"', $text);
	}

	public $allowed_html = array(		// [array] allowed formatting tags in textified output ('content', 'inline', 'inline-no-links')
		'content' => array(				// modern block and inline tags
			'address' => array(),
			'a' => array(
				'href' => true,
				'name' => true,
				'rel' => true,
				'target' => true),
			'abbr' => array(),
			'article' => array(),
			'aside' => array(),
			'audio' => array(
				'autoplay' => true,
				'controls' => true,
				'loop' => true,
				'muted' => true,
				'preload' => true,
				'src' => true),
			'b' => array(),
			'blockquote' => array(
				'cite' => true),
			'br' => array(),
			'button' => array(
				'disabled' => true,
				'name' => true,
				'type' => true,
				'value' => true),
			'caption' => array(),
			'cite' => array(),
			'code' => array(),
			'del' => array(
				'datetime' => true),
			'dd' => array(),
			'dfn' => array(),
			'details' => array(
				'open' => true),
			'div' => array(),
			'dl' => array(),
			'dt' => array(),
			'em' => array(),
			'fieldset' => array(),
			'figure' => array(),
			'figcaption' => array(),
			'footer' => array(),
			'form' => array(
				'action' => true,
				'enctype' => true,
				'method' => true,
				'name' => true),
			'h1' => array(),
			'h2' => array(),
			'h3' => array(),
			'h4' => array(),
			'h5' => array(),
			'h6' => array(),
			'header' => array(),
			'hgroup' => array(),
			'hr' => array(),
			'i' => array(),
			'img' => array(
				'alt' => true,
				'height' => true,
				'loading' => true,
				'longdesc' => true,
				'src' => true,
				'width' => true),
			'input' => array(
				'accept' => true,
				'autocomplete' => true,
				'autofocus' => true,
				'checked' => true,
				'disabled' => true,
				'list' => true,
				'max' => true,
				'maxlength' => true,
				'min' => true,
				'minlength' => true,
				'multiple' => true,
				'name' => true,
				'placeholder' => true,
				'readonly' => true,
				'required' => true,
				'size' => true,
				'src' => true,
				'step' => true,
				'type' => true,
				'value' => true),
			'ins' => array(
				'datetime' => true,
				'cite' => true),
			'kbd' => array(),
			'label' => array(
				'for' => true),
			'legend' => array(),
			'li' => array(
				'value' => true),
			'main' => array(),
			'map' => array(
				'name' => true),
			'mark' => array(),
			'nav' => array(),
			'object' => array(
				'data' => array(
					'required' => true),
				'type' => array(
					'required' => true)),
			'option' => array(
				'value' => true,
				'selected' => true),
			'p' => array(),
			'pre' => array(),
			'q' => array(
				'cite' => true),
			'samp' => array(),
			'span' => array(),
			'section' => array(),
			'select' => array(
				'name' => true,
				'multiple' => true,
				'size' => true,
				'disabled' => true),
			'small' => array(),
			'strong' => array(),
			'sub' => array(),
			'summary' => array(),
			'sup' => array(),
			'table' => array(
				'border' => true,
				'cellpadding' => true,
				'cellspacing' => true),
			'tbody' => array(),
			'td' => array(
				'colspan' => true,
				'nowrap' => true,
				'rowspan' => true,
				'scope' => true),
			'textarea' => array(
				'cols' => true,
				'disabled' => true,
				'name' => true,
				'placeholder' => true,
				'readonly' => true,
				'required' => true,
				'rows' => true),
			'tfoot' => array(),
			'th' => array(
				'colspan' => true,
				'nowrap' => true,
				'rowspan' => true,
				'scope' => true),
			'thead' => array(),
			'title' => array(),
			'tr' => array(),
			'track' => array(
				'default' => true,
				'kind' => true,
				'label' => true,
				'src' => true,
				'srclang' => true),
			'tt' => array(),
			'u' => array(),				// deprecated
			'ul' => array(),
			'ol' => array(
				'start' => true,
				'reversed' => true),
			'var' => array(),
			'video' => array(
				'autoplay' => true,
				'controls' => true,
				'height' => true,
				'loop' => true,
				'muted' => true,
				'playsinline' => true,
				'poster' => true,
				'preload' => true,
				'src' => true,
				'width' => true)),
		'inline' => array(				// inline tags suitable for UI output
			'a' => array(
				'id' => true,
				'class' => true,
				'href' => true,
				'rel' => true,
				'title' => true,
				'target' => true),
			'span' => array(
				'class' => true,
				'title' => true),
			'em' => array(),
			'strong' => array(),
			'abbr' => array(
				'title' => true),
			'u' => array(),
			'i' => array(),
			'code' => array(),
			'sup' => array(),
			'sub' => array(),
			'cite' => array(),
			'kbd' => array(),
			'strike' => array(),
			'br' => array()));
	public $attributes = array(			// [array] allowed attributes common to HTML content elements
		'aria-controls' => true,
		'aria-current' => true,
		'aria-describedby' => true,
		'aria-details' => true,
		'aria-expanded' => true,
		'aria-hidden' => true,
		'aria-label' => true,
		'aria-labelledby' => true,
		'aria-live' => true,
		'class' => true,
		'data-*' => true,
		'dir' => true,
		'hidden' => true,
		'id' => true,
		'style' => true,
		'title' => true,
		'role' => true,
		'xml:lang' => true);
}