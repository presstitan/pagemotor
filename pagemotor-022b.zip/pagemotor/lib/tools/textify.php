<?php
/**
 * PageMotor Text Parser + Formatter
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_Textify {
	public $ldquo = '&#8220;';
	public $rdquo = '&#8221;';
	public $lsquo = '&#8216;';
	public $rsquo = '&#8217;';
	public $prime = '&#8242;';
	public $dprime = '&#8243;';
	public $ndash = '&#8211;';
	public $mdash = '&#8212;';
	public $whitespace = '[\r\n\t ]|\xC2\xA0|&nbsp;';
	public $phrases = array(
		'raw' => array(
			'...',
			"'tis",
			"'til",
			"'em"),
		'formatted' => array(
			'&#8230;',
			'&#8217;tis',
			'&#8217;til',
			'&#8217;em'));
	public $flags = array(
		'rsquo' => '<!--rsquo-->',
		'lsquo' => '<!--lsquo-->',
		'ldquo' => '<!--ldquo-->');
	public $ignore_tags = array(
		'pre',
		'code',
		'kbd',
		'style',
		'script');
	public $ignore_shortcodes = array(
		'code');
	public $replace = array();				// [array] single quote, double quote, and dash patterns to replace
	public $tags = array();					// [array] allowed HTML tags in the current function call environment

	public function __construct() {
		$this->replace = array(
			'squo' => array(
				'/\'(\d\d)\'(?=\Z|[.,:;!?)}\-\]]|&gt;|'. $this->whitespace. ')/' => "{$this->flags['rsquo']}$1$this->rsquo",
				'/\'(\d\d)"(?=\Z|[.,:;!?)}\-\]]|&gt;|'. $this->whitespace. ')/' => "{$this->flags['rsquo']}$1$this->rdquo",
				'/\'(?=\d\d(?:\Z|(?![%\d]|[.,]\d)))/' => $this->flags['rsquo'],
				'/(?<=\A|'. $this->whitespace. ')\'(\d[.,\d]*)\'/' => "{$this->flags['lsquo']}$1$this->rdquo",
				'/(?<=\A|[([{"\-]|&lt;|'. $this->whitespace. ')\'/' => $this->flags['lsquo'],
				'/(?<!'. $this->whitespace. ')\'(?!\Z|[.,:;!?"\'(){}[\]\-]|&[lg]t;|'. $this->whitespace. ')/' => $this->flags['rsquo']),
			'dquo' => array(
				'/(?<=\A|'. $this->whitespace. ')"(\d[.,\d]*)"/' => "{$this->flags['ldquo']}$1$this->rdquo",
				'/(?<=\A|[([{\-]|&lt;|'. $this->whitespace. ')"(?!'. $this->whitespace. ')/' => $this->flags['ldquo']),
			'dash' => array(
				'/---/' => $this->mdash,
				'/(?<=^|'. $this->whitespace. ')--(?=$|'. $this->whitespace. ')/' => $this->mdash,
				'/(?<!xn)--/' => $this->ndash,
				'/(?<=^|'. $this->whitespace. ')-(?=$|'. $this->whitespace. ')/' => $this->ndash));
	}

/*
	Scrub text so only the allowed tags appear in the output
	— $text: the text to scrub for allowed tags
	— $allowed_tags: an array of allowed tags and attributes
*/
	public function allow($text = false, $allowed_tags = array()) {
		if (strlen($text) === 0)
			return false;
		$this->tags = !empty($allowed_tags) && is_array($allowed_tags) ? $allowed_tags : array();
		return $this->allow_tags($this->allow_entities($this->convert($text)));
	}

	public function convert($text = false) {
		global $motor;
		if (strlen($text) === 0)
			return false;
		$ignored_tags = $ignored_shortcodes = array();
		// Shortcodes
		// $shortcodes should be set from a global shortcode registry
		$shortcodes = array();
		preg_match_all('@\[/?([^<>&/\[\]\x00-\x20=]++)@', $text, $matches);
		$shortcodes = array_intersect(array_keys($shortcodes), $matches[1]);
		$find_shortcodes = !empty($shortcodes) ? $this->match_shortcodes($shortcodes) : false;
		$find_tags = '/(<(?(?=!--)!(?:-(?!->)[^\-]*+)*+(?:-->)?|[^>]*>?)'. (!empty($find_shortcodes) ? "|$find_shortcodes" : ''). ')/';
		$tags = preg_split($find_tags, $text, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
		foreach ($tags as &$tag) {
			if ($tag[0] === '<') {			// comment
				if ($motor->tools->text->starts_with($tag, '<!--'))
					continue;
				else {						// HTML element
					$tag = preg_replace('/&(?!#(?:\d+|x[a-f0-9]+);|[a-z1-4]{1,8};)/i', '&#038;', $tag);
					$this->ignore_tag($tag, $ignored_tags, $this->ignore_tags);
				}
			}
			elseif (trim($tag) === '')		// newline
				continue;
			elseif ($tag[0] === '[' && !empty($find_shortcodes) && preg_match('/^'. $find_shortcodes. '$/', $tag) === 1) {
				if (!$motor->tools->text->starts_with($tag, '[[') && !$motor->tools->text->ends_with($tag, ']]'))	// shortcode
					$this->ignore_tag($tag, $ignored_shortcodes, $this->ignore_shortcodes);
				else						// shortcode is escaped, do not format
					continue;
			}
			elseif (empty($ignored_tags) && empty($ignored_shortcodes)) {	// typogrify it!
				$tag = str_replace($this->phrases['raw'], $this->phrases['formatted'], $tag);
				if ($motor->tools->text->contains($tag, "'")) {
					$tag = preg_replace(array_keys($this->replace['squo']), array_values($this->replace['squo']), $tag);
					$tag = $this->convert_quotes($tag, "'", $this->prime, $this->flags['lsquo'], $this->rsquo);
					$tag = str_replace($this->flags['rsquo'], $this->rsquo, $tag);
					$tag = str_replace($this->flags['lsquo'], $this->lsquo, $tag);
				}
				if ($motor->tools->text->contains($tag, '"')) {
					$tag = preg_replace(array_keys($this->replace['dquo']), array_values($this->replace['dquo']), $tag);
					$tag = $this->convert_quotes($tag, '"', $this->dprime, $this->flags['ldquo'], $this->rdquo);
					$tag = str_replace($this->flags['ldquo'], $this->ldquo, $tag);
				}
				if ($motor->tools->text->contains($tag, '-'))
					$tag = preg_replace(array_keys($this->replace['dash']), array_values($this->replace['dash']), $tag);
				if (preg_match('/(?<=\d)x\d/', $tag) === 1)
					$tag = preg_replace('/\b(\d(?(?<=0)[\d\.,]+|[\d\.,]*))x(\d[\d\.,]*)\b/', '$1&#215;$2', $tag);
				$tag = preg_replace('/&(?!#(?:\d+|x[a-f0-9]+);|[a-z1-4]{1,8};)/i', '&#038;', $tag);
			}
		}
		return implode('', $tags);
	}

	public function convert_quotes($string = false, $find = false, $prime = false, $open = false, $close = false) {
		global $motor;
		$flag = '<!--primes-and-quotes-->';
		$find_quote = "/$find(?=\\Z|[.,:;!?)}\\-\\]]|&gt;|[\r\n\t ]|\xC2\xA0|&nbsp;)/";
		$find_prime = "/(?<=\\d)$find/";
		$flags = array(
			'no-digit' => "/(?<!\\d)$flag/",
			'after-digit' => "/(?<=\\d)$flag/");
		$phrases = explode($open, $string);
		foreach ($phrases as $key => &$phrase) {
			if (!$motor->tools->text->contains($phrase, $find))
				continue;
			elseif ($key !== 0 && substr_count($phrase, $close) === 0) {
				// $count is not yet defined!
				$phrase = preg_replace($find_quote, $flag, $phrase, -1, $count);
				if ($count > 1) {
					$phrase = preg_replace($flags['no-digit'], $close, $phrase, -1, $sanity);
					if ($sanity === 0) {
						$sanity = substr_count($phrase, "$flag.");
						$position = $sanity > 0 ?
							strrpos($phrase, "$flag.") :
							strrpos($phrase, $flag);
						$phrase = substr_replace($phrase, $close, $position, strlen($flag));
					}
					$phrase = preg_replace($find_prime, $prime, $phrase);
					$phrase = preg_replace($flags['after-digit'], $prime, $phrase);
					$phrase = preg_replace($flag, $close, $phrase);
				}
				elseif ($count === 1) {
					$phrase = str_replace($flag, $close, $phrase);
					$phrase = preg_replace($find_prime, $prime, $phrase);
				}
				else
					$phrase = preg_replace($find_prime, $prime, $phrase);
			}
			else {
				$phrase = preg_replace($find_prime, $prime, $phrase);
				$phrase = preg_replace($find_quote, $close, $phrase);
			}
			if ($find === '' && $motor->tools->text->contains($phrase, '"'))
				$phrase = str_replace('"', $close, $phrase);
		}
		return implode($open, $phrases);
	}

	public function ignore_tag($element = false, &$tags = array(), $ignore = array()) {
		if (isset($element[1]) && $element[1] !== '/') {
			$open = true;
			$offset = 1;
		}
		elseif (count($tags) === 0)
			return;
		else {
			$open = false;
			$offset = 2;
		}
		$space = strpos($element, ' ') === false ? -1 : $offset;
		$tag = substr($element, $offset, $space);
		if (in_array($tag, $ignore, true)) {
			if ($open)
				array_push($tags, $tag);
			elseif (end($tags) === $tag)
				array_pop($tags);
		}
	}

	public function allow_entities($text = false) {
		$text = str_replace('&', '&amp;', $text);	// convert & to &amp;
		$text = preg_replace_callback('/&amp;([A-Za-z]{2,8}[0-9]{0,2});/', array($this, 'match_entities'), $text);
		$text = preg_replace_callback('/&amp;#(0*[0-9]{1,7});/', array($this, 'match_unicode'), $text);
		$text = preg_replace_callback('/&amp;#[Xx](0*[0-9A-Fa-f]{1,6});/', array($this, 'match_hex'), $text);
		return $text;
	}

	public function allow_tags($text = false) {
		return preg_replace_callback('%(<!--.*?(-->|$))|(<[^>]*(>|$)|>)%', array($this, 'match_tags'), $text);
	}

	public function allow_attributes($tag = false, $attributes = false, $tags = array()) {
		$slash = preg_match('%\s*/\s*$%', $attributes) ? ' /' : false;	// closing slash (XHTML)
		$ltag = strtolower($tag);
		if (empty($tags[$ltag]) || $tags[$ltag] === true)
			return "<$tag$slash>";
		$attribute_list = $this->attribute_list($attributes);
		$required = array();
		foreach ($tags[$ltag] as $attr)
			if (!empty($attr['required']))
				$required[] = $attr;
		$attrs = '';
		foreach ($attribute_list as $name => $attribute) {
			$req = array_search(strtolower($name), $required);
			if ($this->valid_attribute($name, $tag, $tags)) {
				$attrs .= " {$attribute['string']}";
				if ($req !== false)
					unset($required[$req]);
			}
			elseif ($req !== false)
				return "<$tag>";
		}
		if (!empty($required))
			return "<$tag>";
		$attrs = preg_replace('/[<>]/', '', $attrs);
		return "<$tag$attrs$slash>";
	}

	public function match_entities($matches = array()) {
		return empty($matches) || empty($matches[1]) ? false :
			(!in_array($matches[1], $this->allowed_entities, true) ?
				"&amp;{$matches[1]};" : "&{$matches[1]};");
	}

	public function match_tags($matches = array()) {
		global $motor;
		$snippet = $motor->tools->text->stripslashes($matches[0]);
		if (!$motor->tools->text->starts_with($snippet, '<'))		// Tag
			return '&gt;';
		if ($motor->tools->text->starts_with($snippet, '<!--')) {	// HTML comment
			$snippet = str_replace(array('<!--', '-->'), '', $snippet);
			while ($snippet !== ($comment = $this->allow($snippet, $this->tags)))
				$snippet = $comment;
			if (empty($snippet))
				return false;
			$snippet = preg_replace('/--+/', '-', $snippet);	// no multiple dashes
			$snippet = preg_replace('/-$/', '', $snippet);		// no three-dash closing
			return "<!--$snippet-->";
		}
		if (!preg_match('%^<\s*(/\s*)?([a-zA-Z0-9-]+)([^>]*)>?$%', $snippet, $found))	// Malformed tag
			return false;
		$slash = trim($found[1]);
		$tag = $found[2];
		$attributes = $found[3];
		if (!isset($this->tags[strtolower($tag)]))
			return '';
		if ($slash !== '')
			return "</$tag>";
		return
			$this->allow_attributes($tag, $attributes, $this->tags);
	}

	public function match_shortcodes($shortcodes = false) {
		$shortcodes = implode('|', array_map('preg_quote', $shortcodes));
		return '\[[\/\[]?(?:'. $shortcodes. ')(?=[\\s\\]\\/])(?:[^\[\]<>]+|<[^\[\]>]*>)*+\]\]?'; 
	}

	public function match_unicode($matches = array()) {
		return empty($matches) || empty($matches[1]) ? false :
			($this->is_unicode($matches[1]) ?
				'&#'. str_pad(ltrim($matches[1], '0'), 3, '0', STR_PAD_LEFT). ';' :
				"&amp;#{$matches[1]};");
	}

	public function match_hex($matches = array()) {
		return empty($matches) || empty($matches[1]) ? false :
			($this->is_unicode($matches[1]) ?
				'&#x'. ltrim($matches[1], '0'). ';' :
				"&amp;#x{$matches[1]};");
	}

	public function is_unicode($check = 0) {
		$check = (int) $check;
		return $check === 0x9 || $check === 0xa || $check === 0xd
			|| ($check >= 0x20 && $check <= 0xd7ff)
			|| ($check >= 0xe000 && $check <= 0xfffd)
			|| ($check >= 0x10000 && $check <= 0x10ffff) ? true : false;
	}

	public function attribute_list($attributes = false) {
		$list = array();
		$name = false;
		$case = 'attribute';
		while (strlen($attributes) !== 0) {
			$valid = false;
			switch ($case) {
				case 'attribute':
					if (preg_match('/^([_a-zA-Z][-_a-zA-Z0-9:.]*)/', $attributes, $match)) {
						$name = $match[1];
						$valid = true;
						$case = 'check';
						$attributes = preg_replace('/^[_a-zA-Z][-_a-zA-Z0-9:.]*/', '', $attributes);
					}
					break;
				case 'check':
					if (preg_match('/^\s*=\s*/', $attributes)) {	// =
						$valid = true;
						$case = 'value';
						$attributes = preg_replace('/^\s*=\s*/', '', $attributes);
						break;
					}
					if (preg_match('/^\s+/', $attributes)) {	// empty value
						if (!array_key_exists($name, $list))
							$list[$name] = array(
								'value' => false,
								'string' => $name);
						$valid = true;
						$case = 'attribute';
						$attributes = preg_replace('/^\s+/', '', $attributes);
					}
					break;
				case 'value':
					if (preg_match('%^"([^"]*)"(\s+|/?$)%', $attributes, $match)) {	// double quotes
						if (!array_key_exists($name, $list))
							$list[$name] = array(
								'value' => $match[1],
								'string' => "$name=\"{$match[1]}\"");
						$valid = true;
						$case = 'attribute';
						$attributes = preg_replace('/^"[^"]*"(\s+|$)/', '', $attributes);
						break;
					}
					if (preg_match("%^'([^']*)'(\s+|/?$)%", $attributes, $match)) {	// single quotes
						if (!array_key_exists($name, $list))
							$list[$name] = array(
								'value' => $match[1],
								'string' => "$name=\"{$match[1]}\"");
						$valid = true;
						$case = 'attribute';
						$attributes = preg_replace("/^'[^']*'(\s+|$)/", '', $attributes);
						break;
					}
					if (preg_match("%^([^\s\"']+)(\s+|/?$)%", $attributes, $match)) {	// no quotes
						if (!array_key_exists($name, $list))
							$list[$name] = array(
								'value' => $match[1],
								'string' => "$name=\"{$match[1]}\"");
						$valid = true;
						$case = 'attribute';
						$attributes = preg_replace("%^[^\s\"']+(\s+|$)%", '', $attributes);
					}
					break;
			}
			if (empty($valid)) {
				$attributes = preg_replace('/^("[^"]*("|$)|\'[^\']*(\'|$)|\S)*\s*/', '', $attributes);
				$case = 'attribute';
			}
		}
		if ($case === 'check' && !array_key_exists($name, $list))
			$list[$name] = array(
				'value' => false,
				'string' => $name);
		return $list;
	}

	public function valid_attribute($attribute = false, $tag = false, $tags = array()) {
		global $motor;
		$attribute = strtolower($attribute);
		$tag = strtolower($tag);
		if (!isset($tags[$tag]))
			return false;
		if (empty($tags[$tag][$attribute])) {
			if ($motor->tools->text->starts_with($attribute, 'data-')
			&& !empty($tags[$tag]['data-*'])
			&& preg_match('/^data(?:-[a-z0-9_]+)+$/', $attribute, $match))
				$tags[$tag][$match[0]] = $tags[$tag]['data-*'];
			else
				return false;
		}
		return true;
	}

	public $allowed_entities = array(
		'nbsp',
		'iexcl',
		'cent',
		'pound',
		'curren',
		'yen',
		'brvbar',
		'sect',
		'uml',
		'copy',
		'ordf',
		'laquo',
		'not',
		'shy',
		'reg',
		'macr',
		'deg',
		'plusmn',
		'acute',
		'micro',
		'para',
		'middot',
		'cedil',
		'ordm',
		'raquo',
		'iquest',
		'Agrave',
		'Aacute',
		'Acirc',
		'Atilde',
		'Auml',
		'Aring',
		'AElig',
		'Ccedil',
		'Egrave',
		'Eacute',
		'Ecirc',
		'Euml',
		'Igrave',
		'Iacute',
		'Icirc',
		'Iuml',
		'ETH',
		'Ntilde',
		'Ograve',
		'Oacute',
		'Ocirc',
		'Otilde',
		'Ouml',
		'times',
		'Oslash',
		'Ugrave',
		'Uacute',
		'Ucirc',
		'Uuml',
		'Yacute',
		'THORN',
		'szlig',
		'agrave',
		'aacute',
		'acirc',
		'atilde',
		'auml',
		'aring',
		'aelig',
		'ccedil',
		'egrave',
		'eacute',
		'ecirc',
		'euml',
		'igrave',
		'iacute',
		'icirc',
		'iuml',
		'eth',
		'ntilde',
		'ograve',
		'oacute',
		'ocirc',
		'otilde',
		'ouml',
		'divide',
		'oslash',
		'ugrave',
		'uacute',
		'ucirc',
		'uuml',
		'yacute',
		'thorn',
		'yuml',
		'quot',
		'amp',
		'lt',
		'gt',
		'apos',
		'OElig',
		'oelig',
		'Scaron',
		'scaron',
		'Yuml',
		'circ',
		'tilde',
		'ensp',
		'emsp',
		'thinsp',
		'zwnj',
		'zwj',
		'lrm',
		'rlm',
		'ndash',
		'mdash',
		'lsquo',
		'rsquo',
		'sbquo',
		'ldquo',
		'rdquo',
		'bdquo',
		'dagger',
		'Dagger',
		'permil',
		'lsaquo',
		'rsaquo',
		'euro',
		'fnof',
		'Alpha',
		'Beta',
		'Gamma',
		'Delta',
		'Epsilon',
		'Zeta',
		'Eta',
		'Theta',
		'Iota',
		'Kappa',
		'Lambda',
		'Mu',
		'Nu',
		'Xi',
		'Omicron',
		'Pi',
		'Rho',
		'Sigma',
		'Tau',
		'Upsilon',
		'Phi',
		'Chi',
		'Psi',
		'Omega',
		'alpha',
		'beta',
		'gamma',
		'delta',
		'epsilon',
		'zeta',
		'eta',
		'theta',
		'iota',
		'kappa',
		'lambda',
		'mu',
		'nu',
		'xi',
		'omicron',
		'pi',
		'rho',
		'sigmaf',
		'sigma',
		'tau',
		'upsilon',
		'phi',
		'chi',
		'psi',
		'omega',
		'thetasym',
		'upsih',
		'piv',
		'bull',
		'hellip',
		'prime',
		'Prime',
		'oline',
		'frasl',
		'weierp',
		'image',
		'real',
		'trade',
		'alefsym',
		'larr',
		'uarr',
		'rarr',
		'darr',
		'harr',
		'crarr',
		'lArr',
		'uArr',
		'rArr',
		'dArr',
		'hArr',
		'forall',
		'part',
		'exist',
		'empty',
		'nabla',
		'isin',
		'notin',
		'ni',
		'prod',
		'sum',
		'minus',
		'lowast',
		'radic',
		'prop',
		'infin',
		'ang',
		'and',
		'or',
		'cap',
		'cup',
		'int',
		'sim',
		'cong',
		'asymp',
		'ne',
		'equiv',
		'le',
		'ge',
		'sub',
		'sup',
		'nsub',
		'sube',
		'supe',
		'oplus',
		'otimes',
		'perp',
		'sdot',
		'lceil',
		'rceil',
		'lfloor',
		'rfloor',
		'lang',
		'rang',
		'loz',
		'spades',
		'clubs',
		'hearts',
		'diams',
		'sup1',
		'sup2',
		'sup3',
		'frac14',
		'frac12',
		'frac34',
		'there4');
}