<?php
/**
 * PageMotor UI Component Tools
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Tools
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PM_UI {
	public function admin_options_form($args = array()) {
		global $motor;
		$title = 'PageMotor Admin Options Form';
		$name = 'Options';
		$docs = $form = $id = $class = $ajax = $hidden_fields = $saved = $empty = false;
		$depth = 0;
		extract($args);		// title, name, docs, form, id, class, ajax, type, depth, save_icon, hidden, saved, empty
		$tab = str_repeat("\t", $depth);
//		$back = !empty($back) && is_array($back) && !empty($back['url']) && !empty($back['text']) ?
//			"$tab<a class=\"button button-back\" href=\"{$back['url']}\">{$back['text']}</a>\n" : false;
		$docs = !empty($docs) ?
			"$tab\t<a href=\"$docs\" title=\"See Documentation\" target=\"_blank\" rel=\"noopener noreferrer\">\n".
			$motor->tools->svg->icon('info', $depth + 2).
			"$tab\t</a>\n" : false;
		$id = !empty($id) ? " id=\"$id\"" : false;
		$class = " class=\"pm-options-form". (!empty($class) ? ' '. trim($motor->text($class)) : false). '"';
		$type = !empty($type) ? " data-type=\"$type\"" : false;
		$action = empty($ajax) ? $_SERVER['REQUEST_URI'] : false;
		$icon = !empty($save_icon) ? $motor->tools->svg->icon($save_icon, $depth + 2) : false;
//		if (!empty($hidden) && !empty($hidden['options']))
//			foreach ($hidden['options'] as $id => $name)
//			$hidden_fields = $motor->tools->form->fields($hidden['options'], !empty($hidden['values']) ? $hidden['values'] : array());
//		if (!empty($hidden) && is_array($hidden))
//			foreach ($hidden as $id => $value)
//				$hidden_fields .= "$tab\t<input type=\"hidden\" class=\"pm-option-ajax\" id=\"$id\" value=\"$value\">\n";
		if (!empty($hidden) && is_array($hidden))
			foreach ($hidden as $option_name => $value)
				if (!empty($option_name) && !empty($value))
					$hidden_fields .= "$tab\t<input type=\"hidden\" name=\"$option_name\" value=\"$value\">\n";
		// $saved can be true, false, or a string indicating an error
		return
/*			(!empty($form) && empty($empty) ?
				$this->alert("Saving $name&hellip;", 'saving-options', $ajax, 'action', $depth).
				(!empty($saved) ? $this->alert("$name saved!") : '') : '').*/
//			$back.
			"$tab<h3>\n".
			"$tab\t$title\n".
			$docs.
			"$tab</h3>\n".
			(empty($form) && !empty($empty) ?
				"$tab$empty\n" :
				"$tab<form$id$class method=\"post\" action=\"$action\" enctype=\"multipart/form-data\">\n".
				$hidden_fields.
				$form.
				"$tab\t<button id=\"save-options\" class=\"pm-ui-save save\"$type value=\"1\">\n".
				$icon.
				"$tab\t\tSave $name\n".
				"$tab\t</button>\n".
				$this->alert("Saving $name&hellip;", 'saving-options', $ajax, 'action', $depth + 1).
				(!empty($saved) ? $this->alert("$name saved!", $saved, false, false, $depth + 1) : false).
				"$tab</form>\n");
	}

	public function notification($message = false, $type = 'neutral', $depth = 0) {
		global $motor;
		$tab = str_repeat("\t", $depth);
		$type = empty($type) ? 'neutral' : $type;
		return
			"$tab<div class=\"notification $type\">\n".
			"$tab\t<p>". $motor->text($message, 'inline'). "</p>\n".
			"$tab</div>\n";
	}

/*
	Easily output custom alert messages within the PageMotor UI
*/
	public function alert($message = false, $id = false, $ajax = false, $status = false, $depth = false) {
		global $motor;
		if (empty($message))
			return;
		$id = $id ? " id=\"$id\"" : '';
		$ajax = $ajax ? ' pm-alert-ajax' : '';
		$status = $status == 'action' ? ' pm-alert-action' : ($status == 'good' ? ' pm-alert-good' : ($status == 'bad' ? ' pm-alert-bad' : ($status == 'warning' ? ' pm-alert-warning' : '')));
		$tab = str_repeat("\t", (is_numeric($depth) ? $depth : 2));
		return
			"$tab<div$id class=\"pm-alert$ajax$status\">\n".
			"$tab\t<div class=\"pm-alert-message\">\n".
			"$tab\t\t<p>". $motor->text($message, 'inline'). "</p>\n".
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

/*
	Easily output a popup box within the PageMotor UI.
*/
	public function popup($args = array()) {
		global $motor;
		$id = $title = $body = $type = '';
		$name = $menu = $panes = array();
		$depth = 0;
		extract($args);		// array('id', 'title', 'name', 'menu', 'panes', 'body', 'depth')
		$tab = str_repeat("\t", $depth);
		$li = array();
		$type = $type ? " type-$type" : '';
		$title = trim($title);
		$name = !empty($name) && is_array($name) ?
			": <div class=\"option-item option-field\"><input type=\"text\" data-style=\"input\" id=\"{$name['id']}\" data-id=\"$id\" class=\"pm-popup-name\" name=\"{$name['name']}\" value=\"". $motor->text($name['value']). "\"></div>" : (!empty($name) ? ": $name" : '');
		if (is_array($menu))
			foreach ($menu as $pane => $text)
				$li[$pane] = "<li data-pane=\"$pane\">$text</li>";
		if (is_array($panes))
			foreach ($panes as $pane => $options)
				$body .=
					"$tab\t\t\t<div class=\"pane pane-$pane\">\n".
					$options.
					"$tab\t\t\t</div>\n";
		return
			"$tab<div id=\"popup-$id\" data-id=\"$id\" class=\"pm-popup\">\n".
			"$tab\t<div class=\"pm-popup-html$type\">\n".
			"$tab\t\t<div class=\"pm-popup-head\" data-style=\"box\">\n".
			"$tab\t\t\t<div class=\"pm-popup-head-controls\">\n".
			"$tab\t\t\t\t<div class=\"pm-popup-title\">$title$name</div>\n".
			$motor->tools->svg->icon('x-circle', $depth + 4, false, 'pm-popup-close').
			"$tab\t\t\t</div>\n".
			(!empty($li) ?
			"$tab\t\t\t<ul class=\"pm-popup-menu\" data-style=\"tabs\">\n".
			"$tab\t\t\t\t". implode("\n$tab\t\t\t\t", $li). "\n".
			"$tab\t\t\t</ul>\n" : '').
			"$tab\t\t</div>\n".
			"$tab\t\t<div class=\"pm-popup-body\">\n".
			$body.
			"$tab\t\t</div>\n".
			"$tab\t</div>\n".
			"$tab</div>\n";
	}

/*
	Easily add a file uploader to the PageMotor UI.
*/
	public function uploader($name, $depth = false) {
		global $motor;
#		if (!current_user_can('upload_files')) return '';
		$tab = str_repeat("\t", is_numeric($depth) ? $depth : 0);
		return
			"$tab<iframe style=\"width:100%;height:100%;". (stripos($_SERVER['HTTP_USER_AGENT'], 'mozilla') >= 0 && $name == 'pm-images' ? "position:absolute;left:0;" : ''). "\" frameborder=\"0\" src=\"". $motor->admin_url("admin-post.php?action={$name}_window"). "\" id=\"pm-upload-iframe-$name\">\n".
			"$tab</iframe>\n";
	}
}