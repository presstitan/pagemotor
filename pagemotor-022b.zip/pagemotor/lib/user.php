<?php
/**
 * PageMotor Current User Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor User
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_User {
	public $id = false;
	public $name = false;
	public $email = false;
	public $date = false;
	public $options = array();
	public $admin = false;			// Is the user an administrator?
	public $access_level = false;	// This user's access level ('admin', 'user', 'trial', or false)

	public function __construct($user = array()) {
		global $motor;
		$this->id = !empty($user['id']) ? $user['id'] : $this->id;
		$this->name = !empty($user['username']) ? $user['username'] : $this->name;
		$this->email = !empty($user['email']) ? $user['email'] : $this->email;
		$this->date = !empty($user['date_gmt']) ? $user['date_gmt'] : $this->date;
		$this->options = $motor->users->get_options($this->id);
		$this->admin = $motor->users->admin($this->options);
		$this->access_level = $motor->users->access_level($this->options);
	}
}