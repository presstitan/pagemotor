<?php
/**
 * PageMotor Users Controller
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Users
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since 		0.1
 */
class PM_Users {
	public $table = 'users';
	public $table_options = 'user_options';
	public $user = array(
		'id' => NULL,
		'username' => false,
		'email' => false,
		'password' => false,
		'date_gmt' => '0000-00-00 00:00:00');
	public $cookie_user = 'PM_USER';					// [string] PageMotor user cookie
	public $cookie_user_expire = 60 * 60 * 24 * 7;		// [int] 7 days
	public $cookie_registration = 'PM_REGISTRATION';	// [string] PageMotor Admin registration cookie
	public $cookie_registration_expire = 60 * 5;		// [int] 5 minutes
	public $admin = array(
		'administrator');
	// Themes and Plugins can expand these with valet methods (not yet built)
	public $access_admin = array(
		'administrator',
		'producer');
	public $access_user = array(
		'user');
	public $access_trial = array(
		'trial');

	public function __construct() {
		global $motor;
		$this->table = $motor->db->prefix. $this->table;
		$this->table_options = $motor->db->prefix. $this->table_options;
	}

	public function current_user() {
		if (empty($_COOKIE[$this->cookie_user]))
			return false;
		$user = $this->get_user($_COOKIE[$this->cookie_user]);
		if (empty($user))
			return false;
		return new PM_User($user);
	}

	public function get_user($user) {
		global $motor;
		if (empty($user))
			return array();
		$results = $motor->db->get_rows("SELECT * FROM {$this->table} WHERE username = '$user' OR email = '$user'");
		return count($results) === 1 ?
			$results[0] : array();
	}

	public function get_options($id) {
		global $motor;
		$options = array();
		if (empty($id))
			return $options;
		$results = $motor->db->get_rows("SELECT * FROM {$this->table_options} WHERE user_id = $id");
		if (empty($results))
			return $options;
		foreach ($results as $result)
			if (!empty($result['name']))
				$options[$result['name']] = empty($result['value']) ? false :
					((function_exists('json_validate') && json_validate($result['value']) === true) || $motor->tools->is_json($result['value']) ?
						json_decode($result['value'], true) :
						$result['value']);
		return $options;
	}

	public function admin($user_options) {
		if (empty($user_options) || empty($user_options['level']) || !in_array($user_options['level'], $this->admin))
			return false;
		else
			return true;
	}

	public function access_level($user_options) {
		if (empty($user_options) || empty($user_options['level']))
			return false;
		elseif (in_array($user_options['level'], $this->access_admin))
			return 'admin';
		elseif (in_array($user_options['level'], $this->access_user))
			return 'user';
		elseif (in_array($user_options['level'], $this->access_trial))
			return 'trial';
		else
			return false;
	}

	public function add_new($user, $options = array()) {
		global $motor;
		if (!is_array($user) || empty($user['username']) || empty($user['email']) || empty($user['password']) || empty($user['date_gmt']) || !$this->update($user))
			return false;
		if (!is_array($options))
			$options = array();
		if (empty($options))
			$options['level'] = 'user'; 	// defaults: administrator, producer, user, or trial
		$id = $motor->db->connection->insert_id;
		foreach ($options as $name => $value)
			$this->update_option($id, $name, $value);
		return true;
	}

	public function update($user) {
		global $motor;
		if (empty($user))
			return false;
		$udpate = $this->user;
		foreach ($this->user as $field => $default)
			$update[$field] = !empty($user[$field]) ? $user[$field] : $default;
		return
			$motor->db->connection->prepare("INSERT INTO {$this->table} (id, username, email, password, date_gmt) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE username = VALUES(username), email = VALUES(email), password = VALUES(password), date_gmt = VALUES(date_gmt)")->execute(array_values($update));
	}

	public function update_option($user_id, $name, $value) {
		global $motor;
		if (empty($user_id) || empty($name))
			return false;
		if (is_array($value) || is_object($value))
			$value = $motor->db->connection->real_escape_string(json_encode($value));
		return
			$motor->db->query("INSERT INTO {$this->table_options} (user_id, name, value) VALUES ('$user_id', '$name', '$value') ON DUPLICATE KEY UPDATE value = '$value'");
	}

	public function password_hash($password = false) {
		return empty($password) ? false :
			password_hash($password, PASSWORD_DEFAULT);
	}

	public function cookie_user($user = false) {
		global $motor;
		if (!empty($user) && !isset($_COOKIE[$this->cookie_user]))
			return setcookie(
				$this->cookie_user,
				$user,
				time() + $this->cookie_user_expire,
				'/',
				'',
				!empty($motor->ssl) ? true : false,
				true);
		else
			return false;
	}

	public function cookie_registration() {
		global $motor;
		if (!isset($_COOKIE[$this->cookie_registration]))
			setcookie(
				$this->cookie_registration,
				$_SERVER['REMOTE_ADDR'],
				time() + $this->cookie_registration_expire,
				'/',
				'',
				!empty($motor->ssl) ? true : false,
				true);
	}
}