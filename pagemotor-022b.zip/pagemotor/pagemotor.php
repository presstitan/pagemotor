<?php
/**
 * PageMotor Master Controller
 *
 * @package 	PageMotor
 * @author		Christopher Pearson
 * @copyright 	Copyright (c) 2025, Pearsonified LLC
 * @license		MIT2
 * @since		0.1
 */
class PageMotor {
	public $version = '0.2.2';				// [string] current PageMotor version
	public $beta = true;					// [bool] Is this a beta version?
	public $changelog = 'https://pagemotor.com/changelog/v022/';	// [string] changelog URL
	// Core PageMotor object properties
	public $tools = false;					// [object] tools for various types of shared functionality
	public $seed = false;					// [object] PageMotor seed data
	public $charset = 'utf-8';				// [string] charset to use for HTML output
	public $db = false;						// [object] active database connection
	public $ssl = false;					// [bool] site is using SSL or not
	public $protocol = false;				// [string] site URL protocol (http:// or https://)
	public $install_slug = false;			// [string] install location slug
	public $site_url = false;				// [string] URL for this PageMotor installation
	public $admin_slug = 'admin';			// [string] PageMotor admin location slug
	public $admin_url = false;				// [string] PageMotor admin URL
	public $content = false;				// [object] PageMotor content type manager
	public $options = false;				// [object] PageMotor options object
	public $settings = false;				// [object] PageMotor Site Settings object
	public $fonts = false;					// [object] PageMotor Fonts object
	public $users = false;					// [object] user tools
	public $page = false;					// [object] Current Page object
	public $user = false;					// [object] logged-in PageMotor user
	public $plugins = false;				// [object] Plugin controller
	public $themes = false;					// [object] Theme activation controller
	public $theme = false;					// [object] Front end Theme
	public $admin = false;					// [object] Admin Theme

	public function __construct() {
		// Paths
		define('PM_ROOT', __DIR__);
		define('PM_LIB', PM_ROOT. '/lib');
		define('PM_JS', PM_LIB. '/js');
		define('PM_RTE', PM_LIB. '/tinymce');
		// Include Controllers
		require_once(PM_ROOT. '/config.php');
		require_once(PM_LIB. '/error.php');
		require_once(PM_LIB. '/db.php');
		require_once(PM_LIB. '/fonts.php');
		require_once(PM_LIB. '/login.php');
		require_once(PM_LIB. '/options.php');
		require_once(PM_LIB. '/page.php');
		require_once(PM_LIB. '/tools.php');
		require_once(PM_LIB. '/content.php');
		require_once(PM_LIB. '/page.php');
		require_once(PM_LIB. '/plugins.php');
		require_once(PM_LIB. '/seed.php');
		require_once(PM_LIB. '/settings.php');
		require_once(PM_LIB. '/themes.php');
		require_once(PM_LIB. '/user.php');
		require_once(PM_LIB. '/users.php');
		// Include Models
		require_once(PM_LIB. '/plugin.php');
		require_once(PM_LIB. '/theme.php');
		require_once(PM_LIB. '/admin.php');
//		require_once(PM_ROOT. PM_LIB. '/hooks.php');
//		require_once(PM_ROOT. PM_LIB. '/filters.php');
		// Initialize tools
		$this->tools = new PM_Tools;
		// Set up PageMotor charset and URL structure
		$this->charset = defined('PM_HTML_CHARSET') && !empty(PM_HTML_CHARSET) ? PM_HTML_CHARSET : $this->charset;
		$this->ssl = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? true : $this->ssl;
		$this->protocol = 'http'. ($this->ssl ? 's' : ''). "://";
		$this->install_slug = $this->tools->remove_slashes(!empty(PM_INSTALL_LOCATION) ? PM_INSTALL_LOCATION : $this->install_slug);
		$this->site_url = $this->protocol. $_SERVER['HTTP_HOST']. '/'. (!empty($this->install_slug) ? "$this->install_slug/" : '');
		$this->admin_slug = $this->tools->remove_slashes(!empty(PM_ADMIN_SLUG) ? PM_ADMIN_SLUG : $this->admin_slug);
		$this->admin_url = $this->site_url. "$this->admin_slug/";
		// Ensure basic config is ok
		if (empty($this->site_url))
			new PM_Error('No PageMotor site URL found. Check your config file to ensure PageMotor has been set up properly.');
		// Set up user filesystem
		$this->user_files();
		// Check .htaccess and set up if necessary
		$this->check_htaccess();
		// Connect to the database
		$this->db = new PM_DB(array(
			'name' => DB_NAME,
			'user' => DB_USER,
			'password' => DB_PASSWORD,
			'prefix' => DB_TABLE_PREFIX,
			'host' => DB_HOST,
			'flags' => false,
			'charset' => DB_CHARSET,
			'collate' => DB_COLLATE));
	}

	private function user_files() {
		define('PM_USER_CONTENT', PM_ROOT. '/user-content');
		if (!is_dir(PM_USER_CONTENT)) {
			mkdir(PM_USER_CONTENT, 0775);
			mkdir(PM_USER_CONTENT. '/css', 0775);
			mkdir(PM_USER_CONTENT. '/images', 0775);
			mkdir(PM_USER_CONTENT. '/plugins', 0775);
			mkdir(PM_USER_CONTENT. '/themes', 0775);
		}
		elseif (!is_dir(PM_USER_CONTENT. '/css'))
			mkdir(PM_USER_CONTENT. '/css', 0775);
		elseif (!is_dir(PM_USER_CONTENT. '/images'))
			mkdir(PM_USER_CONTENT. '/images', 0775);
		elseif (!is_dir(PM_USER_CONTENT. '/plugins'))
			mkdir(PM_USER_CONTENT. '/plugins', 0775);
		elseif (!is_dir(PM_USER_CONTENT. '/themes'))
			mkdir(PM_USER_CONTENT. '/themes', 0775);
		define('PM_USER_CSS', PM_USER_CONTENT. '/css');
		define('PM_USER_IMAGES', PM_USER_CONTENT. '/images');
	}

	public function init() {
		// Initialize seeds
		$this->seed = new PM_Seed;
		// Set up Content, Options, and Settings objects so current page info can be acquired
		$this->content = new PM_Content;
		$this->options = new PM_Options;
		$this->settings = new PM_Settings;
		// Set up Fonts
		$this->fonts = new PM_Fonts;
		// Initialize user tools
		$this->users = new PM_Users;
		// Determine page request info
		$this->page = new PM_Page;
		// Set up current user (login and registration redirects happen in the PM_Page object)
		$this->user = $this->users->current_user();
		// Set up asset URLs
		define('PM_URL', $this->tools->remove_slashes($this->site_url));
		define('PM_LIB_URL', PM_URL. '/lib');
		define('PM_CSS_URL', PM_LIB_URL. '/css');
		define('PM_IMAGES_URL', PM_LIB_URL. '/images');
		define('PM_JS_URL', PM_LIB_URL. '/js');
		define('PM_RTE_URL', PM_LIB_URL. '/tinymce');
		define('PM_USER_CONTENT_URL', PM_URL. '/user-content');
		define('PM_USER_CSS_URL', PM_USER_CONTENT_URL. '/css');
		define('PM_USER_IMAGES_URL', PM_USER_CONTENT_URL. '/images');
		// Include Plugin FILES so Themes can launch them as needed
		$this->plugins = new PM_Plugins;
		// Include and Launch Themes
		$this->themes = new PM_Themes;
		$this->theme = $this->themes->theme();
		if ($this->page->is_admin)
			$this->admin = $this->themes->admin_theme();
	}

	public function run() {
		$this->page->run();
		$this->theme->__run();
		if ($this->page->is_admin)
			$this->admin->__run();
	}

/*
	Shortcut method to (maybe) textify text and ensure it's suitable for the output environment
	Possible $format values:
	• 'content' = textify content and allow all valid (modern) HTML tags except styles and scripts
	• 'inline' = textify and allow UI-appropriate HTML
	• 'inline-no-links' = textify and allow formatting HTML but no links
	• 'no-html' = textify but don't allow any HTML tags
	• 'escape-html' = textify content but escape HTML tags
	• 'escape-code' = escape code (leaves quotes alone, NOT suitable for attributes)
	• false = escape text (suitable for HTML attributes and data values)
*/
	public function text($string = false, $format = false) {
		$string = (string) $string;
		return strlen($string) === 0 ? false : ($format == 'inline' ?
			$this->tools->text->allow($string) : ($format == 'inline-no-links' ?
			$this->tools->text->allow($string, 'inline-no-links') : ($format == 'no-html' ?
			$this->tools->text->allow($string, false) : ($format == 'content' ?
			$this->tools->text->allow($string, 'content') : ($format == 'escape-html' ?
			$this->tools->text->escape($string, 'escape-html') : ($format == 'escape-code' ?
			$this->tools->text->escape($string, 'escape-code') :
			$this->tools->text->escape($string)))))));
	}

	public function url($path = false) {
		$path = rtrim($path, '/');
		return $this->tools->text->url("{$this->site_url}$path");
	}

	public function admin_url($path = false) {
		$path = rtrim($path, '/');
		return $this->tools->text->url("{$this->admin_url}$path");
	}

/*
	Shortcut method to escape URLs to ensure they don't mess with HTML output
	• $other: set to true for non-HTML use (databases, redirects, etc)
*/
	public function url_escape($url, $other = false) {
		return $this->tools->text->url($url, empty($other) ? 'attribute' : 'other');
	}

	public function redirect($url, $status = 302, $by = 'PageMotor') {
		if (empty($url))
			return false;
		elseif ($status < 300 || $status > 399)
			new PM_Error('HTTP redirect status codes must be in the 300s (3xx)!');
		$url = $this->tools->text->url($url);
		header("X-Redirect-By: $by");
		header("Location: $url", true, $status);
		exit;
	}

	private function check_htaccess() {
		if (!file_exists(PM_ROOT. '/.htaccess'))
			$this->htaccess();
		else {
			$found = false;
			$pagemotor = array();
			$directives = explode("\n", implode('', file(PM_ROOT. '/.htaccess')));
			foreach ($directives as $line) {
				if ($this->tools->text->contains($line, '# END PageMotor'))
					$found = false;
				if ($found && !$this->tools->text->starts_with($line, '#'))
					$pagemotor[] = $line;
				if ($this->tools->text->contains($line, '# BEGIN PageMotor'))
					$found = true;
			}
			if (empty($pagemotor)) // If PageMotor directives are not present...
				$this->htaccess(true);
		}
	}

	private function htaccess($prepend = false) {
		$htaccess =
			"# BEGIN PageMotor\n".
			"<IfModule mod_rewrite.c>\n".
			"RewriteEngine On\n".
			"RewriteBase /". (!empty($this->install_slug) ? "$this->install_slug/" : ''). "\n".
			"RewriteRule ^index\.php$ - [L]\n".
			"RewriteCond %{REQUEST_FILENAME} !-f\n".
			"RewriteCond %{REQUEST_FILENAME} !-d\n".
			"RewriteRule . ". (!empty($this->install_slug) ? "/$this->install_slug" : ''). "/index.php [L]\n".
			"</IfModule>\n".
			"# END PageMotor\n";
		if ($prepend)
			$this->tools->write(PM_ROOT. '/.htaccess', "\n". $htaccess, 'a+');
		else
			$this->tools->write(PM_ROOT. '/.htaccess', $htaccess);
	}
}